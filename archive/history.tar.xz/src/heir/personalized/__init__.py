"""Development pathway for specimen-matched spatial relative-expression prediction.

Historical experiment contracts in :mod:`heir.evaluation` remain independent.
"""

from .schema import Prediction, PredictionInputs, RNAReference, SpatialTargets

__all__ = ["Prediction", "PredictionInputs", "RNAReference", "SpatialTargets"]
