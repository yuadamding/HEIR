"""Terminal gate and outcome-free gene audit for bounded GSE315411.

The protocol ``gse315411_bounded_same_section_cell_state_v1`` failed its
prespecified Phase-4 external V1-only annotation gate before any GSE315411
molecular outcome was released.  The identity is terminal.  This module
therefore deliberately contains no H-MEAS, B0, decision-calibration, model-fit,
or locked-execution implementation.

Only two audit surfaces remain:

* recomputation of the Prime-only/V1 target-gene independence identities; and
* a deterministic terminal receipt plus an unconditional Phase 5--9 guard.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Dict, Mapping, Sequence, Tuple

from heir.annotation.external_validation_receipt import validate_external_validation_receipt
from heir.data.experiment_manifest import canonical_sha256
from heir.data.gse315411_bounded_protocol import PROTOCOL_ID, receipt_sha256
from heir.utils import sha256_file

TERMINAL_RECEIPT_SCHEMA = "heir.gse315411_bounded_phase4_terminal.v1"
PROTOCOL_TERMINAL_STATUS = "terminal_pre_unlock_annotation_qualification_failure"
ANNOTATION_VALIDATION_SCHEMA = "heir.gse274199_celltypist_v1_external_validation.v1"
ANNOTATION_VALIDATION_RECEIPT_PATH = (
    "/mnt/seagate/HnE/GSE315411/annotation_validation/GSE274199/"
    "gse274199_celltypist_v1_validation.receipt.json"
)
ANNOTATION_VALIDATION_ROW_EVIDENCE_PATH = (
    "/mnt/seagate/HnE/GSE315411/annotation_validation/GSE274199/"
    "gse274199_celltypist_v1_validation.rows.tsv.gz"
)
ANNOTATION_VALIDATION_RECEIPT_FILE_SHA256 = (
    "756e6cbf98e948bac3ab7d835d9e1d7a6d4098a3f8873688578d19fcd01b8d09"
)
ANNOTATION_VALIDATION_ROW_EVIDENCE_SHA256 = (
    "1bc06dff69fa60d6a88eae5729545b17bd39ffc76936f5955f2842ad1f6d2935"
)

PROBE_ARCHIVE_SHA256 = "af61de99923262eadc5ad8c88ca56a19902f92ff125620271cda4531d1de23c0"
V1_ORDERED_GENE_IDS_SHA256 = "d61c591575d539e4d4135ddba5d06a1d9ecf01d1971a22526a201080cf6acf61"
V1_SORTED_LF_GENE_IDS_SHA256 = "c974281fe6bcbb870f2985c5fdeb5d098b6863d92c73295603ea86a343ce0023"
PRIME_ORDERED_GENE_IDS_SHA256 = "d689a570775e6917baac2b39d75abac59c5e1ee1e8700d60935add05dc29bb07"
PRIME_SORTED_LF_GENE_IDS_SHA256 = "ee76fe4fe0781f6213169aee886018b406218a957fdb81533c6832437787b1a8"
PRIME_ONLY_ORDERED_GENE_IDS_SHA256 = (
    "9702a0aeb15aa8dfbb6cfa98f29e9539659099042f07746e547ec2318681d4ca"
)
PRIME_ONLY_SORTED_LF_GENE_IDS_SHA256 = (
    "3330fe07846da3f131b0ec6acc3754ff5f070366bd1c4f5e2d00bbbe0af20ba0"
)
ANNOTATION_INPUT_ORDERED_GENE_IDS_SHA256 = (
    "433c5db928a2eda6b76eef912ead304a45782d8c095bb4a47fcb261b1f70a351"
)
ANNOTATION_INPUT_SORTED_LF_GENE_IDS_SHA256 = (
    "0857a2a0aba0b48b724726e7156b032850191e08d930845ebc68e5b3c4e03610"
)


class TerminalBoundedProtocolError(RuntimeError):
    """Phase 5--9 was requested for a terminal pre-unlock identity."""


def _strings(value: object, name: str, *, count: int | None = None) -> Tuple[str, ...]:
    if not isinstance(value, list):
        raise ValueError(f"{name} must be a list")
    result = tuple(value)
    if any(not isinstance(item, str) or not item.strip() for item in result):
        raise ValueError(f"{name} must contain non-empty strings")
    if len(result) != len(set(result)):
        raise ValueError(f"{name} must be unique")
    if count is not None and len(result) != count:
        raise ValueError(f"{name} must contain exactly {count} values")
    return result


def sorted_lf_set_sha256(values: Sequence[str]) -> str:
    """Hash unique strings in sorted order, each terminated by one LF."""

    payload = "".join(f"{value}\n" for value in sorted(set(values))).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def validate_prime_only_target_panel(value: Mapping[str, object]) -> Mapping[str, object]:
    """Recompute the outcome-free target/annotation disjointness assertions."""

    panel = dict(value)
    required = {
        "strategy",
        "ordered_target_gene_ids",
        "ordered_target_gene_ids_canonical_sha256",
        "target_gene_ids_sorted_lf_sha256",
        "prime_gene_ids",
        "prime_gene_ids_ordered_canonical_sha256",
        "prime_gene_ids_sorted_lf_sha256",
        "prime_only_candidate_gene_ids",
        "prime_only_candidate_gene_ids_ordered_canonical_sha256",
        "prime_only_candidate_gene_ids_sorted_lf_sha256",
        "v1_panel_gene_ids",
        "v1_panel_gene_ids_ordered_canonical_sha256",
        "v1_panel_gene_ids_sorted_lf_sha256",
        "annotation_input_gene_ids",
        "annotation_input_gene_ids_ordered_canonical_sha256",
        "annotation_input_gene_ids_sorted_lf_sha256",
        "probe_archive_sha256",
        "target_v1_intersection",
        "target_annotation_input_intersection",
        "source_matrix",
        "common_across_supported_types",
        "type_specific_or_program_fallback_allowed",
    }
    if set(panel) != required:
        raise ValueError("Prime-only target panel fields differ from the audit contract")

    targets = _strings(panel["ordered_target_gene_ids"], "target genes")
    prime = _strings(panel["prime_gene_ids"], "Prime genes", count=5001)
    candidates = _strings(panel["prime_only_candidate_gene_ids"], "Prime-only genes")
    v1 = _strings(panel["v1_panel_gene_ids"], "V1 genes", count=480)
    annotation = _strings(panel["annotation_input_gene_ids"], "annotation genes", count=379)
    if not targets:
        raise ValueError("target genes cannot be empty")

    identities = (
        (
            targets,
            panel["ordered_target_gene_ids_canonical_sha256"],
            panel["target_gene_ids_sorted_lf_sha256"],
            "target",
        ),
        (
            prime,
            panel["prime_gene_ids_ordered_canonical_sha256"],
            panel["prime_gene_ids_sorted_lf_sha256"],
            "Prime",
        ),
        (
            candidates,
            panel["prime_only_candidate_gene_ids_ordered_canonical_sha256"],
            panel["prime_only_candidate_gene_ids_sorted_lf_sha256"],
            "Prime-only",
        ),
        (
            v1,
            panel["v1_panel_gene_ids_ordered_canonical_sha256"],
            panel["v1_panel_gene_ids_sorted_lf_sha256"],
            "V1",
        ),
        (
            annotation,
            panel["annotation_input_gene_ids_ordered_canonical_sha256"],
            panel["annotation_input_gene_ids_sorted_lf_sha256"],
            "annotation",
        ),
    )
    for genes, ordered_hash, sorted_lf_hash, name in identities:
        if ordered_hash != canonical_sha256(list(genes)):
            raise ValueError(f"{name} ordered gene hash differs from explicit IDs")
        if sorted_lf_hash != sorted_lf_set_sha256(genes):
            raise ValueError(f"{name} sorted-LF gene hash differs from explicit IDs")

    frozen = {
        "probe_archive_sha256": PROBE_ARCHIVE_SHA256,
        "v1_panel_gene_ids_ordered_canonical_sha256": V1_ORDERED_GENE_IDS_SHA256,
        "v1_panel_gene_ids_sorted_lf_sha256": V1_SORTED_LF_GENE_IDS_SHA256,
        "prime_gene_ids_ordered_canonical_sha256": PRIME_ORDERED_GENE_IDS_SHA256,
        "prime_gene_ids_sorted_lf_sha256": PRIME_SORTED_LF_GENE_IDS_SHA256,
        "prime_only_candidate_gene_ids_ordered_canonical_sha256": (
            PRIME_ONLY_ORDERED_GENE_IDS_SHA256
        ),
        "prime_only_candidate_gene_ids_sorted_lf_sha256": (PRIME_ONLY_SORTED_LF_GENE_IDS_SHA256),
        "annotation_input_gene_ids_ordered_canonical_sha256": (
            ANNOTATION_INPUT_ORDERED_GENE_IDS_SHA256
        ),
        "annotation_input_gene_ids_sorted_lf_sha256": (ANNOTATION_INPUT_SORTED_LF_GENE_IDS_SHA256),
    }
    if any(panel.get(name) != expected for name, expected in frozen.items()):
        raise ValueError("probe-derived V1/Prime/annotation identity differs")

    v1_set = set(v1)
    annotation_set = set(annotation)
    expected_prime_only = tuple(gene for gene in prime if gene not in v1_set)
    if candidates != expected_prime_only or len(candidates) != 4762:
        raise ValueError("Prime-only genes are not archive-ordered Prime minus V1")
    if annotation != tuple(gene for gene in v1 if gene in annotation_set):
        raise ValueError("annotation genes are not in frozen V1 archive order")

    target_set = set(targets)
    v1_overlap = sorted(target_set & v1_set)
    annotation_overlap = sorted(target_set & annotation_set)
    if panel["target_v1_intersection"] != v1_overlap or v1_overlap:
        raise ValueError("target genes overlap the V1 annotation panel")
    if panel["target_annotation_input_intersection"] != annotation_overlap or annotation_overlap:
        raise ValueError("target genes overlap actual annotation-model inputs")
    if not target_set <= set(candidates):
        raise ValueError("target genes are not a subset of Prime-only genes")

    expected_literals = {
        "strategy": "common_reliable_panel_across_all_supported_fine_types",
        "source_matrix": "Prime_only_not_combined_V1_Prime",
        "common_across_supported_types": True,
        "type_specific_or_program_fallback_allowed": False,
    }
    if any(panel.get(name) != expected for name, expected in expected_literals.items()):
        raise ValueError("target-panel strategy, source, or fallback differs")
    return panel


def terminal_protocol_receipt() -> Mapping[str, object]:
    """Return the frozen outcome-blind Phase-4 terminal disposition."""

    verified = verify_terminal_annotation_evidence()
    decision = verified["decision"]
    qualified_metrics = verified["qualified_type_global_metrics"]

    value: Dict[str, object] = {
        "schema": TERMINAL_RECEIPT_SCHEMA,
        "protocol_id": PROTOCOL_ID,
        "status": PROTOCOL_TERMINAL_STATUS,
        "classification": "pre_unlock_eligibility_failure",
        "decision": "fail_closed_before_biological_execution",
        "terminal_result": True,
        "terminal_phase": "phase_4_external_V1_only_annotation_validation",
        "annotation_validation_evidence": {
            "schema": ANNOTATION_VALIDATION_SCHEMA,
            "receipt_path": ANNOTATION_VALIDATION_RECEIPT_PATH,
            "receipt_file_sha256": ANNOTATION_VALIDATION_RECEIPT_FILE_SHA256,
            "row_evidence_sha256": ANNOTATION_VALIDATION_ROW_EVIDENCE_SHA256,
            "passing_subset_multiclass_expected_calibration_error": qualified_metrics[
                "calibration_error"
            ],
            "maximum_allowed_multiclass_expected_calibration_error": 0.10,
            "passing_subset_prediction_coverage": qualified_metrics["prediction_coverage"],
            "minimum_required_prediction_coverage": 0.80,
            "failure_reasons": decision["global_failure_reasons"],
            "qualified_model_classes": decision["qualified_model_classes_for_gse315411"],
            "authorizes_gse315411_annotation": decision["authorizes_gse315411_annotation"],
        },
        "phases_5_through_9_executed": False,
        "development_prime_released": False,
        "locked_prime_released": False,
        "locked_target_access_started": False,
        "locked_payloads_opened": False,
        "biological_hypothesis_tested": False,
        "protocol_identity_terminal": True,
        "same_identity_repair_or_rerun_allowed": False,
        "authorizations": {
            "authorizes_h_cell": False,
            "authorizes_h_intrinsic": False,
            "authorizes_h_ref": False,
            "authorizes_h_ext": False,
            "authorizes_full_heir": False,
        },
    }
    value["receipt_sha256"] = receipt_sha256(value)
    return value


def verify_terminal_annotation_evidence(
    *,
    receipt_path: str | Path = ANNOTATION_VALIDATION_RECEIPT_PATH,
    row_evidence_path: str | Path = ANNOTATION_VALIDATION_ROW_EVIDENCE_PATH,
) -> Mapping[str, object]:
    """Verify bytes and recompute the Phase-4 failure from row evidence."""

    path = Path(receipt_path).expanduser().resolve()
    rows = Path(row_evidence_path).expanduser().resolve()
    if not path.is_file() or sha256_file(path) != ANNOTATION_VALIDATION_RECEIPT_FILE_SHA256:
        raise ValueError("terminal annotation receipt bytes differ or are missing")
    if not rows.is_file() or sha256_file(rows) != ANNOTATION_VALIDATION_ROW_EVIDENCE_SHA256:
        raise ValueError("terminal annotation row-evidence bytes differ or are missing")
    raw = json.loads(path.read_text(encoding="utf-8"))
    verified = validate_external_validation_receipt(raw, row_evidence_path=rows)
    decision = verified.get("decision")
    if decision != {
        "status": "fail",
        "reason": "external_v1_only_annotation_gate_failed_closed",
        "global_failure_reasons": [
            "calibration_error_above_0.10",
            "prediction_coverage_below_0.80",
        ],
        "passing_model_classes_before_global_gate": ["AT2", "B cells", "CD8 T cells"],
        "qualified_model_classes_for_gse315411": [],
        "authorizes_gse315411_annotation": False,
    }:
        raise ValueError("semantically verified annotation evidence is not terminal")
    row_block = verified.get("row_level_evidence")
    if (
        not isinstance(row_block, Mapping)
        or row_block.get("sha256") != ANNOTATION_VALIDATION_ROW_EVIDENCE_SHA256
    ):
        raise ValueError("terminal annotation receipt binds different row evidence")
    return verified


def validate_terminal_protocol_receipt(
    value: Mapping[str, object],
) -> Mapping[str, object]:
    """Accept a terminal disposition only after re-verifying its source evidence."""

    expected = terminal_protocol_receipt()
    if dict(value) != expected:
        raise ValueError("terminal protocol receipt differs from recomputed disposition")
    return value


def require_phase_5_to_9_authorized(phase: int) -> None:
    """Unconditionally refuse any downstream action for this identity."""

    if isinstance(phase, bool) or not isinstance(phase, int) or phase not in range(5, 10):
        raise ValueError("phase must be an integer from 5 through 9")
    terminal_protocol_receipt()
    raise TerminalBoundedProtocolError(
        f"Phase {phase} is forbidden: {PROTOCOL_ID} is {PROTOCOL_TERMINAL_STATUS}; "
        f"external annotation evidence {ANNOTATION_VALIDATION_RECEIPT_FILE_SHA256} "
        "qualified no model classes and did not authorize GSE315411 annotation"
    )


__all__ = [
    "ANNOTATION_INPUT_ORDERED_GENE_IDS_SHA256",
    "ANNOTATION_INPUT_SORTED_LF_GENE_IDS_SHA256",
    "ANNOTATION_VALIDATION_RECEIPT_FILE_SHA256",
    "ANNOTATION_VALIDATION_ROW_EVIDENCE_SHA256",
    "ANNOTATION_VALIDATION_ROW_EVIDENCE_PATH",
    "ANNOTATION_VALIDATION_SCHEMA",
    "PRIME_ONLY_ORDERED_GENE_IDS_SHA256",
    "PRIME_ONLY_SORTED_LF_GENE_IDS_SHA256",
    "PROBE_ARCHIVE_SHA256",
    "PROTOCOL_TERMINAL_STATUS",
    "TERMINAL_RECEIPT_SCHEMA",
    "TerminalBoundedProtocolError",
    "V1_ORDERED_GENE_IDS_SHA256",
    "V1_SORTED_LF_GENE_IDS_SHA256",
    "require_phase_5_to_9_authorized",
    "sorted_lf_set_sha256",
    "terminal_protocol_receipt",
    "validate_terminal_protocol_receipt",
    "validate_prime_only_target_panel",
    "verify_terminal_annotation_evidence",
]
