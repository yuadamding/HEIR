"""Hash-gated, sandboxed export of CellTypist pickle models.

Pickle is executable.  This module therefore copies and verifies the input in
the parent, loads it only inside a no-network bubblewrap sandbox, and accepts
only inert numeric NPZ plus JSON back from that sandbox.
"""

from __future__ import annotations

import errno
import hashlib
import json
import os
import resource
import shutil
import site
import stat
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Any, Mapping, Union

import numpy as np

PathLike = Union[str, os.PathLike]
SCHEMA = "heir.celltypist_inert_export_receipt.v1"
WORKER_SCHEMA = "heir.celltypist_pickle_worker_export.v1"
OFFICIAL_HUMAN_LUNG_ATLAS_V2_SHA256 = (
    "6b0730537f4fee9f9a6195891a72635d1a3b9e21cade7a7481b2b14808070fdd"
)
OFFICIAL_HUMAN_LUNG_ATLAS_V2_SOURCE = (
    "https://celltypist.cog.sanger.ac.uk/models/Human_Lung_Sikkema/v2/Human_Lung_Atlas.pkl"
)
_ARRAY_NAMES = (
    "coefficient_matrix",
    "intercepts",
    "scaler_mean",
    "scaler_scale",
    "scaler_variance",
)


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _sha256_json(value: object) -> str:
    encoded = json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _validated_digest(value: str) -> str:
    normalized = value.strip().lower()
    invalid_character = any(character not in "0123456789abcdef" for character in normalized)
    if len(normalized) != 64 or invalid_character:
        raise ValueError("expected_sha256 must be exactly 64 lowercase hexadecimal characters")
    return normalized


def _copy_verified(source: Path, destination: Path, expected_sha256: str) -> int:
    digest = hashlib.sha256()
    size = 0
    with source.open("rb") as input_handle, destination.open("xb") as output_handle:
        for block in iter(lambda: input_handle.read(1024 * 1024), b""):
            output_handle.write(block)
            digest.update(block)
            size += len(block)
        output_handle.flush()
        os.fsync(output_handle.fileno())
    if digest.hexdigest() != expected_sha256:
        destination.unlink()
        raise ValueError("CellTypist pickle SHA-256 does not match expected_sha256")
    destination.chmod(0o400)
    return size


def _site_package_roots() -> list[Path]:
    roots = []
    for raw in site.getsitepackages():
        path = Path(raw).resolve()
        if path.is_dir() and path not in roots:
            roots.append(path)
    if not roots:
        raise RuntimeError("no Python site-packages directory is available for the sandbox")
    return roots


def _sandbox_command(
    *,
    bwrap: Path,
    staged_pickle: Path,
    output_dir: Path,
    expected_sha256: str,
) -> list[str]:
    runtime = Path(sys.base_prefix).resolve()
    executable = Path(sys.executable).resolve()
    try:
        executable_relative = executable.relative_to(runtime)
    except ValueError as error:
        raise RuntimeError("Python executable is outside sys.base_prefix") from error
    worker = Path(__file__).with_name("_celltypist_pickle_worker.py").resolve()
    if not worker.is_file():
        raise RuntimeError("CellTypist sandbox worker is missing")

    command = [
        str(bwrap),
        "--unshare-all",
        "--new-session",
        "--die-with-parent",
        "--cap-drop",
        "ALL",
    ]
    for system_path in (Path("/usr"), Path("/lib"), Path("/lib64")):
        if system_path.exists():
            command.extend(("--ro-bind", str(system_path), str(system_path)))
    command.extend(("--ro-bind", str(runtime), "/runtime"))
    package_mounts = []
    for index, package_root in enumerate(_site_package_roots()):
        target = f"/packages/{index}"
        command.extend(("--ro-bind", str(package_root), target))
        package_mounts.append(target)
    command.extend(
        (
            "--proc",
            "/proc",
            "--dev",
            "/dev",
            "--tmpfs",
            "/tmp",
            "--dir",
            "/input",
            "--ro-bind",
            str(staged_pickle),
            "/input/model.pkl",
            "--bind",
            str(output_dir),
            "/output",
            "--ro-bind",
            str(worker),
            "/worker.py",
            "--chdir",
            "/tmp",
            "--clearenv",
            "--setenv",
            "PATH",
            "/runtime/bin:/usr/bin",
            "--setenv",
            "PYTHONPATH",
            ":".join(package_mounts),
            "--setenv",
            "PYTHONNOUSERSITE",
            "1",
            "--setenv",
            "PYTHONHASHSEED",
            "0",
            "--setenv",
            "HOME",
            "/tmp",
            "--setenv",
            "TMPDIR",
            "/tmp",
            f"/runtime/{executable_relative}",
            "/worker.py",
            "--source",
            "/input/model.pkl",
            "--expected-sha256",
            expected_sha256,
            "--output-dir",
            "/output",
        )
    )
    return command


def _resource_limits() -> None:
    resource.setrlimit(resource.RLIMIT_CPU, (120, 120))
    resource.setrlimit(resource.RLIMIT_AS, (4 * 1024**3, 4 * 1024**3))
    resource.setrlimit(resource.RLIMIT_FSIZE, (64 * 1024**2, 64 * 1024**2))
    resource.setrlimit(resource.RLIMIT_NOFILE, (64, 64))


def _run_isolated_worker(command: list[str], timeout_seconds: int) -> None:
    with tempfile.TemporaryFile(mode="w+", encoding="utf-8") as log:
        try:
            completed = subprocess.run(
                command,
                check=False,
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=log,
                text=True,
                timeout=timeout_seconds,
                preexec_fn=_resource_limits,
            )
        except subprocess.TimeoutExpired as error:
            raise RuntimeError("sandboxed CellTypist export timed out") from error
        log.seek(0, os.SEEK_END)
        log.seek(max(0, log.tell() - 2000))
        detail = log.read().strip().replace("\x00", "")
    if completed.returncode != 0:
        raise RuntimeError(f"sandboxed CellTypist export failed: {detail}")


def _plain_mapping(value: object, label: str) -> Mapping[str, Any]:
    if type(value) is not dict:
        raise ValueError(f"{label} must be a plain JSON object")
    return value


def _validate_worker_outputs(output_dir: Path, source_sha256: str) -> Mapping[str, Any]:
    manifest_path = output_dir / "manifest.json"
    weights_path = output_dir / "weights.npz"
    regular_files = all(
        path.exists()
        and not path.is_symlink()
        and stat.S_ISREG(os.lstat(path).st_mode)
        for path in (manifest_path, weights_path)
    )
    if not regular_files:
        raise ValueError("sandbox did not produce both required artifacts")
    if set(path.name for path in output_dir.iterdir()) != {"manifest.json", "weights.npz"}:
        raise ValueError("sandbox produced unexpected output files")
    if manifest_path.stat().st_size > 16 * 1024**2 or weights_path.stat().st_size > 64 * 1024**2:
        raise ValueError("sandbox output exceeds the frozen size limit")
    expected_members = {f"{name}.npy" for name in _ARRAY_NAMES}
    with zipfile.ZipFile(weights_path) as zipped:
        members = zipped.infolist()
        if {member.filename for member in members} != expected_members:
            raise ValueError("NPZ ZIP members do not match the inert array contract")
        if any(member.is_dir() or member.file_size > 64 * 1024**2 for member in members):
            raise ValueError("NPZ ZIP member exceeds the inert array contract")
        if sum(member.file_size for member in members) > 64 * 1024**2:
            raise ValueError("NPZ uncompressed content exceeds the frozen size limit")
    manifest = _plain_mapping(json.loads(manifest_path.read_text(encoding="utf-8")), "manifest")
    if manifest.get("schema") != WORKER_SCHEMA or manifest.get("source_sha256") != source_sha256:
        raise ValueError("sandbox manifest identity does not match the verified input")
    if manifest.get("network_namespace_checked") is not True:
        raise ValueError("sandbox did not attest its network namespace")
    interfaces = manifest.get("network_interface_names")
    if type(interfaces) is not list or any(name != "lo" for name in interfaces):
        raise ValueError("sandbox reported a non-isolated network interface")

    arrays_metadata = _plain_mapping(manifest.get("arrays"), "array metadata")
    if set(arrays_metadata) != set(_ARRAY_NAMES):
        raise ValueError("sandbox array manifest is incomplete")
    with np.load(weights_path, allow_pickle=False) as archive:
        if set(archive.files) != set(_ARRAY_NAMES):
            raise ValueError("NPZ contains unexpected arrays")
        for name in _ARRAY_NAMES:
            value = archive[name]
            metadata = _plain_mapping(arrays_metadata[name], f"metadata for {name}")
            if value.dtype.kind not in "fiu" or not np.isfinite(value).all():
                raise ValueError(f"NPZ array {name} is not finite numeric data")
            dtype_differs = metadata.get("dtype") != str(value.dtype)
            shape_differs = metadata.get("shape") != list(value.shape)
            if dtype_differs or shape_differs:
                raise ValueError(f"NPZ array {name} differs from its manifest")
    return manifest


def _atomic_json(payload: Mapping[str, Any], destination: Path) -> None:
    descriptor, temporary = tempfile.mkstemp(
        prefix=destination.name + ".", suffix=".tmp", dir=str(destination.parent)
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        _publish_noreplace(Path(temporary), destination)
        Path(temporary).unlink()
    except BaseException:
        Path(temporary).unlink(missing_ok=True)
        raise


def _publish_noreplace(source: Path, destination: Path) -> None:
    """Publish without replacing an existing file, including on exFAT."""

    try:
        os.link(source, destination)
        return
    except OSError as error:
        if error.errno not in {errno.EPERM, errno.EOPNOTSUPP, errno.EXDEV, errno.ENOSYS}:
            raise
    created = False
    try:
        with source.open("rb") as input_handle, destination.open("xb") as output_handle:
            created = True
            shutil.copyfileobj(input_handle, output_handle, length=1024 * 1024)
            output_handle.flush()
            os.fsync(output_handle.fileno())
        if _sha256_file(source) != _sha256_file(destination):
            raise OSError("exclusive-copy publication failed its SHA-256 check")
    except BaseException:
        if created:
            destination.unlink(missing_ok=True)
        raise


def export_celltypist_pickle(
    source_pickle: PathLike,
    expected_sha256: str,
    weights_output: PathLike,
    receipt_output: PathLike,
    *,
    bwrap_executable: PathLike = "bwrap",
    timeout_seconds: int = 180,
) -> Mapping[str, Any]:
    """Export a hash-pinned CellTypist pickle without loading it in this process."""

    source = Path(source_pickle).expanduser().resolve()
    weights = Path(weights_output).expanduser().resolve()
    receipt = Path(receipt_output).expanduser().resolve()
    expected = _validated_digest(expected_sha256)
    if not source.is_file():
        raise FileNotFoundError(source)
    if weights == receipt or weights == source or receipt == source:
        raise ValueError("CellTypist input and output paths must be distinct")
    if weights.suffix != ".npz" or receipt.suffix != ".json":
        raise ValueError("CellTypist outputs must use .npz and .json suffixes")
    if weights.exists() or receipt.exists():
        raise FileExistsError("CellTypist export is immutable; outputs must not already exist")
    if timeout_seconds <= 0:
        raise ValueError("timeout_seconds must be positive")
    resolved_bwrap = shutil.which(str(bwrap_executable))
    if resolved_bwrap is None:
        raise RuntimeError("bubblewrap is required; unsafe pickle-loading fallback is prohibited")
    weights.parent.mkdir(parents=True, exist_ok=True)
    receipt.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="heir-celltypist-export-", dir=weights.parent) as raw:
        staging = Path(raw)
        staged_pickle = staging / "verified-model.pkl"
        sandbox_output = staging / "sandbox-output"
        sandbox_output.mkdir(mode=0o700)
        source_bytes = _copy_verified(source, staged_pickle, expected)
        command = _sandbox_command(
            bwrap=Path(resolved_bwrap),
            staged_pickle=staged_pickle,
            output_dir=sandbox_output,
            expected_sha256=expected,
        )
        _run_isolated_worker(command, timeout_seconds)
        worker_manifest = _validate_worker_outputs(sandbox_output, expected)
        temporary_weights = sandbox_output / "weights.npz"
        weights_sha256 = _sha256_file(temporary_weights)
        temporary_weights.chmod(0o444)
        _publish_noreplace(temporary_weights, weights)

    features = worker_manifest["ordered_feature_ids"]
    classes = worker_manifest["ordered_class_ids"]
    export_receipt = {
        "schema": SCHEMA,
        "source": {
            "path": str(source),
            "bytes": source_bytes,
            "expected_sha256": expected,
            "verified_sha256": expected,
            "official_model_id": (
                "CellTypist Human_Lung_Atlas v2"
                if expected == OFFICIAL_HUMAN_LUNG_ATLAS_V2_SHA256
                else None
            ),
            "official_source": (
                OFFICIAL_HUMAN_LUNG_ATLAS_V2_SOURCE
                if expected == OFFICIAL_HUMAN_LUNG_ATLAS_V2_SHA256
                else None
            ),
        },
        "isolation": {
            "implementation": "bubblewrap",
            "network": "new_namespace_with_no_non_loopback_interfaces",
            "host_filesystem": "not_mounted_except_runtime_dependencies_worker_and_verified_input",
            "input_mount": "read_only",
            "unsafe_fallback_allowed": False,
            "worker_hash_reverification": True,
        },
        "weights": {
            "format": "numpy_npz_numeric_arrays_only",
            "path": str(weights),
            "sha256": weights_sha256,
            "arrays": worker_manifest["arrays"],
        },
        "ordered_feature_ids": features,
        "ordered_feature_ids_sha256": _sha256_json(features),
        "ordered_class_ids": classes,
        "ordered_class_ids_sha256": _sha256_json(classes),
        "normalization": worker_manifest["normalization"],
        "model_metadata": worker_manifest["model_metadata"],
        "pickle_required_for_production_inference": False,
    }
    _atomic_json(export_receipt, receipt)
    return export_receipt


__all__ = [
    "OFFICIAL_HUMAN_LUNG_ATLAS_V2_SHA256",
    "OFFICIAL_HUMAN_LUNG_ATLAS_V2_SOURCE",
    "export_celltypist_pickle",
]
