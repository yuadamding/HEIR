"""Sandbox-only worker that converts one trusted pickle into inert artifacts.

This module must never be imported by the production process.  The parent
bind-mounts it into a bubblewrap sandbox with no network or host-data mounts.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import pickle
import socket
from pathlib import Path
from typing import Any, Mapping

import numpy as np

SCHEMA = "heir.celltypist_pickle_worker_export.v1"


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _state(value: object, label: str) -> Mapping[str, Any]:
    try:
        state = object.__getattribute__(value, "__dict__")
    except (AttributeError, TypeError) as error:
        raise ValueError(f"{label} has no inspectable state") from error
    if type(state) is not dict:
        raise ValueError(f"{label} state is not a plain dictionary")
    return state


def _ordered_strings(value: object, label: str) -> list[str]:
    array = np.asarray(value)
    if array.ndim != 1:
        raise ValueError(f"{label} must be one-dimensional")
    result = [str(item) for item in array.tolist()]
    if not result or any(not item for item in result):
        raise ValueError(f"{label} must contain non-empty strings")
    if len(set(result)) != len(result):
        raise ValueError(f"{label} must not contain duplicates")
    return result


def _numeric_array(value: object, label: str, dimensions: int) -> np.ndarray:
    array = np.asarray(value)
    if array.ndim != dimensions:
        raise ValueError(f"{label} must have {dimensions} dimensions")
    if array.dtype.kind not in "fiu":
        raise ValueError(f"{label} must be a numeric non-object array")
    if not np.isfinite(array).all():
        raise ValueError(f"{label} contains non-finite values")
    return np.ascontiguousarray(array)


def _json_value(value: object, label: str) -> object:
    if value is None or type(value) in {str, bool, int}:
        return value
    if type(value) is float:
        if not np.isfinite(value):
            raise ValueError(f"{label} contains a non-finite float")
        return value
    if type(value) in {list, tuple}:
        return [_json_value(item, label) for item in value]
    if type(value) is dict:
        if any(type(key) is not str for key in value):
            raise ValueError(f"{label} contains a non-string key")
        return {key: _json_value(item, label) for key, item in value.items()}
    raise ValueError(f"{label} contains unsupported metadata type {type(value).__name__}")


def _qualified_type(value: object) -> str:
    cls = type(value)
    return f"{cls.__module__}.{cls.__qualname__}"


def _export(source: Path, expected_sha256: str, output_dir: Path) -> None:
    interfaces = sorted(name for _index, name in socket.if_nameindex())
    if any(name != "lo" for name in interfaces):
        raise RuntimeError("pickle worker is not in an isolated network namespace")
    actual_sha256 = _sha256_file(source)
    if actual_sha256 != expected_sha256:
        raise ValueError("sandbox input SHA-256 differs from the expected digest")

    # This is the sole executable-deserialization boundary.  It occurs only after
    # the in-sandbox hash check and network-namespace check.
    with source.open("rb") as handle:
        payload = pickle.load(handle)  # noqa: S301 - deliberately sandboxed boundary
    if type(payload) is not dict:
        raise ValueError("CellTypist payload must be a plain dictionary")
    if "Model" not in payload or "Scaler_" not in payload:
        raise ValueError("CellTypist payload lacks Model or Scaler_")

    classifier = payload["Model"]
    scaler = payload["Scaler_"]
    classifier_state = _state(classifier, "classifier")
    scaler_state = _state(scaler, "scaler")
    required_classifier = {"coef_", "intercept_", "classes_", "features"}
    required_scaler = {"mean_", "scale_", "var_", "with_mean", "with_std"}
    if missing := sorted(required_classifier - classifier_state.keys()):
        raise ValueError(f"classifier state lacks {missing}")
    if missing := sorted(required_scaler - scaler_state.keys()):
        raise ValueError(f"scaler state lacks {missing}")

    features = _ordered_strings(classifier_state["features"], "features")
    classes = _ordered_strings(classifier_state["classes_"], "classes")
    coefficients = _numeric_array(classifier_state["coef_"], "coefficients", 2)
    intercepts = _numeric_array(classifier_state["intercept_"], "intercepts", 1)
    mean = _numeric_array(scaler_state["mean_"], "scaler mean", 1)
    scale = _numeric_array(scaler_state["scale_"], "scaler scale", 1)
    variance = _numeric_array(scaler_state["var_"], "scaler variance", 1)
    class_rows, feature_columns = coefficients.shape
    if feature_columns != len(features):
        raise ValueError("coefficient columns do not match the ordered feature list")
    if class_rows != len(intercepts):
        raise ValueError("coefficient rows do not match intercepts")
    if class_rows != len(classes) and not (class_rows == 1 and len(classes) == 2):
        raise ValueError("coefficient rows do not match the class ontology")
    if not (len(mean) == len(scale) == len(variance) == len(features)):
        raise ValueError("scaler arrays do not match the ordered feature list")
    if np.any(scale <= 0) or np.any(variance < 0):
        raise ValueError("scaler scale/variance is invalid")
    if type(scaler_state["with_mean"]) is not bool or type(scaler_state["with_std"]) is not bool:
        raise ValueError("scaler normalization flags must be booleans")

    description = _json_value(payload.get("description", {}), "description")
    weights_path = output_dir / "weights.npz"
    np.savez_compressed(
        weights_path,
        coefficient_matrix=coefficients,
        intercepts=intercepts,
        scaler_mean=mean,
        scaler_scale=scale,
        scaler_variance=variance,
    )
    arrays = {
        name: {"dtype": str(value.dtype), "shape": list(value.shape)}
        for name, value in {
            "coefficient_matrix": coefficients,
            "intercepts": intercepts,
            "scaler_mean": mean,
            "scaler_scale": scale,
            "scaler_variance": variance,
        }.items()
    }
    manifest = {
        "schema": SCHEMA,
        "source_sha256": actual_sha256,
        "network_namespace_checked": True,
        "network_interface_names": interfaces,
        "ordered_feature_ids": features,
        "ordered_class_ids": classes,
        "normalization": {
            "with_mean": scaler_state["with_mean"],
            "with_std": scaler_state["with_std"],
        },
        "arrays": arrays,
        "model_metadata": {
            "classifier_type": _qualified_type(classifier),
            "scaler_type": _qualified_type(scaler),
            "classifier_pickle_sklearn_version": classifier_state.get("_sklearn_version"),
            "scaler_pickle_sklearn_version": scaler_state.get("_sklearn_version"),
            "description": description,
        },
    }
    (output_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--expected-sha256", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    _export(args.source, args.expected_sha256, args.output_dir)


if __name__ == "__main__":
    main()
