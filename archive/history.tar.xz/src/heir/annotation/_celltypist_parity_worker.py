"""Parity-only official CellTypist worker; never import from production code."""

from __future__ import annotations

import argparse
import hashlib
import json
import socket
from pathlib import Path

import numpy as np


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--expected-sha256", required=True)
    parser.add_argument("--input-tsv", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    interfaces = sorted(name for _index, name in socket.if_nameindex())
    if any(name != "lo" for name in interfaces):
        raise RuntimeError("parity worker is not isolated from the network")
    if _sha256(args.source) != args.expected_sha256:
        raise ValueError("parity pickle differs from the pinned SHA-256")

    # Executable deserialization is intentionally confined to this no-network
    # parity worker.  Production inference imports neither CellTypist nor pickle.
    import celltypist  # noqa: PLC0415
    import sklearn  # noqa: PLC0415

    prediction = celltypist.annotate(
        filename=str(args.input_tsv),
        model=str(args.source),
        mode="best match",
        majority_voting=False,
    )
    scores = prediction.decision_matrix.to_numpy(dtype=np.float64)
    probabilities = prediction.probability_matrix.to_numpy(dtype=np.float64)
    labels = [str(value) for value in prediction.predicted_labels.iloc[:, 0].tolist()]
    np.savez_compressed(
        args.output_dir / "official.npz", scores=scores, probabilities=probabilities
    )
    (args.output_dir / "official.json").write_text(
        json.dumps(
            {
                "schema": "heir.celltypist_official_parity_worker.v1",
                "celltypist_version": str(celltypist.__version__),
                "sklearn_version": str(sklearn.__version__),
                "network_interface_names": interfaces,
                "labels": labels,
                "class_order": [str(value) for value in prediction.decision_matrix.columns],
                "row_order": [str(value) for value in prediction.decision_matrix.index],
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
