"""Metrics for donor-aware external validation of an inert annotator."""

from __future__ import annotations

from typing import Mapping, Sequence

import numpy as np

from .celltypist_inert import multiclass_expected_calibration_error


def summarize_predictions(
    truth: Sequence[str],
    predicted: Sequence[str],
    confidences: np.ndarray,
    abstained: np.ndarray,
    class_ids: Sequence[str],
    *,
    calibration_bins: int = 10,
) -> Mapping[str, object]:
    true_values = np.asarray(truth, dtype="U")
    predicted_values = np.asarray(predicted, dtype="U")
    confidence_values = np.asarray(confidences, dtype=np.float64)
    abstention_values = np.asarray(abstained, dtype=np.bool_)
    classes = tuple(str(value) for value in class_ids)
    if (
        not len(true_values)
        or predicted_values.shape != true_values.shape
        or confidence_values.shape != true_values.shape
        or abstention_values.shape != true_values.shape
        or len(set(classes)) != len(classes)
        or any(value not in classes for value in true_values)
    ):
        raise ValueError("external validation vectors or class scope are invalid")
    if not np.isfinite(confidence_values).all():
        raise ValueError("external validation confidence is non-finite")

    per_class: dict[str, object] = {}
    f1_values = []
    sensitivity_values = []
    for class_id in classes:
        true_mask = true_values == class_id
        true_count = int(true_mask.sum())
        if true_count < 1:
            raise ValueError("every summarized class must have validation truth rows")
        prediction_mask = (predicted_values == class_id) & ~abstention_values
        predicted_count = int(prediction_mask.sum())
        true_positive = int((true_mask & prediction_mask).sum())
        sensitivity = true_positive / true_count
        precision = 0.0 if predicted_count == 0 else true_positive / predicted_count
        denominator = true_count + predicted_count
        f1 = 0.0 if denominator == 0 else 2.0 * true_positive / denominator
        per_class[class_id] = {
            "true_cells": true_count,
            "predicted_cells": predicted_count,
            "true_positive_cells": true_positive,
            "precision": precision,
            "sensitivity": sensitivity,
            "f1": f1,
        }
        f1_values.append(f1)
        sensitivity_values.append(sensitivity)
    correct = predicted_values == true_values
    return {
        "cells": len(true_values),
        "nonabstained_cells": int((~abstention_values).sum()),
        "fine_type_macro_f1": float(np.mean(f1_values)),
        "calibration_error": multiclass_expected_calibration_error(
            confidence_values,
            correct,
            bin_count=calibration_bins,
        ),
        "prediction_coverage": float((~abstention_values).mean()),
        "minimum_major_class_sensitivity": float(min(sensitivity_values)),
        "major_class_sensitivity_by_fine_type": {
            class_id: per_class[class_id]["sensitivity"] for class_id in classes
        },
        "per_class": per_class,
    }


def support_by_class_and_donor(
    truth: Sequence[str],
    donors: Sequence[str],
    class_ids: Sequence[str],
    donor_ids: Sequence[str],
) -> Mapping[str, Mapping[str, int]]:
    true_values = np.asarray(truth, dtype="U")
    donor_values = np.asarray(donors, dtype="U")
    if true_values.shape != donor_values.shape:
        raise ValueError("truth and donor vectors are not aligned")
    return {
        class_id: {
            donor_id: int(((true_values == class_id) & (donor_values == donor_id)).sum())
            for donor_id in donor_ids
        }
        for class_id in class_ids
    }


__all__ = ["summarize_predictions", "support_by_class_and_donor"]
