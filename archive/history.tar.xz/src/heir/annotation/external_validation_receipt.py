"""Fail-closed semantic verification for the terminal GSE274199 annotation receipt."""

from __future__ import annotations

import csv
import gzip
import json
import math
from pathlib import Path
from typing import Mapping, Sequence

import numpy as np

from .celltypist_inert import canonical_sha256, sha256_file
from .external_validation import summarize_predictions, support_by_class_and_donor

SCHEMA = "heir.gse274199_celltypist_v1_external_validation.v1"
EXPECTED_H5AD_SHA256 = "0648ce0268807301b5fe1b92955ed8e9d29c5f67812c6ed9ec3ed7da79e79b4c"
EXPECTED_H5AD_BYTES = 1_180_621_333
EXPECTED_MAPPING_SHA256 = "b577ac9f19af6d820254dfc9ecf2b956b48704049502368972a6b4245621ba88"
EXPECTED_PARITY_SHA256 = "7b37cccd44252cb663380acb41a9181dc8da58ef9d523ae21725ce06ac6b4913"
EXPECTED_ROWS_SHA256 = "1bc06dff69fa60d6a88eae5729545b17bd39ffc76936f5955f2842ad1f6d2935"
EXPECTED_ROWS = 32_320
EXPECTED_CLASS_IDS_SHA256 = "5c8878270748891d3c11fb73502e9e7c49305aa601489c4988b17a2c0d00b5db"
EXPECTED_V1_GENES_SHA256 = "d61c591575d539e4d4135ddba5d06a1d9ecf01d1971a22526a201080cf6acf61"
EXPECTED_SUPPORTED_GENES_SHA256 = (
    "45924baa65dc0e2c6706ee9f75867e776080f6b0a2acaf72f91e0c21fb651b0e"
)

PRIMARY_DONORS = (
    "LTx_pt_01",
    "LTx_pt_02",
    "LTx_pt_04",
    "LTx_pt_05",
    "LTx_pt_06",
    "LTx_pt_07",
)
SENSITIVITY_DONORS = ("LTx_pt_03", "LTx_pt_08")
QUALITY_THRESHOLDS = {
    "minimum_fine_type_macro_f1": 0.7,
    "maximum_multiclass_expected_calibration_error": 0.1,
    "minimum_major_class_sensitivity": 0.5,
    "minimum_prediction_coverage": 0.8,
    "confidence_threshold": 0.5,
    "calibration_bins": 10,
    "per_validation_donor_reporting_required": True,
}
SUPPORT_RULE = {
    "minimum_cells_per_primary_donor": 20,
    "minimum_primary_donors": 3,
}
VALIDATION_COLUMNS = (
    "validation_split",
    "validation_donor_id",
    "cell_id",
    "author_cell_type",
    "cell_ontology_term_id",
    "true_model_class",
    "predicted_model_class",
    "confidence",
    "abstained",
    "raw_sigmoid_probabilities_json",
)
TOP_LEVEL_KEYS = frozenset(
    {
        "schema",
        "decision",
        "source_dataset",
        "independence_and_label_provenance",
        "mapping",
        "feature_audit",
        "model",
        "parity",
        "quality_thresholds",
        "support_rule",
        "primary_validation",
        "type_qualification",
        "qualified_type_global_metrics",
        "adult_age_shift_sensitivity",
        "row_level_evidence",
        "execution",
    }
)


def _object(value: object, name: str) -> Mapping[str, object]:
    if type(value) is not dict:
        raise ValueError(f"{name} must be a plain JSON object")
    return value


def _compare(observed: object, expected: object, name: str) -> None:
    if isinstance(expected, Mapping):
        value = _object(observed, name)
        if set(value) != set(expected):
            raise ValueError(f"{name} keys differ from recomputed evidence")
        for key, expected_value in expected.items():
            _compare(value[key], expected_value, f"{name}.{key}")
        return
    if isinstance(expected, list):
        if type(observed) is not list or len(observed) != len(expected):
            raise ValueError(f"{name} differs from recomputed evidence")
        for index, expected_value in enumerate(expected):
            _compare(observed[index], expected_value, f"{name}[{index}]")
        return
    if isinstance(expected, float):
        if (
            isinstance(observed, bool)
            or not isinstance(observed, (int, float))
            or not math.isfinite(float(observed))
            or not math.isclose(float(observed), expected, rel_tol=1e-12, abs_tol=1e-12)
        ):
            raise ValueError(f"{name} differs from recomputed evidence")
        return
    if type(observed) is not type(expected) or observed != expected:
        raise ValueError(f"{name} differs from recomputed evidence")


def _per_donor_metrics(
    donor: np.ndarray,
    truth: np.ndarray,
    predicted: np.ndarray,
    confidence: np.ndarray,
    abstained: np.ndarray,
    class_ids: Sequence[str],
    donor_ids: Sequence[str],
    support: Mapping[str, Mapping[str, int]],
) -> Mapping[str, object]:
    result: dict[str, object] = {}
    for donor_id in donor_ids:
        donor_classes = tuple(
            class_id
            for class_id in class_ids
            if support[class_id].get(donor_id, 0)
            >= SUPPORT_RULE["minimum_cells_per_primary_donor"]
        )
        selected = (donor == donor_id) & np.isin(truth, donor_classes)
        if not donor_classes or not selected.any():
            result[donor_id] = {
                "status": "insufficient_supported_types",
                "class_ids": [],
            }
            continue
        result[donor_id] = {
            "status": "reported",
            "class_ids": list(donor_classes),
            **summarize_predictions(
                truth[selected],
                predicted[selected],
                confidence[selected],
                abstained[selected],
                donor_classes,
                calibration_bins=QUALITY_THRESHOLDS["calibration_bins"],
            ),
        }
    return result


def _read_rows(
    path: Path,
    *,
    class_ids: Sequence[str],
    author_mapping: Mapping[str, object],
) -> Mapping[str, np.ndarray]:
    donors: list[str] = []
    splits: list[str] = []
    truth: list[str] = []
    predicted: list[str] = []
    confidence: list[float] = []
    abstained: list[bool] = []
    cell_ids: set[str] = set()
    previous_order: tuple[int, str, str] | None = None
    class_index = {class_id: index for index, class_id in enumerate(class_ids)}
    split_rank = {"pediatric_primary": 0, "adult_age_shift_sensitivity": 1}
    with gzip.open(path, "rt", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if tuple(reader.fieldnames or ()) != VALIDATION_COLUMNS:
            raise ValueError("row evidence columns differ from the frozen schema")
        for row_number, row in enumerate(reader, start=2):
            split = row["validation_split"]
            donor_id = row["validation_donor_id"]
            cell_id = row["cell_id"]
            if split not in split_rank:
                raise ValueError(f"row {row_number} has an invalid validation split")
            expected_donors = PRIMARY_DONORS if split == "pediatric_primary" else SENSITIVITY_DONORS
            if donor_id not in expected_donors:
                raise ValueError(f"row {row_number} assigns a donor to the wrong split")
            order = (split_rank[split], donor_id, cell_id)
            if previous_order is not None and order <= previous_order:
                raise ValueError("row evidence is not in the frozen unique order")
            previous_order = order
            if not cell_id or cell_id in cell_ids:
                raise ValueError("row evidence contains an empty or duplicate cell ID")
            cell_ids.add(cell_id)

            mapping_record = _object(
                author_mapping.get(row["author_cell_type"]),
                f"row {row_number} author-label mapping",
            )
            target = mapping_record.get("model_class")
            if (
                target is None
                or row["true_model_class"] != target
                or row["cell_ontology_term_id"] != mapping_record.get("cell_ontology_term_id")
            ):
                raise ValueError(f"row {row_number} differs from the frozen ontology crosswalk")
            predicted_class = row["predicted_model_class"]
            if predicted_class not in class_index:
                raise ValueError(f"row {row_number} predicts an unknown model class")
            try:
                confidence_value = float(row["confidence"])
                probability = np.asarray(
                    json.loads(row["raw_sigmoid_probabilities_json"]), dtype=np.float64
                )
            except (TypeError, ValueError, json.JSONDecodeError) as error:
                raise ValueError(f"row {row_number} has malformed numeric evidence") from error
            if (
                probability.shape != (len(class_ids),)
                or not np.isfinite(probability).all()
                or np.any((probability < 0.0) | (probability > 1.0))
                or not math.isfinite(confidence_value)
            ):
                raise ValueError(f"row {row_number} has invalid sigmoid evidence")
            maximum_index = int(np.argmax(probability))
            if predicted_class != class_ids[maximum_index] or not math.isclose(
                confidence_value,
                float(probability[maximum_index]),
                rel_tol=0.0,
                abs_tol=1e-14,
            ):
                raise ValueError(f"row {row_number} prediction is not the sigmoid argmax")
            if row["abstained"] not in {"true", "false"}:
                raise ValueError(f"row {row_number} has an invalid abstention flag")
            abstention = confidence_value < QUALITY_THRESHOLDS["confidence_threshold"]
            if (row["abstained"] == "true") != abstention:
                raise ValueError(f"row {row_number} abstention differs from the frozen threshold")

            splits.append(split)
            donors.append(donor_id)
            truth.append(str(target))
            predicted.append(predicted_class)
            confidence.append(confidence_value)
            abstained.append(abstention)
    return {
        "split": np.asarray(splits, dtype="U"),
        "donor": np.asarray(donors, dtype="U"),
        "truth": np.asarray(truth, dtype="U"),
        "predicted": np.asarray(predicted, dtype="U"),
        "confidence": np.asarray(confidence, dtype=np.float64),
        "abstained": np.asarray(abstained, dtype=np.bool_),
    }


def _recompute_claims(
    rows: Mapping[str, np.ndarray], class_ids: Sequence[str]
) -> Mapping[str, object]:
    split = rows["split"]
    donor = rows["donor"]
    truth = rows["truth"]
    predicted = rows["predicted"]
    confidence = rows["confidence"]
    abstained = rows["abstained"]
    primary_selected = split == "pediatric_primary"
    sensitivity_selected = split == "adult_age_shift_sensitivity"
    candidate_classes = tuple(
        class_id for class_id in class_ids if np.any(truth[primary_selected] == class_id)
    )
    if len(candidate_classes) < 2:
        raise ValueError("row evidence has fewer than two candidate model classes")
    primary_support = support_by_class_and_donor(
        truth[primary_selected], donor[primary_selected], candidate_classes, PRIMARY_DONORS
    )
    minimum_cells = SUPPORT_RULE["minimum_cells_per_primary_donor"]
    minimum_donors = SUPPORT_RULE["minimum_primary_donors"]
    unsupported = [
        class_id
        for class_id in candidate_classes
        if sum(count >= minimum_cells for count in primary_support[class_id].values())
        < minimum_donors
    ]
    if unsupported:
        raise ValueError("row evidence claims classes below the frozen donor-support rule")
    primary_metrics = summarize_predictions(
        truth[primary_selected],
        predicted[primary_selected],
        confidence[primary_selected],
        abstained[primary_selected],
        candidate_classes,
        calibration_bins=QUALITY_THRESHOLDS["calibration_bins"],
    )
    primary_per_donor = _per_donor_metrics(
        donor[primary_selected],
        truth[primary_selected],
        predicted[primary_selected],
        confidence[primary_selected],
        abstained[primary_selected],
        candidate_classes,
        PRIMARY_DONORS,
        primary_support,
    )

    type_decisions: dict[str, object] = {}
    passing_types: list[str] = []
    for class_id in candidate_classes:
        class_metrics = primary_metrics["per_class"][class_id]
        supported_donors = tuple(
            donor_id
            for donor_id in PRIMARY_DONORS
            if primary_support[class_id][donor_id] >= minimum_cells
        )
        donor_sensitivities = {
            donor_id: primary_per_donor[donor_id]["per_class"][class_id]["sensitivity"]
            for donor_id in supported_donors
        }
        reasons = []
        if class_metrics["f1"] < QUALITY_THRESHOLDS["minimum_fine_type_macro_f1"]:
            reasons.append("class_f1_below_0.70")
        if (
            class_metrics["sensitivity"]
            < QUALITY_THRESHOLDS["minimum_major_class_sensitivity"]
        ):
            reasons.append("class_sensitivity_below_0.50")
        if any(
            value < QUALITY_THRESHOLDS["minimum_major_class_sensitivity"]
            for value in donor_sensitivities.values()
        ):
            reasons.append("supported_donor_sensitivity_below_0.50")
        passed = not reasons
        if passed:
            passing_types.append(class_id)
        type_decisions[class_id] = {
            "status": "pass" if passed else "fail",
            "reasons": reasons,
            "supported_primary_donor_ids": list(supported_donors),
            "sensitivity_by_supported_primary_donor": donor_sensitivities,
        }

    passing = tuple(passing_types)
    qualified_selected = primary_selected & np.isin(truth, passing)
    qualified_metrics = None
    if len(passing) >= 2 and qualified_selected.any():
        qualified_metrics = summarize_predictions(
            truth[qualified_selected],
            predicted[qualified_selected],
            confidence[qualified_selected],
            abstained[qualified_selected],
            passing,
            calibration_bins=QUALITY_THRESHOLDS["calibration_bins"],
        )
    global_reasons = []
    if qualified_metrics is None:
        global_reasons.append("fewer_than_two_discrimination_qualified_types")
    else:
        if (
            qualified_metrics["fine_type_macro_f1"]
            < QUALITY_THRESHOLDS["minimum_fine_type_macro_f1"]
        ):
            global_reasons.append("fine_type_macro_f1_below_0.70")
        if (
            qualified_metrics["calibration_error"]
            > QUALITY_THRESHOLDS["maximum_multiclass_expected_calibration_error"]
        ):
            global_reasons.append("calibration_error_above_0.10")
        if (
            qualified_metrics["minimum_major_class_sensitivity"]
            < QUALITY_THRESHOLDS["minimum_major_class_sensitivity"]
        ):
            global_reasons.append("minimum_major_class_sensitivity_below_0.50")
        if (
            qualified_metrics["prediction_coverage"]
            < QUALITY_THRESHOLDS["minimum_prediction_coverage"]
        ):
            global_reasons.append("prediction_coverage_below_0.80")
    passed = not global_reasons

    sensitivity_classes = tuple(
        class_id
        for class_id in candidate_classes
        if np.any(sensitivity_selected & (truth == class_id))
    )
    sensitivity_metrics = None
    if sensitivity_classes:
        adult_rows = sensitivity_selected & np.isin(truth, sensitivity_classes)
        sensitivity_metrics = summarize_predictions(
            truth[adult_rows],
            predicted[adult_rows],
            confidence[adult_rows],
            abstained[adult_rows],
            sensitivity_classes,
            calibration_bins=QUALITY_THRESHOLDS["calibration_bins"],
        )
    return {
        "decision": {
            "status": "pass" if passed else "fail",
            "reason": (
                "external_v1_only_annotation_gate_passed"
                if passed
                else "external_v1_only_annotation_gate_failed_closed"
            ),
            "global_failure_reasons": global_reasons,
            "passing_model_classes_before_global_gate": list(passing),
            "qualified_model_classes_for_gse315411": list(passing) if passed else [],
            "authorizes_gse315411_annotation": passed,
        },
        "primary_validation": {
            **primary_metrics,
            "donor_ids": list(PRIMARY_DONORS),
            "cells": int(primary_selected.sum()),
            "candidate_model_classes": list(candidate_classes),
            "support_by_model_class_and_donor": primary_support,
            "per_donor_metrics": primary_per_donor,
        },
        "type_qualification": type_decisions,
        "qualified_type_global_metrics": qualified_metrics,
        "adult_age_shift_sensitivity": {
            "donor_ids": list(SENSITIVITY_DONORS),
            "candidate_model_classes_observed": list(sensitivity_classes),
            "metrics": sensitivity_metrics,
            "decision_role": "prespecified_sensitivity_not_a_substitute_for_primary_donors",
        },
    }


def validate_external_validation_receipt(
    value: Mapping[str, object],
    *,
    row_evidence_path: str | Path | None = None,
    mapping_path: str | Path | None = None,
    parity_receipt_path: str | Path | None = None,
) -> Mapping[str, object]:
    """Recompute the frozen gate from row evidence and reject unsupported claims."""

    receipt = _object(value, "external validation receipt")
    if set(receipt) != TOP_LEVEL_KEYS or receipt.get("schema") != SCHEMA:
        raise ValueError("unsupported external validation receipt schema or claims")
    _compare(receipt["quality_thresholds"], QUALITY_THRESHOLDS, "quality thresholds")
    _compare(receipt["support_rule"], SUPPORT_RULE, "support rule")

    source = _object(receipt["source_dataset"], "source dataset")
    if (
        source.get("accession") != "GSE274199"
        or source.get("h5ad_sha256") != EXPECTED_H5AD_SHA256
        or source.get("h5ad_bytes") != EXPECTED_H5AD_BYTES
        or source.get("cells") != 56_676
        or source.get("raw_count_shape") != [56_676, 27_320]
        or source.get("donor_ids") != sorted(PRIMARY_DONORS + SENSITIVITY_DONORS)
        or source.get("primary_pediatric_cells_all_labels") != 45_446
    ):
        raise ValueError("GSE274199 source identity differs from the frozen cohort")

    feature = _object(receipt["feature_audit"], "feature audit")
    expected_feature = {
        "v1_panel_gene_count": 480,
        "v1_panel_genes_present": 480,
        "supported_model_feature_count": 379,
        "supported_model_features_present": 379,
        "missing_v1_panel_genes": [],
        "missing_supported_model_features": [],
        "h5ad_feature_field": "raw.var.gene_symbols",
        "ordered_v1_panel_genes_sha256": EXPECTED_V1_GENES_SHA256,
        "ordered_supported_model_features_sha256": EXPECTED_SUPPORTED_GENES_SHA256,
    }
    _compare(feature, expected_feature, "feature audit")
    expected_model = {
        "source_model_sha256": (
            "6b0730537f4fee9f9a6195891a72635d1a3b9e21cade7a7481b2b14808070fdd"
        ),
        "weights_sha256": (
            "547cd698a176f3b0cc64acd431628c503742fe62e4b1466a3d3c49cc807fef8b"
        ),
        "normalization": "log1p_10000_over_exact_480_v1_genes",
        "normalization_target_sum": 10_000,
        "normalization_gene_count": 480,
        "missing_feature_rule": "omit_absent_model_features_without_imputation",
        "upper_z_clip": 10.0,
        "probability_semantics": "independent_one_vs_rest_sigmoid_not_simplex",
        "ordered_v1_panel_genes_sha256": EXPECTED_V1_GENES_SHA256,
        "ordered_supported_model_features_sha256": EXPECTED_SUPPORTED_GENES_SHA256,
        "supported_model_feature_count": 379,
        "class_count": 61,
    }
    _compare(receipt["model"], expected_model, "model identity")

    mapping_block = _object(receipt["mapping"], "mapping")
    mapping_file = Path(
        mapping_path if mapping_path is not None else str(mapping_block.get("path", ""))
    ).expanduser().resolve()
    if not mapping_file.is_file() or sha256_file(mapping_file) != EXPECTED_MAPPING_SHA256:
        raise ValueError("frozen ontology mapping bytes differ or are missing")
    mapping_config = _object(
        json.loads(mapping_file.read_text(encoding="utf-8")), "ontology mapping"
    )
    if (
        mapping_block.get("sha256") != EXPECTED_MAPPING_SHA256
        or mapping_block.get("schema") != mapping_config.get("schema")
        or mapping_block.get("frozen_before_expression_scoring") is not True
        or mapping_block.get("policy") != mapping_config.get("mapping_policy")
        or mapping_block.get("author_label_mapping")
        != mapping_config.get("author_label_mapping")
        or receipt["independence_and_label_provenance"]
        != mapping_config.get("independence_assessment")
        or receipt["quality_thresholds"] != mapping_config.get("quality_thresholds")
        or receipt["support_rule"] != mapping_config.get("support_rule")
    ):
        raise ValueError("receipt is not bound to the exact frozen ontology mapping")
    if set(mapping_block) != {
        "path",
        "sha256",
        "schema",
        "frozen_before_expression_scoring",
        "policy",
        "author_label_mapping",
        "unsupported_author_label_cell_counts",
    }:
        raise ValueError("ontology mapping block contains unsupported claims")
    unsupported_counts = _object(
        mapping_block["unsupported_author_label_cell_counts"], "unsupported label counts"
    )
    if any(type(count) is not int or count < 0 for count in unsupported_counts.values()):
        raise ValueError("unsupported-label counts are invalid")

    parity_block = _object(receipt["parity"], "parity")
    parity_file = Path(
        parity_receipt_path
        if parity_receipt_path is not None
        else str(parity_block.get("receipt_path", ""))
    ).expanduser().resolve()
    if not parity_file.is_file() or sha256_file(parity_file) != EXPECTED_PARITY_SHA256:
        raise ValueError("final official-vs-inert parity bytes differ or are missing")
    parity = _object(json.loads(parity_file.read_text(encoding="utf-8")), "parity receipt")
    if (
        parity_block.get("receipt_sha256") != EXPECTED_PARITY_SHA256
        or parity_block.get("schema") != "heir.celltypist_inert_official_parity.v1"
        or parity_block.get("status") != "pass"
        or parity_block.get("comparison") != parity.get("comparison")
        or parity.get("status") != "pass"
        or parity.get("production_pickle_loaded") is not False
        or parity.get("inert_model") != expected_model
    ):
        raise ValueError("receipt is not bound to the final passing inert parity result")

    execution = _object(receipt["execution"], "execution")
    expected_execution = {
        "production_pickle_loaded": False,
        "gse315411_molecular_data_loaded": False,
        "batch_size": 512,
        "worker_processes": 1,
        "visible_cpu_affinity": [29],
        "gpu_used": False,
        "implementation_sha256": {
            "runner": "5223190f47f38bd30f18ae03894f3bbbeb0fe8a436c8000f21dd88abb0b246f3",
            "inert_scorer": (
                "03c9ac5963a28810d76b6aa2e839d51a918e735ac5f2961a0c033bbbc485727b"
            ),
            "metrics": "77e4be2bf2be220d09ad3a5af7ff7d637d95ad736ce4d9d5a3c925ac6b36da40",
        },
    }
    _compare(execution, expected_execution, "execution identity")

    row_block = _object(receipt["row_level_evidence"], "row evidence")
    row_file = Path(
        row_evidence_path if row_evidence_path is not None else str(row_block.get("path", ""))
    ).expanduser().resolve()
    if not row_file.is_file() or sha256_file(row_file) != EXPECTED_ROWS_SHA256:
        raise ValueError("row-level validation evidence bytes differ or are missing")
    class_ids = row_block.get("probability_vector_order")
    if (
        type(class_ids) is not list
        or len(class_ids) != 61
        or len(set(class_ids)) != 61
        or canonical_sha256(class_ids) != EXPECTED_CLASS_IDS_SHA256
    ):
        raise ValueError("CellTypist class order differs from the frozen model")
    expected_row_block = {
        "path": str(row_block.get("path")),
        "sha256": EXPECTED_ROWS_SHA256,
        "rows": EXPECTED_ROWS,
        "columns": list(VALIDATION_COLUMNS),
        "row_order": "validation_split_then_donor_then_cell_id",
        "probability_vector_order": class_ids,
        "probability_semantics": "official_independent_one_vs_rest_sigmoid_not_simplex",
    }
    _compare(row_block, expected_row_block, "row evidence identity")
    rows = _read_rows(
        row_file,
        class_ids=class_ids,
        author_mapping=_object(mapping_config["author_label_mapping"], "author label mapping"),
    )
    if len(rows["truth"]) != EXPECTED_ROWS:
        raise ValueError("row-level evidence count differs from its frozen identity")
    recomputed = _recompute_claims(rows, class_ids)
    for key, expected in recomputed.items():
        _compare(receipt[key], expected, key)
    return receipt


__all__ = ["SCHEMA", "validate_external_validation_receipt"]
