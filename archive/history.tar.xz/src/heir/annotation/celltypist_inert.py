"""Inert, V1-panel-only inference for exported CellTypist linear models.

This module deliberately has no pickle or CellTypist import path.  It accepts
only the numeric NPZ and JSON receipt emitted by :mod:`celltypist_export`.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import tarfile
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence, Union

import numpy as np

from .celltypist_export import (
    OFFICIAL_HUMAN_LUNG_ATLAS_V2_SHA256,
)
from .celltypist_export import (
    SCHEMA as EXPORT_RECEIPT_SCHEMA,
)

PathLike = Union[str, os.PathLike]
V1_PANEL_SIZE = 480
V1_SUPPORTED_MODEL_FEATURES = 379
OFFICIAL_GSE315411_V1_PROBE_ARCHIVE_SHA256 = (
    "af61de99923262eadc5ad8c88ca56a19902f92ff125620271cda4531d1de23c0"
)
NORMALIZATION_ID = "log1p_10000_over_exact_480_v1_genes"
MISSING_FEATURE_RULE = "omit_absent_model_features_without_imputation"
UPPER_Z_CLIP = 10.0

DEFAULT_V1_PROBE_MEMBERS = (
    "xenium_probes/43R3RN_hLung_50g_probe_sequences.fasta",
    "xenium_probes/6ZAAWG_hLung_380g_probe_sequences.fasta",
    "xenium_probes/6ZX7JP_hLung_50g_probe_sequences.fasta",
)
_EXPECTED_MEMBER_GENE_COUNTS = (50, 380, 50)
_FASTA_HEADER = re.compile(rb"^>([^ ]+) \(ENSG[0-9]+\) \|")
_ARRAY_NAMES = {
    "coefficient_matrix",
    "intercepts",
    "scaler_mean",
    "scaler_scale",
    "scaler_variance",
}


def sha256_file(path: PathLike) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_sha256(value: object) -> str:
    encoded = json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def read_v1_panel_genes(
    probe_archive: PathLike,
    members: Sequence[str] = DEFAULT_V1_PROBE_MEMBERS,
    *,
    expected_sha256: str = OFFICIAL_GSE315411_V1_PROBE_ARCHIVE_SHA256,
) -> tuple[str, ...]:
    """Read the three V1 FASTA members without extracting the tar archive."""

    archive_path = Path(probe_archive).expanduser().resolve()
    if sha256_file(archive_path) != expected_sha256:
        raise ValueError("V1 probe archive differs from its frozen SHA-256")
    if tuple(members) != DEFAULT_V1_PROBE_MEMBERS:
        raise ValueError("V1 probe member identity differs from the frozen three-member panel")
    ordered: list[str] = []
    with tarfile.open(archive_path, mode="r:gz") as archive:
        available = {member.name for member in archive.getmembers() if member.isfile()}
        if not set(members).issubset(available):
            raise ValueError("V1 probe archive lacks a frozen FASTA member")
        for member_name, expected_count in zip(members, _EXPECTED_MEMBER_GENE_COUNTS):
            handle = archive.extractfile(member_name)
            if handle is None:
                raise ValueError("V1 probe FASTA member is unreadable")
            member_genes: list[str] = []
            for line in handle:
                if not line.startswith(b">"):
                    continue
                match = _FASTA_HEADER.match(line)
                if match is None:
                    raise ValueError("V1 probe FASTA contains an unexpected header")
                gene = match.group(1).decode("ascii")
                if gene not in member_genes:
                    member_genes.append(gene)
            if len(member_genes) != expected_count:
                raise ValueError("V1 probe member gene count differs from the frozen panel")
            ordered.extend(member_genes)
    if len(ordered) != V1_PANEL_SIZE or len(set(ordered)) != V1_PANEL_SIZE:
        raise ValueError("V1 panel must contain exactly 480 unique ordered genes")
    return tuple(ordered)


def _ordered_strings(value: object, label: str) -> tuple[str, ...]:
    if type(value) is not list:
        raise ValueError(f"{label} must be a JSON list")
    result = tuple(str(item) for item in value)
    if not result or any(not item for item in result) or len(set(result)) != len(result):
        raise ValueError(f"{label} must contain unique non-empty strings")
    return result


def _stable_sigmoid(values: np.ndarray) -> np.ndarray:
    result = np.empty(values.shape, dtype=np.float64)
    nonnegative = values >= 0
    result[nonnegative] = 1.0 / (1.0 + np.exp(-values[nonnegative]))
    exponential = np.exp(values[~nonnegative])
    result[~nonnegative] = exponential / (1.0 + exponential)
    return result


@dataclass(frozen=True)
class InertPrediction:
    decision_scores: np.ndarray
    raw_sigmoid_probabilities: np.ndarray
    predicted_class_indices: np.ndarray
    predicted_labels: np.ndarray
    confidences: np.ndarray
    valid_library_mask: np.ndarray


@dataclass(frozen=True)
class InertCellTypistModel:
    classes: tuple[str, ...]
    model_features: tuple[str, ...]
    panel_genes: tuple[str, ...]
    supported_features: tuple[str, ...]
    coefficient_matrix: np.ndarray
    intercepts: np.ndarray
    scaler_mean: np.ndarray
    scaler_scale: np.ndarray
    supported_model_indices: np.ndarray
    supported_panel_indices: np.ndarray
    source_model_sha256: str
    weights_sha256: str

    @classmethod
    def load(
        cls,
        weights_path: PathLike,
        receipt_path: PathLike,
        panel_genes: Sequence[str],
        *,
        require_official_human_lung_v2: bool = True,
    ) -> "InertCellTypistModel":
        weights = Path(weights_path).expanduser().resolve()
        receipt_file = Path(receipt_path).expanduser().resolve()
        receipt = json.loads(receipt_file.read_text(encoding="utf-8"))
        if type(receipt) is not dict or receipt.get("schema") != EXPORT_RECEIPT_SCHEMA:
            raise ValueError("CellTypist inert receipt schema is invalid")
        source = receipt.get("source")
        weights_meta = receipt.get("weights")
        if type(source) is not dict or type(weights_meta) is not dict:
            raise ValueError("CellTypist inert receipt lacks source or weights metadata")
        source_sha = str(source.get("verified_sha256", ""))
        if source_sha != str(source.get("expected_sha256", "")):
            raise ValueError("CellTypist source hash was not verified")
        if require_official_human_lung_v2 and source_sha != OFFICIAL_HUMAN_LUNG_ATLAS_V2_SHA256:
            raise ValueError("inert model is not the pinned Human Lung Atlas v2")
        if receipt.get("pickle_required_for_production_inference") is not False:
            raise ValueError("inert receipt does not prohibit production pickle use")

        features = _ordered_strings(receipt.get("ordered_feature_ids"), "model features")
        classes = _ordered_strings(receipt.get("ordered_class_ids"), "model classes")
        if receipt.get("ordered_feature_ids_sha256") != canonical_sha256(list(features)):
            raise ValueError("ordered model features differ from their receipt hash")
        if receipt.get("ordered_class_ids_sha256") != canonical_sha256(list(classes)):
            raise ValueError("ordered model classes differ from their receipt hash")
        panel = tuple(str(gene) for gene in panel_genes)
        if len(panel) != V1_PANEL_SIZE or len(set(panel)) != V1_PANEL_SIZE:
            raise ValueError("production panel must contain exactly 480 unique genes")

        actual_weights_sha = sha256_file(weights)
        if actual_weights_sha != weights_meta.get("sha256"):
            raise ValueError("inert NPZ differs from its export receipt")
        with np.load(weights, allow_pickle=False) as archive:
            if set(archive.files) != _ARRAY_NAMES:
                raise ValueError("inert NPZ contains an unexpected array set")
            arrays = {name: np.asarray(archive[name]) for name in _ARRAY_NAMES}
        if any(array.dtype.kind not in "fiu" for array in arrays.values()):
            raise ValueError("inert NPZ arrays must be numeric")
        if any(not np.isfinite(array).all() for array in arrays.values()):
            raise ValueError("inert NPZ arrays must be finite")

        coefficients = arrays["coefficient_matrix"]
        intercepts = arrays["intercepts"]
        mean = arrays["scaler_mean"]
        scale = arrays["scaler_scale"]
        variance = arrays["scaler_variance"]
        if (
            coefficients.ndim != 2
            or intercepts.ndim != 1
            or mean.ndim != 1
            or scale.ndim != 1
            or variance.ndim != 1
            or coefficients.shape[1] != len(features)
            or len(mean) != len(features)
            or len(scale) != len(features)
            or len(variance) != len(features)
            or coefficients.shape[0] != len(intercepts)
            or coefficients.shape[0] != len(classes)
            or np.any(scale <= 0)
            or np.any(variance < 0)
        ):
            raise ValueError("inert model array dimensions are inconsistent")
        normalization = receipt.get("normalization")
        if normalization != {"with_mean": True, "with_std": True}:
            raise ValueError("Human Lung Atlas v2 scaler contract changed")

        panel_index = {gene: index for index, gene in enumerate(panel)}
        supported_model = np.asarray(
            [index for index, gene in enumerate(features) if gene in panel_index], dtype=np.int64
        )
        supported = tuple(features[index] for index in supported_model.tolist())
        supported_panel = np.asarray([panel_index[gene] for gene in supported], dtype=np.int64)
        if require_official_human_lung_v2 and len(supported) != V1_SUPPORTED_MODEL_FEATURES:
            raise ValueError("Human Lung Atlas v2/V1 overlap is not exactly 379 features")

        return cls(
            classes=classes,
            model_features=features,
            panel_genes=panel,
            supported_features=supported,
            coefficient_matrix=np.asarray(coefficients[:, supported_model], dtype=np.float64),
            intercepts=np.asarray(intercepts, dtype=np.float64),
            scaler_mean=np.asarray(mean[supported_model], dtype=np.float64),
            scaler_scale=np.asarray(scale[supported_model], dtype=np.float64),
            supported_model_indices=supported_model,
            supported_panel_indices=supported_panel,
            source_model_sha256=source_sha,
            weights_sha256=actual_weights_sha,
        )

    def predict_raw_counts(self, counts_480: np.ndarray) -> InertPrediction:
        """Apply the frozen 480-gene normalization and official linear scorer."""

        counts = np.asarray(counts_480)
        if counts.ndim != 2 or counts.shape[1] != V1_PANEL_SIZE:
            raise ValueError("raw counts must have shape (cells, 480)")
        if counts.dtype.kind not in "fiu" or not np.isfinite(counts).all():
            raise ValueError("raw counts must be finite numeric values")
        if np.any(counts < 0):
            raise ValueError("raw counts must be non-negative")
        if not np.equal(counts, np.floor(counts)).all():
            raise ValueError("raw counts must be integer-valued")
        counts = np.asarray(counts, dtype=np.float64)
        library_sizes = counts.sum(axis=1)
        valid = library_sizes > 0
        normalized = np.zeros(counts.shape, dtype=np.float64)
        normalized[valid] = np.log1p(counts[valid] * (10000.0 / library_sizes[valid, np.newaxis]))
        values = normalized[:, self.supported_panel_indices]
        scaled = (values - self.scaler_mean) / self.scaler_scale
        np.minimum(scaled, UPPER_Z_CLIP, out=scaled)
        scores = scaled @ self.coefficient_matrix.T + self.intercepts
        probabilities = _stable_sigmoid(scores)
        predicted_indices = scores.argmax(axis=1)
        labels = np.asarray(self.classes, dtype="U")[predicted_indices]
        confidences = probabilities[np.arange(len(probabilities)), predicted_indices]
        # A zero V1 library has no defensible prediction even though the affine
        # model can produce one from scaler offsets and intercepts.
        labels = labels.astype(object)
        labels[~valid] = "__ABSTAIN__"
        confidences = confidences.copy()
        confidences[~valid] = 0.0
        return InertPrediction(
            decision_scores=scores,
            raw_sigmoid_probabilities=probabilities,
            predicted_class_indices=predicted_indices,
            predicted_labels=labels,
            confidences=confidences,
            valid_library_mask=valid,
        )

    def identity(self) -> Mapping[str, object]:
        return {
            "source_model_sha256": self.source_model_sha256,
            "weights_sha256": self.weights_sha256,
            "normalization": NORMALIZATION_ID,
            "normalization_target_sum": 10000,
            "normalization_gene_count": len(self.panel_genes),
            "missing_feature_rule": MISSING_FEATURE_RULE,
            "upper_z_clip": UPPER_Z_CLIP,
            "probability_semantics": "independent_one_vs_rest_sigmoid_not_simplex",
            "ordered_v1_panel_genes_sha256": canonical_sha256(list(self.panel_genes)),
            "ordered_supported_model_features_sha256": canonical_sha256(
                list(self.supported_features)
            ),
            "supported_model_feature_count": len(self.supported_features),
            "class_count": len(self.classes),
        }


def multiclass_expected_calibration_error(
    confidences: np.ndarray,
    correct: np.ndarray,
    *,
    bin_count: int = 10,
) -> float:
    confidences = np.asarray(confidences, dtype=np.float64)
    correct = np.asarray(correct, dtype=np.float64)
    if confidences.ndim != 1 or correct.shape != confidences.shape or not len(confidences):
        raise ValueError("calibration inputs must be non-empty aligned vectors")
    if not np.isfinite(confidences).all() or np.any((confidences < 0) | (confidences > 1)):
        raise ValueError("calibration confidences must lie in [0, 1]")
    if bin_count <= 0:
        raise ValueError("calibration bin count must be positive")
    indices = np.minimum((confidences * bin_count).astype(np.int64), bin_count - 1)
    error = 0.0
    for index in range(bin_count):
        selected = indices == index
        if selected.any():
            error += float(selected.mean()) * abs(
                float(correct[selected].mean()) - float(confidences[selected].mean())
            )
    if not math.isfinite(error):
        raise ValueError("calibration error is not finite")
    return error


__all__ = [
    "DEFAULT_V1_PROBE_MEMBERS",
    "InertCellTypistModel",
    "InertPrediction",
    "MISSING_FEATURE_RULE",
    "NORMALIZATION_ID",
    "OFFICIAL_GSE315411_V1_PROBE_ARCHIVE_SHA256",
    "UPPER_Z_CLIP",
    "V1_PANEL_SIZE",
    "V1_SUPPORTED_MODEL_FEATURES",
    "canonical_sha256",
    "multiclass_expected_calibration_error",
    "read_v1_panel_genes",
    "sha256_file",
]
