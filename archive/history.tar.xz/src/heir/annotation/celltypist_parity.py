"""No-network parity check between official CellTypist and inert inference."""

from __future__ import annotations

import csv
import json
import os
import resource
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Mapping, Union

import numpy as np

from .celltypist_export import OFFICIAL_HUMAN_LUNG_ATLAS_V2_SHA256
from .celltypist_export import _publish_noreplace as _publish_noreplace
from .celltypist_inert import (
    InertCellTypistModel,
    canonical_sha256,
    sha256_file,
)

PathLike = Union[str, os.PathLike]
SCHEMA = "heir.celltypist_inert_official_parity.v1"
SYNTHETIC_SEED = 315411
SYNTHETIC_ROWS = 16
MAX_SCORE_ABSOLUTE_ERROR = 2.0e-5
MAX_PROBABILITY_ABSOLUTE_ERROR = 5.0e-6


def deterministic_synthetic_counts(rows: int = SYNTHETIC_ROWS) -> np.ndarray:
    if rows < 4:
        raise ValueError("parity requires at least four synthetic rows")
    rng = np.random.default_rng(SYNTHETIC_SEED)
    counts = rng.negative_binomial(2, 0.35, size=(rows, 480)).astype(np.int64)
    counts[0] = 1
    counts[1] = np.arange(480, dtype=np.int64) % 17
    counts[2] = (np.arange(480, dtype=np.int64) % 29 == 0) * 100
    counts[3] = (np.arange(480, dtype=np.int64)[::-1] % 11) ** 2
    if np.any(counts.sum(axis=1) == 0):
        raise RuntimeError("synthetic parity generator produced a zero library")
    return counts


def _write_tsv(path: Path, counts: np.ndarray, genes: tuple[str, ...]) -> None:
    with path.open("x", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow([""] + list(genes))
        for index, row in enumerate(counts):
            writer.writerow([f"synthetic-{index:03d}"] + row.tolist())


def _limits() -> None:
    resource.setrlimit(resource.RLIMIT_CPU, (120, 120))
    resource.setrlimit(resource.RLIMIT_AS, (8 * 1024**3, 8 * 1024**3))
    resource.setrlimit(resource.RLIMIT_FSIZE, (64 * 1024**2, 64 * 1024**2))
    resource.setrlimit(resource.RLIMIT_NOFILE, (128, 128))


def _atomic_json(path: Path, payload: Mapping[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, raw = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        _publish_noreplace(Path(raw), path)
        Path(raw).unlink()
    except BaseException:
        Path(raw).unlink(missing_ok=True)
        raise


def run_official_parity(
    *,
    model: InertCellTypistModel,
    source_pickle: PathLike,
    official_python: PathLike,
    celltypist_package_root: PathLike,
    output_receipt: PathLike,
    bwrap_executable: PathLike = "bwrap",
) -> Mapping[str, object]:
    source = Path(source_pickle).expanduser().resolve()
    python = Path(official_python).expanduser().resolve()
    package_root = Path(celltypist_package_root).expanduser().resolve()
    receipt_path = Path(output_receipt).expanduser().resolve()
    if sha256_file(source) != OFFICIAL_HUMAN_LUNG_ATLAS_V2_SHA256:
        raise ValueError("parity source is not the pinned official model")
    if not python.is_file() or not package_root.is_dir():
        raise FileNotFoundError("official parity Python/package root is unavailable")
    bwrap = shutil.which(str(bwrap_executable))
    if bwrap is None:
        raise RuntimeError("bubblewrap is required for official CellTypist parity")
    runtime = python.parent.parent
    worker = Path(__file__).with_name("_celltypist_parity_worker.py").resolve()
    scorer = Path(__file__).with_name("celltypist_inert.py").resolve()
    orchestrator = Path(__file__).resolve()
    counts = deterministic_synthetic_counts()
    inert_prediction = model.predict_raw_counts(counts)

    receipt_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(
        prefix="heir-celltypist-parity-", dir=receipt_path.parent
    ) as raw:
        root = Path(raw)
        input_tsv = root / "synthetic.tsv"
        output = root / "output"
        output.mkdir()
        _write_tsv(input_tsv, counts, model.panel_genes)
        command = [
            bwrap,
            "--unshare-all",
            "--new-session",
            "--die-with-parent",
            "--cap-drop",
            "ALL",
        ]
        for system_path in (Path("/usr"), Path("/lib"), Path("/lib64")):
            if system_path.exists():
                command.extend(("--ro-bind", str(system_path), str(system_path)))
        command.extend(
            (
                "--ro-bind",
                str(runtime),
                "/runtime",
                "--ro-bind",
                str(package_root),
                "/celltypist",
                "--ro-bind",
                str(worker),
                "/worker.py",
                "--dir",
                "/input",
                "--ro-bind",
                str(source),
                "/input/model.pkl",
                "--ro-bind",
                str(input_tsv),
                "/input/synthetic.tsv",
                "--bind",
                str(output),
                "/output",
                "--proc",
                "/proc",
                "--dev",
                "/dev",
                "--tmpfs",
                "/tmp",
                "--clearenv",
                "--setenv",
                "PATH",
                "/runtime/bin:/usr/bin",
                "--setenv",
                "PYTHONPATH",
                "/celltypist",
                "--setenv",
                "PYTHONNOUSERSITE",
                "1",
                "--setenv",
                "PYTHONHASHSEED",
                "0",
                "--setenv",
                "HOME",
                "/tmp",
                "--setenv",
                "CELLTYPIST_FOLDER",
                "/tmp/celltypist",
                "--chdir",
                "/tmp",
                f"/runtime/bin/{python.name}",
                "/worker.py",
                "--source",
                "/input/model.pkl",
                "--expected-sha256",
                OFFICIAL_HUMAN_LUNG_ATLAS_V2_SHA256,
                "--input-tsv",
                "/input/synthetic.tsv",
                "--output-dir",
                "/output",
            )
        )
        completed = subprocess.run(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
            text=True,
            timeout=180,
            preexec_fn=_limits,
        )
        if completed.returncode != 0:
            detail = completed.stdout[-4000:].strip()
            raise RuntimeError(f"official CellTypist parity worker failed: {detail}")
        metadata_path = output / "official.json"
        arrays_path = output / "official.npz"
        if set(path.name for path in output.iterdir()) != {"official.json", "official.npz"}:
            raise ValueError("official parity worker produced unexpected files")
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        with np.load(arrays_path, allow_pickle=False) as archive:
            if set(archive.files) != {"scores", "probabilities"}:
                raise ValueError("official parity NPZ contains unexpected arrays")
            official_scores = np.asarray(archive["scores"], dtype=np.float64)
            official_probabilities = np.asarray(archive["probabilities"], dtype=np.float64)

    official_labels = tuple(str(value) for value in metadata["labels"])
    official_classes = tuple(str(value) for value in metadata["class_order"])
    inert_labels = tuple(str(value) for value in inert_prediction.predicted_labels)
    expected_rows = tuple(f"synthetic-{index:03d}" for index in range(len(counts)))
    if (
        official_scores.shape != inert_prediction.decision_scores.shape
        or official_probabilities.shape != inert_prediction.raw_sigmoid_probabilities.shape
        or official_classes != model.classes
        or tuple(metadata["row_order"]) != expected_rows
    ):
        raise ValueError("official and inert parity output scopes differ")
    score_error = float(np.max(np.abs(official_scores - inert_prediction.decision_scores)))
    probability_error = float(
        np.max(np.abs(official_probabilities - inert_prediction.raw_sigmoid_probabilities))
    )
    agreement_count = sum(left == right for left, right in zip(official_labels, inert_labels))
    passed = (
        score_error <= MAX_SCORE_ABSOLUTE_ERROR
        and probability_error <= MAX_PROBABILITY_ABSOLUTE_ERROR
        and agreement_count == len(counts)
    )
    receipt = {
        "schema": SCHEMA,
        "status": "pass" if passed else "fail",
        "production_pickle_loaded": False,
        "official_pickle_use": "parity_only_no_network_bubblewrap_worker",
        "official_model_sha256": OFFICIAL_HUMAN_LUNG_ATLAS_V2_SHA256,
        "inert_model": dict(model.identity()),
        "official_runtime": {
            "celltypist_version": metadata["celltypist_version"],
            "sklearn_version": metadata["sklearn_version"],
            "network_interface_names": metadata["network_interface_names"],
        },
        "implementation_sha256": {
            "inert_scorer": sha256_file(scorer),
            "parity_orchestrator": sha256_file(orchestrator),
            "official_parity_worker": sha256_file(worker),
        },
        "synthetic_input": {
            "seed": SYNTHETIC_SEED,
            "rows": len(counts),
            "columns": counts.shape[1],
            "raw_count_matrix_sha256": canonical_sha256(counts.tolist()),
            "ordered_panel_genes_sha256": canonical_sha256(list(model.panel_genes)),
        },
        "comparison": {
            "maximum_decision_score_absolute_error": score_error,
            "maximum_raw_sigmoid_probability_absolute_error": probability_error,
            "exact_best_match_label_agreement_count": agreement_count,
            "exact_best_match_label_agreement_fraction": agreement_count / len(counts),
            "score_error_threshold": MAX_SCORE_ABSOLUTE_ERROR,
            "probability_error_threshold": MAX_PROBABILITY_ABSOLUTE_ERROR,
        },
    }
    _atomic_json(receipt_path, receipt)
    if not passed:
        raise RuntimeError("inert CellTypist parity failed")
    return receipt


__all__ = [
    "MAX_PROBABILITY_ABSOLUTE_ERROR",
    "MAX_SCORE_ABSOLUTE_ERROR",
    "SCHEMA",
    "deterministic_synthetic_counts",
    "run_official_parity",
]
