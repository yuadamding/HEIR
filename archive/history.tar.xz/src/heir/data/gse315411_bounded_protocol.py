"""Fail-closed custody and exposure-stratified split contracts for GSE315411."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Dict, Mapping, Sequence, Tuple, Union

from heir.data.experiment_manifest import canonical_sha256

PathLike = Union[str, Path]

CUSTODY_RECEIPT_SCHEMA = "heir.independent_molecular_custody_receipt.v1"
EXPOSURE_MAP_SCHEMA = "heir.molecular_exposure_classification.v1"
SPLIT_RECEIPT_SCHEMA = "heir.exposure_stratified_split_receipt.v1"

COHORT = "GSE315411"
PROTOCOL_ID = "gse315411_bounded_same_section_cell_state_v1"
CORE_UNIVERSE_SHA256 = "8353c9b1f95b666e9ce5b57af6b0c24430a27d9960de1e3a8dea77cb4e36f199"
CELL_STATS_SHA256 = "15a40b7311b79c2b7cbab76cbadeed27f853ed77cf88ed31ec679e24470bc910"
SUPPLEMENTAL_TABLES_SHA256 = (
    "a2e3953a0cc6b3c8f0432f8053d903c801463971fbbc775a6043008730ce02bf"
)

CORE_IDS: Tuple[str, ...] = (
    "PDL018D",
    "PDL026A",
    "PDL029A",
    "PDL031A",
    "PDL032D",
    "PDL033T",
    "PDL034D",
    "PDL040A",
    "PDL042D",
    "PDL047T",
    "PDL055T",
    "PDL061",
    "PDL072",
    "PDL077",
    "PDL085A",
    "PDL095D",
    "PDL097",
)

EXPOSURE_CLASSES: Tuple[str, ...] = (
    "none",
    "study-level-only",
    "sample-specific-summary",
    "raw-or-processed-molecular",
)
_EXPOSURE_RANK = {value: index for index, value in enumerate(EXPOSURE_CLASSES)}
_SUMMARY_EXPOSURE_RANK = _EXPOSURE_RANK["sample-specific-summary"]
KNOWN_ANALYST_VISIBLE_EXPOSURES = frozenset({"PDL018D", "PDL026A", "PDL034D"})
SPLIT_ALGORITHM = "sha256-nul-delimited-exposure-stratified-10-5-2-v1"

_CUSTODY_FIELDS = {
    "schema",
    "protocol_id",
    "cohort",
    "cell_stats_sha256",
    "supplemental_tables_sha256",
    "analysis_account_identity",
    "custodian_identity",
    "custodian_is_independent",
    "analysis_account_has_read_access",
    "analysis_environment_readable_copies_removed",
    "development_payload_separately_releasable",
    "locked_payload_separately_releasable",
    "access_logging_enabled",
    "access_log_append_only",
    "receipt_sha256",
}
_EXPOSURE_MAP_FIELDS = {
    "schema",
    "protocol_id",
    "cohort",
    "core_universe_sha256",
    "custody_receipt_sha256",
    "custodian_identity",
    "all_public_sample_level_material_audited",
    "underlying_molecular_values_disclosed_to_analysis_account",
    "classifications",
    "receipt_sha256",
}


def _reject_duplicate_keys(pairs: Sequence[Tuple[str, object]]) -> Dict[str, object]:
    result: Dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("receipt JSON contains duplicate key %s" % key)
        result[key] = value
    return result


def load_json_receipt(path: PathLike) -> Mapping[str, object]:
    """Load a JSON receipt while rejecting ambiguous duplicate object keys."""

    resolved = Path(path).expanduser().resolve()
    try:
        value = json.loads(
            resolved.read_text(encoding="utf-8"), object_pairs_hook=_reject_duplicate_keys
        )
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError("receipt is not valid readable JSON") from error
    if not isinstance(value, Mapping):
        raise ValueError("receipt must be a JSON object")
    return value


def receipt_sha256(value: Mapping[str, object]) -> str:
    """Hash all canonical receipt content except the self-referential digest field."""

    content = dict(value)
    content.pop("receipt_sha256", None)
    return canonical_sha256(content)


def _exact_fields(value: Mapping[str, object], expected: set[str], label: str) -> None:
    missing = sorted(expected - set(value))
    extra = sorted(set(value) - expected)
    if missing or extra:
        raise ValueError("%s fields differ (missing=%s, extra=%s)" % (label, missing, extra))


def _sha256(value: object, label: str) -> str:
    digest = value if isinstance(value, str) else ""
    if len(digest) != 64 or any(character not in "0123456789abcdef" for character in digest):
        raise ValueError("%s must be a lowercase SHA-256" % label)
    return digest


def _identity(value: object, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("%s must be a non-empty string" % label)
    if value != value.strip():
        raise ValueError("%s must not contain surrounding whitespace" % label)
    return value


def _require_literal(value: object, expected: object, label: str) -> None:
    differs = value is not expected if isinstance(expected, bool) else value != expected
    if differs:
        raise ValueError("%s must equal %r" % (label, expected))


def _validate_embedded_digest(value: Mapping[str, object], label: str) -> None:
    observed = _sha256(value.get("receipt_sha256"), "%s receipt_sha256" % label)
    expected = receipt_sha256(value)
    if observed != expected:
        raise ValueError("%s receipt_sha256 does not bind its canonical content" % label)


def validate_custody_receipt(value: Mapping[str, object]) -> Mapping[str, object]:
    """Validate the minimum independent-custody claims required before splitting."""

    if not isinstance(value, Mapping):
        raise ValueError("custody receipt must be a mapping")
    _exact_fields(value, _CUSTODY_FIELDS, "custody receipt")
    _require_literal(value["schema"], CUSTODY_RECEIPT_SCHEMA, "custody receipt schema")
    _require_literal(value["protocol_id"], PROTOCOL_ID, "custody receipt protocol_id")
    _require_literal(value["cohort"], COHORT, "custody receipt cohort")
    _require_literal(
        _sha256(value["cell_stats_sha256"], "custody cell_stats_sha256"),
        CELL_STATS_SHA256,
        "custody cell_stats_sha256",
    )
    _require_literal(
        _sha256(value["supplemental_tables_sha256"], "custody supplemental_tables_sha256"),
        SUPPLEMENTAL_TABLES_SHA256,
        "custody supplemental_tables_sha256",
    )

    analysis_identity = _identity(
        value["analysis_account_identity"], "custody analysis_account_identity"
    )
    custodian_identity = _identity(value["custodian_identity"], "custody custodian_identity")
    if analysis_identity == custodian_identity:
        raise ValueError("custody custodian_identity must differ from analysis_account_identity")

    required_true = (
        "custodian_is_independent",
        "analysis_environment_readable_copies_removed",
        "development_payload_separately_releasable",
        "locked_payload_separately_releasable",
        "access_logging_enabled",
        "access_log_append_only",
    )
    for field in required_true:
        if value[field] is not True:
            raise ValueError("custody %s must be true" % field)
    if value["analysis_account_has_read_access"] is not False:
        raise ValueError("custody analysis_account_has_read_access must be false")

    _validate_embedded_digest(value, "custody")
    return dict(value)


def validate_exposure_map(
    value: Mapping[str, object], custody_receipt: Mapping[str, object]
) -> Mapping[str, object]:
    """Validate a complete custodian classification without accepting underlying values."""

    custody = validate_custody_receipt(custody_receipt)
    if not isinstance(value, Mapping):
        raise ValueError("exposure map must be a mapping")
    _exact_fields(value, _EXPOSURE_MAP_FIELDS, "exposure map")
    _require_literal(value["schema"], EXPOSURE_MAP_SCHEMA, "exposure map schema")
    _require_literal(value["protocol_id"], PROTOCOL_ID, "exposure map protocol_id")
    _require_literal(value["cohort"], COHORT, "exposure map cohort")
    _require_literal(
        _sha256(value["core_universe_sha256"], "exposure map core_universe_sha256"),
        CORE_UNIVERSE_SHA256,
        "exposure map core_universe_sha256",
    )
    _require_literal(
        _sha256(value["custody_receipt_sha256"], "exposure map custody_receipt_sha256"),
        custody["receipt_sha256"],
        "exposure map custody_receipt_sha256",
    )
    _require_literal(
        _identity(value["custodian_identity"], "exposure map custodian_identity"),
        custody["custodian_identity"],
        "exposure map custodian_identity",
    )
    if value["all_public_sample_level_material_audited"] is not True:
        raise ValueError("exposure map all_public_sample_level_material_audited must be true")
    if value["underlying_molecular_values_disclosed_to_analysis_account"] is not False:
        raise ValueError(
            "exposure map underlying_molecular_values_disclosed_to_analysis_account must be false"
        )

    rows = value["classifications"]
    if not isinstance(rows, list):
        raise ValueError("exposure map classifications must be a list")
    classifications: Dict[str, str] = {}
    for index, row in enumerate(rows):
        if not isinstance(row, Mapping) or set(row) != {"core_id", "exposure_class"}:
            raise ValueError("exposure map classification %d has invalid fields" % index)
        core_id = _identity(row["core_id"], "exposure map core_id")
        exposure_class = _identity(row["exposure_class"], "exposure map exposure_class")
        if core_id in classifications:
            raise ValueError("exposure map contains duplicate core_id %s" % core_id)
        if exposure_class not in _EXPOSURE_RANK:
            raise ValueError("exposure map has unsupported exposure_class %s" % exposure_class)
        classifications[core_id] = exposure_class
    if set(classifications) != set(CORE_IDS):
        missing = sorted(set(CORE_IDS) - set(classifications))
        extra = sorted(set(classifications) - set(CORE_IDS))
        raise ValueError(
            "exposure map must classify the exact 17-core universe (missing=%s, extra=%s)"
            % (missing, extra)
        )
    for core_id in KNOWN_ANALYST_VISIBLE_EXPOSURES:
        if _EXPOSURE_RANK[classifications[core_id]] < _SUMMARY_EXPOSURE_RANK:
            raise ValueError("exposure map attempts to downgrade known exposure for %s" % core_id)

    _validate_embedded_digest(value, "exposure map")
    return dict(value)


def split_sort_sha256(core_id: str) -> str:
    """Return the exact NUL-delimited ordering digest frozen by the protocol."""

    if core_id not in CORE_IDS:
        raise ValueError("split core_id is outside the frozen universe")
    payload = (
        PROTOCOL_ID.encode("utf-8")
        + b"\0"
        + b"exposure_stratified_split"
        + b"\0"
        + core_id.encode("utf-8")
    )
    return hashlib.sha256(payload).hexdigest()


def generate_exposure_stratified_split(
    custody_receipt: Mapping[str, object], exposure_map: Mapping[str, object]
) -> Mapping[str, object]:
    """Create the one frozen 10/5/2 split, rejecting an ineligible exposure map."""

    custody = validate_custody_receipt(custody_receipt)
    exposure = validate_exposure_map(exposure_map, custody)
    classification_by_core = {
        str(row["core_id"]): str(row["exposure_class"])
        for row in exposure["classifications"]  # type: ignore[union-attr]
    }
    exposed = [
        core_id
        for core_id in CORE_IDS
        if _EXPOSURE_RANK[classification_by_core[core_id]] >= _SUMMARY_EXPOSURE_RANK
    ]
    unexposed = [core_id for core_id in CORE_IDS if core_id not in set(exposed)]
    unexposed.sort(key=lambda core_id: (split_sort_sha256(core_id), core_id))

    if len(exposed) > 10:
        raise ValueError("exposure-stratified split requires no more than 10 exposed cores")
    additional_development = 10 - len(exposed)
    if len(unexposed) < additional_development + 7:
        raise ValueError(
            "exposure-stratified split lacks unexposed cores for development "
            "plus 5 locked and 2 reserve"
        )

    development = exposed + unexposed[:additional_development]
    locked_start = additional_development
    locked = unexposed[locked_start : locked_start + 5]
    reserve = unexposed[locked_start + 5 : locked_start + 7]
    assigned = development + locked + reserve
    if (
        len(development) != 10
        or len(locked) != 5
        or len(reserve) != 2
        or len(set(assigned)) != 17
        or set(assigned) != set(CORE_IDS)
    ):
        raise RuntimeError("exposure-stratified split violated the frozen 10/5/2 invariant")
    if any(
        _EXPOSURE_RANK[classification_by_core[core_id]] >= _SUMMARY_EXPOSURE_RANK
        for core_id in locked + reserve
    ):
        raise RuntimeError("exposure-stratified split placed an exposed core outside development")

    result: Dict[str, object] = {
        "schema": SPLIT_RECEIPT_SCHEMA,
        "protocol_id": PROTOCOL_ID,
        "cohort": COHORT,
        "algorithm": SPLIT_ALGORITHM,
        "core_universe_sha256": CORE_UNIVERSE_SHA256,
        "custody_receipt_sha256": custody["receipt_sha256"],
        "exposure_map_receipt_sha256": exposure["receipt_sha256"],
        "exposed_development": exposed,
        "unexposed_hash_order": unexposed,
        "development": development,
        "locked_evaluation": locked,
        "reserve": reserve,
        "reserve_replacement_policy": {
            "allowed_only_before_locked_molecular_release": True,
            "allowed_reason": "prespecified_outcome_blind_asset_failure",
            "order": "fixed_hash_order",
            "immutable_replacement_receipt_required": True,
            "permitted_after_locked_prime_target_access": False,
        },
        "molecular_release_authorized": False,
    }
    result["receipt_sha256"] = receipt_sha256(result)
    return result


__all__ = [
    "CELL_STATS_SHA256",
    "COHORT",
    "CORE_IDS",
    "CORE_UNIVERSE_SHA256",
    "CUSTODY_RECEIPT_SCHEMA",
    "EXPOSURE_CLASSES",
    "EXPOSURE_MAP_SCHEMA",
    "KNOWN_ANALYST_VISIBLE_EXPOSURES",
    "PROTOCOL_ID",
    "SPLIT_ALGORITHM",
    "SPLIT_RECEIPT_SCHEMA",
    "SUPPLEMENTAL_TABLES_SHA256",
    "generate_exposure_stratified_split",
    "load_json_receipt",
    "receipt_sha256",
    "split_sort_sha256",
    "validate_custody_receipt",
    "validate_exposure_map",
]
