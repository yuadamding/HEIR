"""Outcome-free archive and routing preflight for the bounded GSE315411 protocol.

This module intentionally cannot qualify Phase 3.  It inventories the final H&E
archive, binds explicit core routing and TMA coordinates, and emits a pending
receipt listing the image/registration evidence that still has to be frozen.
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import tarfile
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import BinaryIO, Dict, List, Mapping, Optional, Sequence, Tuple, Union

import numpy as np

from heir.data.experiment_manifest import canonical_sha256
from heir.data.gse315411_bounded_protocol import (
    COHORT,
    CORE_IDS,
    CORE_UNIVERSE_SHA256,
    PROTOCOL_ID,
    receipt_sha256,
)

PathLike = Union[str, Path]

IMAGE_ROUTING_SCHEMA = "heir.gse315411_image_routing.v1"
IMAGE_QUALIFICATION_RECEIPT_SCHEMA = (
    "heir.gse315411_image_registration_qualification_receipt.v1"
)
ARCHIVE_FINAL_NAME = "GSE315411_HE_images.tar.gz"
ARCHIVE_EXPECTED_BYTES = 35_204_235_163
TMA_COORDINATES_FINAL_NAME = "GSE315411_TMA_coords.csv"
TMA_COORDINATES_SHA256 = (
    "e720a2ef0c9161627f023823597e3f122073524f8d5abdc80910711f2dd443fe"
)
TMA_COORDINATE_RECORDS_SHA256 = (
    "df2a2ac9b5c5f3919e05e5b6f8917e2fd50f858f4ded44d722499ff724f7c1aa"
)
TMA_COORDINATE_RECORD_COUNT = 107
V1_ALIGNMENT_ARCHIVE_FINAL_NAME = (
    "GSM9427183_Xen0069259_NB_PDLTMA6-10_v1_alignment_files.tar.gz"
)
V1_ALIGNMENT_ARCHIVE_EXPECTED_BYTES = 1_850
V1_ALIGNMENT_ARCHIVE_SHA256 = (
    "0023f01b23aaeeb80b118b5e0739b571e92bffdd8a991ebfb37a5ec019c13b56"
)
V1_ALIGNMENT_MEMBER_MANIFEST_SHA256 = (
    "744f2ef785767c2e77ca5e19138a777868693ddac08eb5808526328bca5e7efb"
)
V1_ALIGNMENT_ARCHIVE_URL = (
    "https://ftp.ncbi.nlm.nih.gov/geo/samples/GSM9427nnn/GSM9427183/suppl/"
    "GSM9427183_Xen0069259_NB_PDLTMA6-10_v1_alignment_files.tar.gz"
)
V1_ALIGNMENT_KEYPOINTS_CONTENT_SHA256 = (
    "57621597e38f4aecd0fefaca0f80ac951812ec43d042060ad232ade2f6c3ee20"
)
V1_ALIGNMENT_MATRIX_CONTENT_SHA256 = (
    "8f1fb3b901ea6c77cfc64f8a72815700037ece39c6b17423f91fe6c75d171a1b"
)
V1_ALIGNMENT_KEYPOINT_RECORDS_SHA256 = (
    "5a9916b34681cbf5c204733da737faa1c28006ce97fcf9f4b4f86662e1b8d63c"
)
V1_ALIGNMENT_MATRIX_VALUES_SHA256 = (
    "c30374112ea08bba692fc2042573f21699f1cd9486ae2fa5262b71e9060901b7"
)
V1_ALIGNMENT_KEYPOINT_COUNT = 37
MAX_ARCHIVE_MEMBERS = 100_000
MAX_TOTAL_UNCOMPRESSED_BYTES = 1 << 40
MAX_ARCHIVE_EXPANSION_RATIO = 8
HOPTIMUS1_ENCODER_MANIFEST_SHA256 = (
    "f6852288e1ae146a4865bf19e38ce994c0be9ce1c2bfa09bdf77747043ac8fd9"
)
HOPTIMUS1_CHECKPOINT_SHA256 = (
    "c4f1e5b457ddf00679626053b0bf2899be6a19c3a04ad191c87ad1cdfd1abfe1"
)
PRIOR_WHITE_BLANK_RECEIPT_SHA256 = (
    "41917b39c0e50f27e252d76a4507e0a7599591e00c09b25074f49b9413bbd962"
)
PRIOR_WHITE_BLANK_FEATURE_SHA256 = (
    "d81926fd76fef69e9e59b8777e068a008716eedbf939b0b85ef1e4018b57df6f"
)
PRIOR_WHITE_BLANK_INPUT_SHA256 = (
    "dc8992e8c4431b762dad21613e71acc85cc736c9bb305b23f4e5805ffdf7c8ea"
)

REQUIRED_CROP_ARMS: Tuple[str, ...] = (
    "natural_112um",
    "nucleus_mask_112um",
    "cell_mask_112um",
    "target_cell_removed_112um",
    "real_white_blank_112um",
    "natural_32um_sensitivity",
    "natural_64um_sensitivity",
    "context_annuli_if_geometry_eligible",
)

MISSING_REQUIRED_EVIDENCE: Tuple[str, ...] = (
    "V1_alignment_archive_identity_and_member_inventory",
    "scanner_metadata",
    "microns_per_pixel",
    "V1_cell_segmentation_identity",
    "V1_nucleus_segmentation_identity",
    "H_and_E_to_Xenium_transforms",
    "transform_coordinate_frame_and_direction_declaration",
    "tissue_masks",
    "cell_masks",
    "nucleus_masks",
    "cell_centered_crop_geometry",
    "crop_padding",
    "registration_quality_definitions",
    "registration_QC_results",
    "cell_and_landmark_residual_QC_thresholds_and_results",
    "guarded_spatial_block_definitions",
    "observation_cell_and_block_hashes",
    "natural_112um_crop_arm",
    "nucleus_mask_112um_crop_arm",
    "cell_mask_112um_crop_arm",
    "target_cell_removed_112um_crop_arm",
    "real_white_blank_112um_crop_arm",
    "natural_32um_sensitivity_crop_arm",
    "natural_64um_sensitivity_crop_arm",
    "context_annuli_geometry_eligibility_and_arm_disposition",
)

TMA_SELECTION_BY_CORE: Mapping[str, str] = {
    core_id: "PDLTMA006_%s_prime_with_V1_segmentation" % core_id for core_id in CORE_IDS
}

_ROUTING_FIELDS = {
    "schema",
    "protocol_id",
    "cohort",
    "core_universe_sha256",
    "archive_sha256",
    "tma_coordinates_sha256",
    "routes",
}
_ROUTE_FIELDS = {"core_id", "image_member_path", "tma_selection_name"}


class _HashingReader:
    """Hash compressed bytes as tarfile consumes them without a second archive pass."""

    def __init__(self, handle: BinaryIO) -> None:
        self._handle = handle
        self._digest = hashlib.sha256()
        self.bytes_read = 0

    def read(self, size: int = -1) -> bytes:
        block = self._handle.read(size)
        if block:
            self._digest.update(block)
            self.bytes_read += len(block)
        return block

    def hexdigest(self) -> str:
        return self._digest.hexdigest()


def _sha256(value: object, label: str) -> str:
    digest = value if isinstance(value, str) else ""
    if len(digest) != 64 or any(character not in "0123456789abcdef" for character in digest):
        raise ValueError("%s must be a lowercase SHA-256" % label)
    return digest


def _exact_fields(value: Mapping[str, object], fields: set[str], label: str) -> None:
    missing = sorted(fields - set(value))
    extra = sorted(set(value) - fields)
    if missing or extra:
        raise ValueError("%s fields differ (missing=%s, extra=%s)" % (label, missing, extra))


def _reject_duplicate_keys(pairs: Sequence[Tuple[str, object]]) -> Dict[str, object]:
    result: Dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("routing JSON contains duplicate key %s" % key)
        result[key] = value
    return result


def _reject_nonfinite_json(value: str) -> object:
    raise ValueError("routing JSON contains non-finite value %s" % value)


def _read_small_file(path: Path, *, maximum_bytes: int, label: str) -> bytes:
    try:
        size = path.stat().st_size
    except OSError as error:
        raise ValueError("%s is not a readable regular file" % label) from error
    if not path.is_file() or size <= 0 or size > maximum_bytes:
        raise ValueError(
            "%s must be a nonempty regular file of at most %d bytes" % (label, maximum_bytes)
        )
    try:
        payload = path.read_bytes()
    except OSError as error:
        raise ValueError("%s is not readable" % label) from error
    if len(payload) != size:
        raise ValueError("%s changed while it was read" % label)
    return payload


def _canonical_member_path(name: str) -> str:
    if not name or "\x00" in name or "\\" in name or len(name) > 4096:
        raise ValueError("tar member has an unsafe or empty path")
    windows = PureWindowsPath(name)
    path = PurePosixPath(name)
    if windows.drive or windows.is_absolute() or path.is_absolute() or ".." in path.parts:
        raise ValueError("tar member path escapes the archive root: %s" % name)
    normalized = path.as_posix().rstrip("/")
    while normalized.startswith("./"):
        normalized = normalized[2:]
    if normalized in {"", "."}:
        raise ValueError("tar member has an empty normalized path")
    return normalized


def _member_kind(member: tarfile.TarInfo) -> str:
    if member.issym():
        raise ValueError("tar archive contains a symbolic link: %s" % member.name)
    if member.islnk():
        raise ValueError("tar archive contains a hard link: %s" % member.name)
    if member.ischr() or member.isblk():
        raise ValueError("tar archive contains a device member: %s" % member.name)
    if member.isfifo():
        raise ValueError("tar archive contains a FIFO member: %s" % member.name)
    if member.isdir():
        if member.size != 0:
            raise ValueError("tar directory member has a nonzero size: %s" % member.name)
        return "directory"
    if member.isfile():
        if member.issparse():
            raise ValueError("tar archive contains a sparse member: %s" % member.name)
        return "file"
    raise ValueError("tar archive contains an unsupported member type: %s" % member.name)


def inspect_safe_tar_archive(
    archive_path: PathLike,
    *,
    expected_bytes: int,
    supplied_sha256: str,
    maximum_members: int = MAX_ARCHIVE_MEMBERS,
    maximum_uncompressed_bytes: int = MAX_TOTAL_UNCOMPRESSED_BYTES,
) -> Mapping[str, object]:
    """Inspect and hash a gzip tar archive in one compressed-byte pass, without extraction."""

    archive = Path(archive_path).expanduser().resolve()
    expected_digest = _sha256(supplied_sha256, "supplied archive SHA-256")
    if (
        not isinstance(expected_bytes, int)
        or isinstance(expected_bytes, bool)
        or expected_bytes <= 0
    ):
        raise ValueError("expected archive bytes must be a positive integer")
    if not isinstance(maximum_members, int) or maximum_members <= 0:
        raise ValueError("maximum archive members must be positive")
    if not isinstance(maximum_uncompressed_bytes, int) or maximum_uncompressed_bytes <= 0:
        raise ValueError("maximum uncompressed bytes must be positive")
    effective_uncompressed_limit = min(
        maximum_uncompressed_bytes, expected_bytes * MAX_ARCHIVE_EXPANSION_RATIO
    )
    try:
        metadata = archive.stat()
    except OSError as error:
        raise ValueError("tar archive is not a readable final file") from error
    if not archive.is_file() or metadata.st_size != expected_bytes:
        raise ValueError(
            "tar archive byte count differs (expected=%d, observed=%d)"
            % (expected_bytes, metadata.st_size)
        )

    members: List[Dict[str, object]] = []
    seen_paths: Dict[str, str] = {}
    total_uncompressed = 0
    file_count = 0
    directory_count = 0
    reader: Optional[_HashingReader] = None
    try:
        with archive.open("rb") as raw_handle:
            reader = _HashingReader(raw_handle)
            with tarfile.open(fileobj=reader, mode="r|gz") as tar:
                for index, member in enumerate(tar):
                    if index >= maximum_members:
                        raise ValueError("tar archive exceeds the frozen member safety limit")
                    path = _canonical_member_path(member.name)
                    if path in seen_paths:
                        raise ValueError("tar archive contains duplicate normalized path %s" % path)
                    kind = _member_kind(member)
                    if member.size < 0:
                        raise ValueError("tar member has a negative size: %s" % member.name)
                    total_uncompressed += int(member.size)
                    if total_uncompressed > effective_uncompressed_limit:
                        raise ValueError("tar archive exceeds the uncompressed-byte safety limit")

                    content_sha256: Optional[str] = None
                    if kind == "file":
                        extracted = tar.extractfile(member)
                        if extracted is None:
                            raise ValueError(
                                "tar regular member cannot be streamed: %s" % member.name
                            )
                        digest = hashlib.sha256()
                        observed_size = 0
                        for block in iter(lambda: extracted.read(8 * 1024 * 1024), b""):
                            digest.update(block)
                            observed_size += len(block)
                        if observed_size != member.size:
                            raise ValueError(
                                "tar member size differs while streaming: %s" % member.name
                            )
                        content_sha256 = digest.hexdigest()
                        file_count += 1
                    else:
                        directory_count += 1

                    seen_paths[path] = kind
                    members.append(
                        {
                            "index": index,
                            "archive_name": member.name,
                            "path": path,
                            "type": kind,
                            "size_bytes": int(member.size),
                            "content_sha256": content_sha256,
                        }
                    )

            # tarfile may stop at the end-of-archive marker before consuming trailing
            # compressed bytes. Drain only the raw wrapper so the digest binds the file.
            for _block in iter(lambda: reader.read(8 * 1024 * 1024), b""):
                pass
    except (OSError, EOFError, tarfile.TarError) as error:
        raise ValueError("archive is not a complete readable gzip tar") from error

    if reader is None or reader.bytes_read != expected_bytes:
        raise ValueError("tar archive changed or was not fully read during inspection")
    observed_digest = reader.hexdigest()
    if observed_digest != expected_digest:
        raise ValueError("tar archive SHA-256 differs from the supplied digest")
    if not members or file_count == 0:
        raise ValueError("tar archive contains no regular file members")

    for path, kind in seen_paths.items():
        for parent in PurePosixPath(path).parents:
            parent_path = parent.as_posix()
            if parent_path == ".":
                break
            if parent_path in seen_paths and seen_paths[parent_path] != "directory":
                raise ValueError(
                    "tar archive has a file/directory path collision at %s" % parent_path
                )

    return {
        "expected_bytes": expected_bytes,
        "observed_bytes": metadata.st_size,
        "supplied_sha256": expected_digest,
        "observed_sha256": observed_digest,
        "member_count": len(members),
        "file_count": file_count,
        "directory_count": directory_count,
        "total_uncompressed_bytes": total_uncompressed,
        "uncompressed_byte_safety_limit": effective_uncompressed_limit,
        "member_manifest_sha256": canonical_sha256(members),
        "members": members,
    }


def _read_exact_tar_members(
    archive_path: Path, expected_paths: Sequence[str], *, maximum_member_bytes: int
) -> Mapping[str, bytes]:
    expected = set(expected_paths)
    payloads: Dict[str, bytes] = {}
    try:
        with tarfile.open(archive_path, mode="r:gz") as archive:
            for member in archive:
                path = _canonical_member_path(member.name)
                if path not in expected:
                    continue
                if not member.isfile() or member.size <= 0 or member.size > maximum_member_bytes:
                    raise ValueError("alignment member is not a bounded regular file: %s" % path)
                handle = archive.extractfile(member)
                if handle is None:
                    raise ValueError("alignment member cannot be read: %s" % path)
                payload = handle.read(maximum_member_bytes + 1)
                if len(payload) != member.size or len(payload) > maximum_member_bytes:
                    raise ValueError("alignment member size changed while reading: %s" % path)
                if path in payloads:
                    raise ValueError("alignment archive contains duplicate member %s" % path)
                payloads[path] = payload
    except (OSError, EOFError, tarfile.TarError) as error:
        raise ValueError("V1 alignment archive cannot be safely reopened") from error
    if set(payloads) != expected:
        missing = sorted(expected - set(payloads))
        raise ValueError("V1 alignment archive lacks exact required members %s" % missing)
    return payloads


def _parse_alignment_keypoints(payload: bytes) -> Mapping[str, object]:
    try:
        text = payload.decode("utf-8-sig")
    except UnicodeDecodeError as error:
        raise ValueError("alignment keypoints are not valid UTF-8") from error
    reader = csv.DictReader(io.StringIO(text))
    fields = ["fixedX", "fixedY", "alignmentX", "alignmentY"]
    if reader.fieldnames != fields:
        raise ValueError("alignment keypoint header differs from the exact four-column schema")
    records: List[Dict[str, str]] = []
    numeric: List[List[float]] = []
    for index, row in enumerate(reader):
        if set(row) != set(fields) or any(value is None for value in row.values()):
            raise ValueError("alignment keypoint row %d is malformed" % (index + 1))
        record: Dict[str, str] = {}
        values: List[float] = []
        for field in fields:
            text_value = str(row[field])
            if not text_value or text_value != text_value.strip():
                raise ValueError("alignment keypoint contains an empty or padded value")
            try:
                number = float(text_value)
            except ValueError as error:
                raise ValueError("alignment keypoint contains a nonnumeric value") from error
            if not math.isfinite(number) or number < 0:
                raise ValueError("alignment keypoint contains an invalid coordinate")
            record[field] = text_value
            values.append(number)
        records.append(record)
        numeric.append(values)
    if len(records) < 3:
        raise ValueError("alignment requires at least three point correspondences")
    array = np.asarray(numeric, dtype=np.float64)
    if len(np.unique(array[:, :2], axis=0)) != len(array) or len(
        np.unique(array[:, 2:], axis=0)
    ) != len(array):
        raise ValueError("alignment keypoints contain duplicate fixed or alignment points")
    return {
        "content_sha256": hashlib.sha256(payload).hexdigest(),
        "records_sha256": canonical_sha256(records),
        "correspondence_count": len(records),
        "columns": fields,
        "fixed_bounds": {
            "x_min": float(array[:, 0].min()),
            "x_max": float(array[:, 0].max()),
            "y_min": float(array[:, 1].min()),
            "y_max": float(array[:, 1].max()),
        },
        "alignment_bounds": {
            "x_min": float(array[:, 2].min()),
            "x_max": float(array[:, 2].max()),
            "y_min": float(array[:, 3].min()),
            "y_max": float(array[:, 3].max()),
        },
        "_numeric": array,
    }


def _residual_summary(values: np.ndarray) -> Mapping[str, float]:
    distances = np.asarray(values, dtype=np.float64)
    return {
        "minimum": float(distances.min()),
        "median": float(np.median(distances)),
        "mean": float(distances.mean()),
        "root_mean_square": float(np.sqrt(np.mean(np.square(distances)))),
        "maximum": float(distances.max()),
    }


def _parse_alignment_matrix(
    payload: bytes, keypoint_numeric: np.ndarray
) -> Mapping[str, object]:
    try:
        text = payload.decode("utf-8-sig")
    except UnicodeDecodeError as error:
        raise ValueError("alignment matrix is not valid UTF-8") from error
    rows = list(csv.reader(io.StringIO(text)))
    if len(rows) != 3 or any(len(row) != 3 for row in rows):
        raise ValueError("alignment matrix must be exactly 3 by 3")
    values: List[List[float]] = []
    for row in rows:
        numeric_row: List[float] = []
        for text_value in row:
            if not text_value or text_value != text_value.strip():
                raise ValueError("alignment matrix contains an empty or padded value")
            try:
                number = float(text_value)
            except ValueError as error:
                raise ValueError("alignment matrix contains a nonnumeric value") from error
            if not math.isfinite(number):
                raise ValueError("alignment matrix contains a non-finite value")
            numeric_row.append(number)
        values.append(numeric_row)
    matrix = np.asarray(values, dtype=np.float64)
    if not np.array_equal(matrix[2], np.asarray([0.0, 0.0, 1.0])):
        raise ValueError("alignment matrix is not a 2D affine homogeneous transform")
    linear = matrix[:2, :2]
    linear_rank = int(np.linalg.matrix_rank(linear))
    homogeneous_rank = int(np.linalg.matrix_rank(matrix))
    determinant = float(np.linalg.det(linear))
    condition = float(np.linalg.cond(linear))
    if (
        linear_rank != 2
        or homogeneous_rank != 3
        or not math.isfinite(determinant)
        or abs(determinant) <= 1e-12
        or not math.isfinite(condition)
        or condition > 1e12
    ):
        raise ValueError("alignment matrix is singular or numerically non-invertible")
    inverse = np.linalg.inv(matrix)
    fixed = keypoint_numeric[:, :2]
    alignment = keypoint_numeric[:, 2:]

    def transform(points: np.ndarray, transform_matrix: np.ndarray) -> np.ndarray:
        homogeneous = np.column_stack([points, np.ones(len(points), dtype=np.float64)])
        mapped = homogeneous @ transform_matrix.T
        if np.any(np.abs(mapped[:, 2]) <= 1e-12):
            raise ValueError("alignment transform maps a keypoint to infinity")
        return mapped[:, :2] / mapped[:, 2, None]

    alignment_to_fixed = np.linalg.norm(transform(alignment, matrix) - fixed, axis=1)
    fixed_to_alignment = np.linalg.norm(transform(fixed, inverse) - alignment, axis=1)
    singular_values = np.linalg.svd(linear, compute_uv=False)
    return {
        "content_sha256": hashlib.sha256(payload).hexdigest(),
        "values_sha256": canonical_sha256(rows),
        "shape": [3, 3],
        "transform_class": "2D_affine_homogeneous",
        "linear_rank": linear_rank,
        "homogeneous_rank": homogeneous_rank,
        "linear_determinant": determinant,
        "orientation_preserving": determinant > 0,
        "linear_condition_number": condition,
        "linear_singular_values": [float(value) for value in singular_values],
        "translation": [float(value) for value in matrix[:2, 2]],
        "invertible": True,
        "candidate_direction_diagnostics": {
            "alignment_xy_to_fixed_xy_using_matrix": _residual_summary(alignment_to_fixed),
            "fixed_xy_to_alignment_xy_using_inverse": _residual_summary(fixed_to_alignment),
            "coordinate_units": "unresolved_pending_scanner_metadata_and_microns_per_pixel",
            "qualifies_registration_accuracy": False,
        },
    }


def inspect_v1_alignment_archive(
    archive_path: PathLike, *, expected_bytes: int, supplied_sha256: str
) -> Mapping[str, object]:
    """Safely inventory and validate the exact outcome-free alignment CSV structures."""

    archive = Path(archive_path).expanduser().resolve()
    inventory = inspect_safe_tar_archive(
        archive,
        expected_bytes=expected_bytes,
        supplied_sha256=supplied_sha256,
    )
    root = "Xen0069259_NB_PDLTMA6-10_v1_alignment_files"
    keypoints_path = root + "/keypoints.csv"
    matrix_path = root + "/matrix.csv"
    expected_files = {keypoints_path, matrix_path}
    observed_files = {
        str(member["path"])
        for member in inventory["members"]  # type: ignore[union-attr]
        if member["type"] == "file"
    }
    if observed_files != expected_files:
        raise ValueError("V1 alignment archive file members differ from the exact allowlist")
    payloads = _read_exact_tar_members(
        archive, sorted(expected_files), maximum_member_bytes=1024 * 1024
    )
    keypoints = dict(_parse_alignment_keypoints(payloads[keypoints_path]))
    numeric = keypoints.pop("_numeric")
    if not isinstance(numeric, np.ndarray):
        raise RuntimeError("alignment keypoint parser lost its numeric matrix")
    matrix = _parse_alignment_matrix(payloads[matrix_path], numeric)
    return {
        **dict(inventory),
        "keypoints": keypoints,
        "matrix": matrix,
        "transform_integrity_valid": True,
        "registration_accuracy_qualified": False,
    }


def _load_routing(path: Path) -> Tuple[Mapping[str, object], str]:
    payload = _read_small_file(path, maximum_bytes=4 * 1024 * 1024, label="routing manifest")
    digest = hashlib.sha256(payload).hexdigest()
    try:
        value = json.loads(
            payload.decode("utf-8"),
            object_pairs_hook=_reject_duplicate_keys,
            parse_constant=_reject_nonfinite_json,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError("routing manifest is not valid UTF-8 JSON") from error
    if not isinstance(value, Mapping):
        raise ValueError("routing manifest must be a JSON object")
    return value, digest


def _load_tma_coordinates(path: Path) -> Mapping[str, object]:
    payload = _read_small_file(
        path, maximum_bytes=16 * 1024 * 1024, label="TMA-coordinate file"
    )
    raw_digest = hashlib.sha256(payload).hexdigest()
    try:
        text = payload.decode("utf-8-sig")
    except UnicodeDecodeError as error:
        raise ValueError("TMA-coordinate file is not valid UTF-8") from error
    data_lines = [line for line in text.splitlines() if line and not line.startswith("#")]
    reader = csv.DictReader(io.StringIO("\n".join(data_lines)))
    if reader.fieldnames != ["Selection", "X", "Y"]:
        raise ValueError("TMA-coordinate CSV header must be exactly Selection,X,Y")

    records: List[Dict[str, str]] = []
    points_by_selection: Dict[str, List[Tuple[float, float]]] = {}
    for index, row in enumerate(reader):
        if set(row) != {"Selection", "X", "Y"} or any(value is None for value in row.values()):
            raise ValueError("TMA-coordinate row %d is malformed" % (index + 1))
        selection = str(row["Selection"])
        x_text = str(row["X"])
        y_text = str(row["Y"])
        if not selection or selection != selection.strip():
            raise ValueError("TMA-coordinate row has an empty or padded selection name")
        if x_text != x_text.strip() or y_text != y_text.strip():
            raise ValueError("TMA-coordinate values must not contain surrounding whitespace")
        try:
            x_value = float(x_text)
            y_value = float(y_text)
        except ValueError as error:
            raise ValueError("TMA-coordinate row contains a nonnumeric point") from error
        if not math.isfinite(x_value) or not math.isfinite(y_value) or x_value < 0 or y_value < 0:
            raise ValueError("TMA-coordinate row contains an invalid point")
        records.append({"selection": selection, "x": x_text, "y": y_text})
        points_by_selection.setdefault(selection, []).append((x_value, y_value))

    if not records:
        raise ValueError("TMA-coordinate file contains no coordinate records")
    expected_selections = set(TMA_SELECTION_BY_CORE.values())
    if set(points_by_selection) != expected_selections:
        missing = sorted(expected_selections - set(points_by_selection))
        extra = sorted(set(points_by_selection) - expected_selections)
        raise ValueError(
            "TMA-coordinate selections differ from the exact 17-core universe "
            "(missing=%s, extra=%s)" % (missing, extra)
        )
    for selection, points in points_by_selection.items():
        if len(points) < 4 or len(set(points)) < 3:
            raise ValueError("TMA-coordinate polygon is degenerate for %s" % selection)

    return {
        "raw_file_sha256": raw_digest,
        "coordinate_records_sha256": canonical_sha256(records),
        "record_count": len(records),
        "selection_count": len(points_by_selection),
        "points_per_selection": {
            selection: len(points_by_selection[selection])
            for selection in sorted(points_by_selection)
        },
    }


def _validate_routing(
    value: Mapping[str, object],
    *,
    archive: Mapping[str, object],
    coordinates: Mapping[str, object],
) -> List[Dict[str, object]]:
    _exact_fields(value, _ROUTING_FIELDS, "routing manifest")
    if value["schema"] != IMAGE_ROUTING_SCHEMA:
        raise ValueError("routing manifest schema is unsupported")
    if value["protocol_id"] != PROTOCOL_ID or value["cohort"] != COHORT:
        raise ValueError("routing manifest protocol or cohort differs")
    if value["core_universe_sha256"] != CORE_UNIVERSE_SHA256:
        raise ValueError("routing manifest core universe differs")
    if _sha256(value["archive_sha256"], "routing archive_sha256") != archive["observed_sha256"]:
        raise ValueError("routing manifest archive SHA-256 differs")
    if (
        _sha256(value["tma_coordinates_sha256"], "routing tma_coordinates_sha256")
        != coordinates["raw_file_sha256"]
    ):
        raise ValueError("routing manifest TMA-coordinate SHA-256 differs")

    rows = value["routes"]
    if not isinstance(rows, list):
        raise ValueError("routing manifest routes must be a list")
    member_by_path = {
        str(member["path"]): member
        for member in archive["members"]  # type: ignore[union-attr]
    }
    route_by_core: Dict[str, Dict[str, object]] = {}
    seen_selections: set[str] = set()
    for index, row in enumerate(rows):
        if not isinstance(row, Mapping):
            raise ValueError("routing row %d must be an object" % index)
        _exact_fields(row, _ROUTE_FIELDS, "routing row %d" % index)
        core_id = row["core_id"] if isinstance(row["core_id"], str) else ""
        member_path = row["image_member_path"] if isinstance(row["image_member_path"], str) else ""
        selection = row["tma_selection_name"] if isinstance(row["tma_selection_name"], str) else ""
        if core_id in route_by_core:
            raise ValueError("routing manifest contains duplicate core_id %s" % core_id)
        if core_id not in CORE_IDS:
            raise ValueError("routing manifest contains an unknown core_id %s" % core_id)
        if not member_path or _canonical_member_path(member_path) != member_path:
            raise ValueError("routing image_member_path must be an exact canonical member path")
        member = member_by_path.get(member_path)
        if member is None or member["type"] != "file":
            raise ValueError(
                "routing image member is not a regular archive member: %s" % member_path
            )
        expected_selection = TMA_SELECTION_BY_CORE[core_id]
        if selection != expected_selection:
            raise ValueError(
                "routing TMA selection differs from the frozen mapping for %s" % core_id
            )
        if selection in seen_selections:
            raise ValueError("routing manifest reuses TMA selection %s" % selection)
        seen_selections.add(selection)
        route_by_core[core_id] = {
            "core_id": core_id,
            "image_member_path": member_path,
            "image_member_content_sha256": member["content_sha256"],
            "tma_selection_name": selection,
        }

    if set(route_by_core) != set(CORE_IDS) or len(rows) != len(CORE_IDS):
        missing = sorted(set(CORE_IDS) - set(route_by_core))
        extra = sorted(set(route_by_core) - set(CORE_IDS))
        raise ValueError(
            "routing manifest must map the exact 17-core universe once "
            "(missing=%s, extra=%s)" % (missing, extra)
        )
    if seen_selections != set(TMA_SELECTION_BY_CORE.values()):
        raise ValueError("routing manifest does not bind every frozen TMA selection exactly once")
    return [route_by_core[core_id] for core_id in CORE_IDS]


def _build_pending_image_qualification_receipt(
    *,
    archive_path: PathLike,
    supplied_archive_sha256: str,
    routing_path: PathLike,
    tma_coordinates_path: PathLike,
    expected_archive_bytes: int,
    v1_alignment_archive_path: Optional[PathLike] = None,
    supplied_v1_alignment_sha256: Optional[str] = None,
    expected_v1_alignment_bytes: Optional[int] = None,
) -> Mapping[str, object]:
    archive = inspect_safe_tar_archive(
        archive_path,
        expected_bytes=expected_archive_bytes,
        supplied_sha256=supplied_archive_sha256,
    )
    coordinates_path = Path(tma_coordinates_path).expanduser().resolve()
    coordinates = _load_tma_coordinates(coordinates_path)
    routing_file = Path(routing_path).expanduser().resolve()
    routing, routing_sha256 = _load_routing(routing_file)
    routes = _validate_routing(routing, archive=archive, coordinates=coordinates)

    alignment_arguments = (
        v1_alignment_archive_path,
        supplied_v1_alignment_sha256,
        expected_v1_alignment_bytes,
    )
    if any(value is not None for value in alignment_arguments) and not all(
        value is not None for value in alignment_arguments
    ):
        raise ValueError(
            "V1 alignment archive path, SHA-256, and expected bytes must be supplied together"
        )
    alignment: Dict[str, object]
    missing_evidence = list(MISSING_REQUIRED_EVIDENCE)
    if all(value is not None for value in alignment_arguments):
        alignment_path = Path(str(v1_alignment_archive_path)).expanduser().resolve()
        if (
            alignment_path.name != V1_ALIGNMENT_ARCHIVE_FINAL_NAME
            or alignment_path.name.endswith(".part")
        ):
            raise ValueError(
                "V1 alignment qualification requires the exact final archive filename, never .part"
            )
        alignment_inventory = inspect_v1_alignment_archive(
            alignment_path,
            expected_bytes=int(expected_v1_alignment_bytes),  # type: ignore[arg-type]
            supplied_sha256=str(supplied_v1_alignment_sha256),
        )
        alignment = {
            "status": "archive_inventory_verified",
            "source_sample": "GSM9427183",
            "source_url": V1_ALIGNMENT_ARCHIVE_URL,
            **dict(alignment_inventory),
        }
        missing_evidence.remove("V1_alignment_archive_identity_and_member_inventory")
    else:
        alignment = {
            "status": "missing",
            "expected_final_filename": V1_ALIGNMENT_ARCHIVE_FINAL_NAME,
            "expected_bytes": V1_ALIGNMENT_ARCHIVE_EXPECTED_BYTES,
            "expected_sha256": V1_ALIGNMENT_ARCHIVE_SHA256,
            "expected_member_manifest_sha256": V1_ALIGNMENT_MEMBER_MANIFEST_SHA256,
            "expected_keypoints_content_sha256": V1_ALIGNMENT_KEYPOINTS_CONTENT_SHA256,
            "expected_keypoint_records_sha256": V1_ALIGNMENT_KEYPOINT_RECORDS_SHA256,
            "expected_keypoint_count": V1_ALIGNMENT_KEYPOINT_COUNT,
            "expected_matrix_content_sha256": V1_ALIGNMENT_MATRIX_CONTENT_SHA256,
            "expected_matrix_values_sha256": V1_ALIGNMENT_MATRIX_VALUES_SHA256,
            "source_sample": "GSM9427183",
            "source_url": V1_ALIGNMENT_ARCHIVE_URL,
        }

    receipt: Dict[str, object] = {
        "schema": IMAGE_QUALIFICATION_RECEIPT_SCHEMA,
        "protocol_id": PROTOCOL_ID,
        "cohort": COHORT,
        "core_universe_sha256": CORE_UNIVERSE_SHA256,
        "status": "pending_required_evidence",
        "scope": "outcome_free_archive_routing_and_coordinate_inventory_only",
        "section_context": {
            "study_H_and_E_serial_TMA_section_count": 3,
            "assayed_section": "TMA6-10",
            "V1_output": "GSM9427183",
            "Prime_with_V1_segmentation_output": "GSM9427185",
            "V1_and_Prime_relationship": "sequential_outputs_from_one_tissue_section",
            "three_serial_sections_are_three_dual_chemistry_replicates": False,
        },
        "archive": dict(archive),
        "V1_alignment_archive": alignment,
        "routing": {
            "schema": IMAGE_ROUTING_SCHEMA,
            "raw_file_sha256": routing_sha256,
            "route_count": len(routes),
            "exact_17_core_universe_verified": True,
            "runtime_filename_inference_used": False,
            "routes_sha256": canonical_sha256(routes),
            "routes": routes,
        },
        "TMA_coordinates": dict(coordinates),
        "prior_white_blank_parity_evidence": {
            "status": "verified_prior_protocol_evidence_only",
            "source_schema": "heir.hest_blank_patch_supplement.v1",
            "source_receipt_sha256": PRIOR_WHITE_BLANK_RECEIPT_SHA256,
            "input_shape": [1, 224, 224, 3],
            "input_dtype": "uint8",
            "input_RGB_value": [255, 255, 255],
            "input_sha256": PRIOR_WHITE_BLANK_INPUT_SHA256,
            "encoder_manifest_sha256": HOPTIMUS1_ENCODER_MANIFEST_SHA256,
            "checkpoint_sha256": HOPTIMUS1_CHECKPOINT_SHA256,
            "feature_shape": [1, 1536],
            "feature_sha256": PRIOR_WHITE_BLANK_FEATURE_SHA256,
            "batch_1_vs_32_parity_passed": True,
            "qualifies_GSE315411_blank_crop_arm": False,
            "required_next_action": (
                "issue a protocol-specific outcome-free blank receipt by re-encoding the exact "
                "white patch with the verified frozen encoder"
            ),
        },
        "verified_outcome_free_evidence": [
            "final_archive_byte_count",
            "final_archive_sha256",
            "safe_archive_member_paths_and_types",
            "archive_member_content_hashes",
            "explicit_exact_17_core_image_routing",
            "exact_TMA_coordinate_file_and_parsed_record_hashes",
        ]
        + (
            ["V1_alignment_archive_and_numeric_transform_integrity"]
            if alignment["status"] == "archive_inventory_verified"
            else []
        ),
        "required_crop_arms": list(REQUIRED_CROP_ARMS),
        "frozen_crop_arms": [],
        "missing_required_evidence": missing_evidence,
        "phase3_qualified": False,
        "molecular_release_authorized": False,
        "biological_execution_authorized": False,
        "interpretation": (
            "Archive integrity and explicit routing are verified, but image/registration "
            "qualification is pending. This receipt cannot authorize molecular release or a "
            "biological run."
        ),
    }
    receipt["receipt_sha256"] = receipt_sha256(receipt)
    return receipt


def build_pending_gse315411_image_qualification_receipt(
    *,
    archive_path: PathLike,
    supplied_archive_sha256: str,
    routing_path: PathLike,
    tma_coordinates_path: PathLike,
    v1_alignment_archive_path: Optional[PathLike] = None,
) -> Mapping[str, object]:
    """Inspect only the exact final GSE315411 archive and return a pending receipt."""

    archive = Path(archive_path).expanduser().resolve()
    if archive.name != ARCHIVE_FINAL_NAME or archive.name.endswith(".part"):
        raise ValueError("qualification requires the exact final H&E archive filename, never .part")
    coordinates_path = Path(tma_coordinates_path).expanduser().resolve()
    if coordinates_path.name != TMA_COORDINATES_FINAL_NAME:
        raise ValueError("qualification requires the exact frozen TMA-coordinate filename")
    receipt = _build_pending_image_qualification_receipt(
        archive_path=archive,
        supplied_archive_sha256=supplied_archive_sha256,
        routing_path=routing_path,
        tma_coordinates_path=tma_coordinates_path,
        expected_archive_bytes=ARCHIVE_EXPECTED_BYTES,
        v1_alignment_archive_path=v1_alignment_archive_path,
        supplied_v1_alignment_sha256=(
            V1_ALIGNMENT_ARCHIVE_SHA256 if v1_alignment_archive_path is not None else None
        ),
        expected_v1_alignment_bytes=(
            V1_ALIGNMENT_ARCHIVE_EXPECTED_BYTES if v1_alignment_archive_path is not None else None
        ),
    )
    coordinates = receipt["TMA_coordinates"]
    expected_coordinates = {
        "raw_file_sha256": TMA_COORDINATES_SHA256,
        "coordinate_records_sha256": TMA_COORDINATE_RECORDS_SHA256,
        "record_count": TMA_COORDINATE_RECORD_COUNT,
        "selection_count": len(CORE_IDS),
    }
    if not isinstance(coordinates, Mapping) or {
        key: coordinates.get(key) for key in expected_coordinates
    } != expected_coordinates:
        raise ValueError("TMA-coordinate identity differs from the frozen outcome-free asset")
    if v1_alignment_archive_path is not None:
        alignment = receipt["V1_alignment_archive"]
        if not isinstance(alignment, Mapping):
            raise RuntimeError("V1 alignment inventory is missing from its pending receipt")
        expected_alignment = {
            "member_manifest_sha256": V1_ALIGNMENT_MEMBER_MANIFEST_SHA256,
            "keypoints_content_sha256": V1_ALIGNMENT_KEYPOINTS_CONTENT_SHA256,
            "keypoint_records_sha256": V1_ALIGNMENT_KEYPOINT_RECORDS_SHA256,
            "matrix_content_sha256": V1_ALIGNMENT_MATRIX_CONTENT_SHA256,
            "matrix_values_sha256": V1_ALIGNMENT_MATRIX_VALUES_SHA256,
            "keypoint_count": V1_ALIGNMENT_KEYPOINT_COUNT,
        }
        observed_alignment = {
            "member_manifest_sha256": alignment.get("member_manifest_sha256"),
            "keypoints_content_sha256": (
                alignment.get("keypoints", {}).get("content_sha256")
                if isinstance(alignment.get("keypoints"), Mapping)
                else None
            ),
            "keypoint_records_sha256": (
                alignment.get("keypoints", {}).get("records_sha256")
                if isinstance(alignment.get("keypoints"), Mapping)
                else None
            ),
            "matrix_content_sha256": (
                alignment.get("matrix", {}).get("content_sha256")
                if isinstance(alignment.get("matrix"), Mapping)
                else None
            ),
            "matrix_values_sha256": (
                alignment.get("matrix", {}).get("values_sha256")
                if isinstance(alignment.get("matrix"), Mapping)
                else None
            ),
            "keypoint_count": (
                alignment.get("keypoints", {}).get("correspondence_count")
                if isinstance(alignment.get("keypoints"), Mapping)
                else None
            ),
        }
        if observed_alignment != expected_alignment:
            raise ValueError("V1 alignment archive semantics differ from the frozen asset")
    return receipt


__all__ = [
    "ARCHIVE_EXPECTED_BYTES",
    "ARCHIVE_FINAL_NAME",
    "IMAGE_QUALIFICATION_RECEIPT_SCHEMA",
    "IMAGE_ROUTING_SCHEMA",
    "HOPTIMUS1_CHECKPOINT_SHA256",
    "HOPTIMUS1_ENCODER_MANIFEST_SHA256",
    "MISSING_REQUIRED_EVIDENCE",
    "REQUIRED_CROP_ARMS",
    "TMA_SELECTION_BY_CORE",
    "TMA_COORDINATES_FINAL_NAME",
    "TMA_COORDINATES_SHA256",
    "TMA_COORDINATE_RECORDS_SHA256",
    "V1_ALIGNMENT_ARCHIVE_EXPECTED_BYTES",
    "V1_ALIGNMENT_ARCHIVE_FINAL_NAME",
    "V1_ALIGNMENT_ARCHIVE_SHA256",
    "V1_ALIGNMENT_ARCHIVE_URL",
    "V1_ALIGNMENT_MEMBER_MANIFEST_SHA256",
    "build_pending_gse315411_image_qualification_receipt",
    "inspect_safe_tar_archive",
    "inspect_v1_alignment_archive",
]
