from __future__ import annotations

import numpy as np
import pytest

from heir.annotation.external_validation import summarize_predictions, support_by_class_and_donor


def test_external_validation_metrics_include_abstention_as_false_negative() -> None:
    metrics = summarize_predictions(
        ["A", "A", "B", "B"],
        ["A", "B", "B", "A"],
        np.asarray([0.9, 0.4, 0.8, 0.2]),
        np.asarray([False, True, False, True]),
        ["A", "B"],
        calibration_bins=2,
    )
    assert metrics["prediction_coverage"] == 0.5
    assert metrics["per_class"]["A"]["sensitivity"] == 0.5
    assert metrics["per_class"]["B"]["sensitivity"] == 0.5
    assert metrics["fine_type_macro_f1"] == pytest.approx(2 / 3)


def test_support_table_is_donor_and_class_explicit() -> None:
    support = support_by_class_and_donor(
        ["A", "A", "B"], ["D1", "D2", "D1"], ["A", "B"], ["D1", "D2"]
    )
    assert support == {"A": {"D1": 1, "D2": 1}, "B": {"D1": 1, "D2": 0}}
