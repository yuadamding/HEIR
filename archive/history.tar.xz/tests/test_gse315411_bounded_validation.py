from __future__ import annotations

import copy
import json
import re
import tarfile
from pathlib import Path

import pytest

import heir.evaluation.gse315411_bounded_validation as bounded
from heir.annotation.celltypist_inert import read_v1_panel_genes
from heir.data.experiment_manifest import canonical_sha256
from heir.data.gse315411_bounded_protocol import PROTOCOL_ID, receipt_sha256
from heir.utils import sha256_file


def _target_panel(monkeypatch: pytest.MonkeyPatch) -> dict[str, object]:
    v1 = [f"V1_{index:03d}" for index in range(480)]
    annotation = v1[:379]
    candidates = [f"P_{index:04d}" for index in range(4762)]
    prime = v1[:239] + candidates
    targets = candidates[:12]
    monkeypatch.setattr(bounded, "PROBE_ARCHIVE_SHA256", "9" * 64)
    monkeypatch.setattr(bounded, "V1_ORDERED_GENE_IDS_SHA256", canonical_sha256(v1))
    monkeypatch.setattr(bounded, "V1_SORTED_LF_GENE_IDS_SHA256", bounded.sorted_lf_set_sha256(v1))
    monkeypatch.setattr(bounded, "PRIME_ORDERED_GENE_IDS_SHA256", canonical_sha256(prime))
    monkeypatch.setattr(
        bounded, "PRIME_SORTED_LF_GENE_IDS_SHA256", bounded.sorted_lf_set_sha256(prime)
    )
    monkeypatch.setattr(bounded, "PRIME_ONLY_ORDERED_GENE_IDS_SHA256", canonical_sha256(candidates))
    monkeypatch.setattr(
        bounded,
        "PRIME_ONLY_SORTED_LF_GENE_IDS_SHA256",
        bounded.sorted_lf_set_sha256(candidates),
    )
    monkeypatch.setattr(
        bounded, "ANNOTATION_INPUT_ORDERED_GENE_IDS_SHA256", canonical_sha256(annotation)
    )
    monkeypatch.setattr(
        bounded,
        "ANNOTATION_INPUT_SORTED_LF_GENE_IDS_SHA256",
        bounded.sorted_lf_set_sha256(annotation),
    )
    return {
        "strategy": "common_reliable_panel_across_all_supported_fine_types",
        "ordered_target_gene_ids": targets,
        "ordered_target_gene_ids_canonical_sha256": canonical_sha256(targets),
        "target_gene_ids_sorted_lf_sha256": bounded.sorted_lf_set_sha256(targets),
        "prime_gene_ids": prime,
        "prime_gene_ids_ordered_canonical_sha256": canonical_sha256(prime),
        "prime_gene_ids_sorted_lf_sha256": bounded.sorted_lf_set_sha256(prime),
        "prime_only_candidate_gene_ids": candidates,
        "prime_only_candidate_gene_ids_ordered_canonical_sha256": canonical_sha256(candidates),
        "prime_only_candidate_gene_ids_sorted_lf_sha256": (
            bounded.sorted_lf_set_sha256(candidates)
        ),
        "v1_panel_gene_ids": v1,
        "v1_panel_gene_ids_ordered_canonical_sha256": canonical_sha256(v1),
        "v1_panel_gene_ids_sorted_lf_sha256": bounded.sorted_lf_set_sha256(v1),
        "annotation_input_gene_ids": annotation,
        "annotation_input_gene_ids_ordered_canonical_sha256": canonical_sha256(annotation),
        "annotation_input_gene_ids_sorted_lf_sha256": (bounded.sorted_lf_set_sha256(annotation)),
        "probe_archive_sha256": "9" * 64,
        "target_v1_intersection": [],
        "target_annotation_input_intersection": [],
        "source_matrix": "Prime_only_not_combined_V1_Prime",
        "common_across_supported_types": True,
        "type_specific_or_program_fallback_allowed": False,
    }


def test_prime_only_target_gate_recomputes_disjointness(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    panel = _target_panel(monkeypatch)
    assert bounded.validate_prime_only_target_panel(panel)["ordered_target_gene_ids"]

    leaked = copy.deepcopy(panel)
    leaked["ordered_target_gene_ids"][0] = leaked["v1_panel_gene_ids"][0]
    leaked["ordered_target_gene_ids_canonical_sha256"] = canonical_sha256(
        leaked["ordered_target_gene_ids"]
    )
    leaked["target_gene_ids_sorted_lf_sha256"] = bounded.sorted_lf_set_sha256(
        leaked["ordered_target_gene_ids"]
    )
    leaked["target_v1_intersection"] = [leaked["v1_panel_gene_ids"][0]]
    leaked["target_annotation_input_intersection"] = [leaked["v1_panel_gene_ids"][0]]
    with pytest.raises(ValueError, match="overlap the V1 annotation panel"):
        bounded.validate_prime_only_target_panel(leaked)

    combined = copy.deepcopy(panel)
    combined["source_matrix"] = "combined_V1_Prime"
    with pytest.raises(ValueError, match="strategy, source, or fallback"):
        bounded.validate_prime_only_target_panel(combined)


def test_real_probe_archive_matches_both_frozen_gene_hash_encodings() -> None:
    probe = Path("/mnt/seagate/HnE/GSE315411/metadata/GSE315411_xenium_probes.tar.gz")
    export = Path(
        "/mnt/seagate/HnE/GSE315411/reference/inert/Human_Lung_Atlas.v2.export_receipt.json"
    )
    if not probe.is_file() or not export.is_file():
        pytest.skip("outcome-free GSE315411 probe/model archives are not installed")
    assert sha256_file(probe) == bounded.PROBE_ARCHIVE_SHA256
    v1 = read_v1_panel_genes(probe)
    pattern = re.compile(rb"^>([^ ]+) \(ENSG[0-9]+\) \|")
    with tarfile.open(probe, "r:gz") as archive:
        handle = archive.extractfile("xenium_probes/xenium_human_5k_probe_sequences_revB.fasta")
        assert handle is not None
        prime = tuple(
            dict.fromkeys(
                match.group(1).decode("ascii")
                for line in handle
                if line.startswith(b">")
                for match in [pattern.match(line)]
                if match is not None
            )
        )
    model_features = json.loads(export.read_text(encoding="utf-8"))["ordered_feature_ids"]
    prime_only = tuple(gene for gene in prime if gene not in set(v1))
    annotation = tuple(gene for gene in v1 if gene in set(model_features))
    expected = (
        (v1, bounded.V1_ORDERED_GENE_IDS_SHA256, bounded.V1_SORTED_LF_GENE_IDS_SHA256),
        (prime, bounded.PRIME_ORDERED_GENE_IDS_SHA256, bounded.PRIME_SORTED_LF_GENE_IDS_SHA256),
        (
            prime_only,
            bounded.PRIME_ONLY_ORDERED_GENE_IDS_SHA256,
            bounded.PRIME_ONLY_SORTED_LF_GENE_IDS_SHA256,
        ),
        (
            annotation,
            bounded.ANNOTATION_INPUT_ORDERED_GENE_IDS_SHA256,
            bounded.ANNOTATION_INPUT_SORTED_LF_GENE_IDS_SHA256,
        ),
    )
    for values, ordered_sha, sorted_lf_sha in expected:
        assert canonical_sha256(list(values)) == ordered_sha
        assert bounded.sorted_lf_set_sha256(values) == sorted_lf_sha


def test_terminal_receipt_binds_phase4_failure_with_a_self_digest() -> None:
    result = bounded.terminal_protocol_receipt()
    assert result["protocol_id"] == PROTOCOL_ID
    assert result["status"] == bounded.PROTOCOL_TERMINAL_STATUS
    assert result["terminal_result"] is True
    assert result["phases_5_through_9_executed"] is False
    assert result["development_prime_released"] is False
    assert result["locked_prime_released"] is False
    assert result["biological_hypothesis_tested"] is False
    assert result["same_identity_repair_or_rerun_allowed"] is False
    assert all(value is False for value in result["authorizations"].values())
    evidence = result["annotation_validation_evidence"]
    assert evidence["qualified_model_classes"] == []
    assert evidence["authorizes_gse315411_annotation"] is False
    assert (
        evidence["passing_subset_multiclass_expected_calibration_error"]
        > evidence["maximum_allowed_multiclass_expected_calibration_error"]
    )
    assert (
        evidence["passing_subset_prediction_coverage"]
        < evidence["minimum_required_prediction_coverage"]
    )
    assert result["receipt_sha256"] == receipt_sha256(result)
    assert bounded.validate_terminal_protocol_receipt(result) == result


def test_materialized_terminal_receipt_matches_the_deterministic_contract() -> None:
    path = (
        Path(__file__).parents[1]
        / "reports"
        / "gse315411_bounded_same_section_terminal_receipt.json"
    )
    assert json.loads(path.read_text(encoding="utf-8")) == bounded.terminal_protocol_receipt()


@pytest.mark.parametrize("phase", range(5, 10))
def test_every_downstream_phase_is_unconditionally_refused(phase: int) -> None:
    with pytest.raises(
        bounded.TerminalBoundedProtocolError,
        match="terminal_pre_unlock_annotation_qualification_failure",
    ):
        bounded.require_phase_5_to_9_authorized(phase)


@pytest.mark.parametrize("phase", [True, False, 4, 10, 5.0, "5"])
def test_terminal_gate_rejects_ambiguous_phase_identifiers(phase: object) -> None:
    with pytest.raises(ValueError, match="integer from 5 through 9"):
        bounded.require_phase_5_to_9_authorized(phase)  # type: ignore[arg-type]


def test_terminal_receipt_matches_installed_external_validation_evidence() -> None:
    receipt_path = Path(bounded.ANNOTATION_VALIDATION_RECEIPT_PATH)
    if not receipt_path.is_file():
        pytest.skip("frozen external annotation receipt is not installed")
    assert sha256_file(receipt_path) == bounded.ANNOTATION_VALIDATION_RECEIPT_FILE_SHA256
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    assert receipt["schema"] == bounded.ANNOTATION_VALIDATION_SCHEMA
    assert receipt["decision"] == {
        "authorizes_gse315411_annotation": False,
        "global_failure_reasons": [
            "calibration_error_above_0.10",
            "prediction_coverage_below_0.80",
        ],
        "passing_model_classes_before_global_gate": ["AT2", "B cells", "CD8 T cells"],
        "qualified_model_classes_for_gse315411": [],
        "reason": "external_v1_only_annotation_gate_failed_closed",
        "status": "fail",
    }
    metrics = receipt["qualified_type_global_metrics"]
    evidence = bounded.terminal_protocol_receipt()["annotation_validation_evidence"]
    assert (
        metrics["calibration_error"]
        == evidence["passing_subset_multiclass_expected_calibration_error"]
    )
    assert metrics["prediction_coverage"] == evidence["passing_subset_prediction_coverage"]
    assert receipt["row_level_evidence"]["sha256"] == (
        bounded.ANNOTATION_VALIDATION_ROW_EVIDENCE_SHA256
    )
    assert receipt["execution"]["gse315411_molecular_data_loaded"] is False
    assert bounded.verify_terminal_annotation_evidence() == receipt


def test_hash_substitution_cannot_turn_failed_annotation_into_authorization(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source = Path(bounded.ANNOTATION_VALIDATION_RECEIPT_PATH)
    if not source.is_file():
        pytest.skip("frozen external annotation receipt is not installed")
    overstated = json.loads(source.read_text(encoding="utf-8"))
    overstated["decision"]["status"] = "pass"
    overstated["decision"]["authorizes_gse315411_annotation"] = True
    overstated["decision"]["qualified_model_classes_for_gse315411"] = [
        "AT2",
        "B cells",
        "CD8 T cells",
    ]
    substituted = tmp_path / "overstated.json"
    substituted.write_text(json.dumps(overstated), encoding="utf-8")

    # Even if an attacker substitutes a receipt and updates its claimed digest,
    # semantic recomputation against the independently pinned rows must reject it.
    monkeypatch.setattr(
        bounded,
        "ANNOTATION_VALIDATION_RECEIPT_FILE_SHA256",
        sha256_file(substituted),
    )
    with pytest.raises(ValueError, match="decision"):
        bounded.verify_terminal_annotation_evidence(receipt_path=substituted)
