from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest

from heir.annotation.external_validation_receipt import validate_external_validation_receipt

RECEIPT = Path(
    "/mnt/seagate/HnE/GSE315411/annotation_validation/GSE274199/"
    "gse274199_celltypist_v1_validation.receipt.json"
)


def _terminal_receipt() -> dict[str, object]:
    if not RECEIPT.is_file():
        pytest.skip("terminal GSE274199 scientific evidence is not mounted")
    return json.loads(RECEIPT.read_text(encoding="utf-8"))


def test_terminal_external_validation_receipt_recomputes_failed_gate() -> None:
    validated = validate_external_validation_receipt(_terminal_receipt())
    assert validated["decision"] == {
        "status": "fail",
        "reason": "external_v1_only_annotation_gate_failed_closed",
        "global_failure_reasons": [
            "calibration_error_above_0.10",
            "prediction_coverage_below_0.80",
        ],
        "passing_model_classes_before_global_gate": ["AT2", "B cells", "CD8 T cells"],
        "qualified_model_classes_for_gse315411": [],
        "authorizes_gse315411_annotation": False,
    }


def test_external_validation_receipt_rejects_overstated_metric() -> None:
    tampered = copy.deepcopy(_terminal_receipt())
    tampered["primary_validation"]["fine_type_macro_f1"] = 0.99
    with pytest.raises(ValueError, match="primary_validation"):
        validate_external_validation_receipt(tampered)


def test_external_validation_receipt_rejects_false_authorization() -> None:
    tampered = copy.deepcopy(_terminal_receipt())
    tampered["decision"]["status"] = "pass"
    tampered["decision"]["authorizes_gse315411_annotation"] = True
    tampered["decision"]["qualified_model_classes_for_gse315411"] = [
        "AT2",
        "B cells",
        "CD8 T cells",
    ]
    with pytest.raises(ValueError, match="decision"):
        validate_external_validation_receipt(tampered)


def test_external_validation_receipt_rejects_extra_claim() -> None:
    tampered = copy.deepcopy(_terminal_receipt())
    tampered["authorizes_full_heir"] = True
    with pytest.raises(ValueError, match="unsupported"):
        validate_external_validation_receipt(tampered)
