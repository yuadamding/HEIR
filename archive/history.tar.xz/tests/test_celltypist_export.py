from __future__ import annotations

import errno
import hashlib
import json
import pickle
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest

import heir.annotation.celltypist_export as exporter


def _synthetic_pickle(path: Path) -> str:
    classifier = SimpleNamespace(
        features=np.asarray(["GENE_A", "GENE_B", "GENE_C"], dtype=object),
        classes_=np.asarray(["AT1", "AT2"], dtype=object),
        coef_=np.asarray([[1.0, -2.0, 0.5]], dtype=np.float32),
        intercept_=np.asarray([0.25], dtype=np.float32),
        _sklearn_version="synthetic-test",
    )
    scaler = SimpleNamespace(
        mean_=np.asarray([1.0, 2.0, 3.0]),
        scale_=np.asarray([0.5, 1.5, 2.5]),
        var_=np.asarray([0.25, 2.25, 6.25]),
        with_mean=True,
        with_std=True,
        _sklearn_version="synthetic-test",
    )
    with path.open("wb") as handle:
        pickle.dump(
            {
                "Model": classifier,
                "Scaler_": scaler,
                "description": {"version": "synthetic", "number_celltypes": 2},
            },
            handle,
            protocol=4,
        )
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_synthetic_pickle_exports_only_inert_numeric_arrays_and_json(tmp_path: Path) -> None:
    source = tmp_path / "harmless.pkl"
    digest = _synthetic_pickle(source)
    weights = tmp_path / "model.npz"
    receipt_path = tmp_path / "receipt.json"
    receipt = exporter.export_celltypist_pickle(source, digest, weights, receipt_path)

    assert receipt == json.loads(receipt_path.read_text(encoding="utf-8"))
    assert receipt["source"]["verified_sha256"] == digest
    assert receipt["source"]["official_model_id"] is None
    assert receipt["ordered_feature_ids"] == ["GENE_A", "GENE_B", "GENE_C"]
    assert receipt["ordered_class_ids"] == ["AT1", "AT2"]
    assert receipt["isolation"]["unsafe_fallback_allowed"] is False
    assert receipt["pickle_required_for_production_inference"] is False
    with np.load(weights, allow_pickle=False) as archive:
        assert set(archive.files) == {
            "coefficient_matrix",
            "intercepts",
            "scaler_mean",
            "scaler_scale",
            "scaler_variance",
        }
        assert all(archive[name].dtype.kind != "O" for name in archive.files)
        np.testing.assert_array_equal(
            archive["coefficient_matrix"], np.asarray([[1.0, -2.0, 0.5]], dtype=np.float32)
        )


def test_wrong_hash_stops_before_worker_launch(monkeypatch, tmp_path: Path) -> None:
    source = tmp_path / "harmless.pkl"
    _synthetic_pickle(source)

    def forbidden(*_args, **_kwargs):
        raise AssertionError("worker must not launch for a hash mismatch")

    monkeypatch.setattr(exporter, "_run_isolated_worker", forbidden)
    with pytest.raises(ValueError, match="does not match"):
        exporter.export_celltypist_pickle(
            source,
            "0" * 64,
            tmp_path / "model.npz",
            tmp_path / "receipt.json",
        )
    assert not (tmp_path / "model.npz").exists()
    assert not (tmp_path / "receipt.json").exists()


def test_unsafe_fallback_is_prohibited(monkeypatch, tmp_path: Path) -> None:
    source = tmp_path / "harmless.pkl"
    digest = _synthetic_pickle(source)
    monkeypatch.setattr(exporter.shutil, "which", lambda _name: None)
    with pytest.raises(RuntimeError, match="unsafe pickle-loading fallback is prohibited"):
        exporter.export_celltypist_pickle(
            source,
            digest,
            tmp_path / "model.npz",
            tmp_path / "receipt.json",
        )


def test_malformed_model_fails_without_publishing_artifacts(tmp_path: Path) -> None:
    source = tmp_path / "incomplete.pkl"
    with source.open("wb") as handle:
        pickle.dump({"Model": SimpleNamespace()}, handle, protocol=4)
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    with pytest.raises(RuntimeError, match="lacks Model or Scaler"):
        exporter.export_celltypist_pickle(
            source,
            digest,
            tmp_path / "model.npz",
            tmp_path / "receipt.json",
        )
    assert not (tmp_path / "model.npz").exists()
    assert not (tmp_path / "receipt.json").exists()


def test_official_hash_is_pinned_without_opening_official_pickle() -> None:
    assert exporter.OFFICIAL_HUMAN_LUNG_ATLAS_V2_SHA256 == (
        "6b0730537f4fee9f9a6195891a72635d1a3b9e21cade7a7481b2b14808070fdd"
    )


def test_exfat_publication_fallback_is_exclusive(monkeypatch, tmp_path: Path) -> None:
    source = tmp_path / "staged"
    destination = tmp_path / "published"
    source.write_bytes(b"inert artifact")

    def unsupported_link(*_args, **_kwargs):
        raise OSError(errno.EPERM, "hard links unsupported")

    monkeypatch.setattr(exporter.os, "link", unsupported_link)
    exporter._publish_noreplace(source, destination)
    assert destination.read_bytes() == b"inert artifact"
    with pytest.raises(FileExistsError):
        exporter._publish_noreplace(source, destination)
    assert destination.read_bytes() == b"inert artifact"
