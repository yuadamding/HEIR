from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
from types import ModuleType

import pytest

from heir.data.gse315411_bounded_protocol import (
    CELL_STATS_SHA256,
    COHORT,
    CORE_IDS,
    CORE_UNIVERSE_SHA256,
    CUSTODY_RECEIPT_SCHEMA,
    EXPOSURE_MAP_SCHEMA,
    PROTOCOL_ID,
    SUPPLEMENTAL_TABLES_SHA256,
    generate_exposure_stratified_split,
    load_json_receipt,
    receipt_sha256,
    validate_custody_receipt,
    validate_exposure_map,
)


def _custody_receipt() -> dict[str, object]:
    value: dict[str, object] = {
        "schema": CUSTODY_RECEIPT_SCHEMA,
        "protocol_id": PROTOCOL_ID,
        "cohort": COHORT,
        "cell_stats_sha256": CELL_STATS_SHA256,
        "supplemental_tables_sha256": SUPPLEMENTAL_TABLES_SHA256,
        "analysis_account_identity": "heir-analysis",
        "custodian_identity": "independent-custodian",
        "custodian_is_independent": True,
        "analysis_account_has_read_access": False,
        "analysis_environment_readable_copies_removed": True,
        "development_payload_separately_releasable": True,
        "locked_payload_separately_releasable": True,
        "access_logging_enabled": True,
        "access_log_append_only": True,
    }
    value["receipt_sha256"] = receipt_sha256(value)
    return value


def _exposure_map(custody: dict[str, object]) -> dict[str, object]:
    known = {"PDL018D", "PDL026A", "PDL034D"}
    value: dict[str, object] = {
        "schema": EXPOSURE_MAP_SCHEMA,
        "protocol_id": PROTOCOL_ID,
        "cohort": COHORT,
        "core_universe_sha256": CORE_UNIVERSE_SHA256,
        "custody_receipt_sha256": custody["receipt_sha256"],
        "custodian_identity": custody["custodian_identity"],
        "all_public_sample_level_material_audited": True,
        "underlying_molecular_values_disclosed_to_analysis_account": False,
        "classifications": [
            {
                "core_id": core_id,
                "exposure_class": (
                    "sample-specific-summary" if core_id in known else "none"
                ),
            }
            for core_id in CORE_IDS
        ],
    }
    value["receipt_sha256"] = receipt_sha256(value)
    return value


def _refresh_digest(value: dict[str, object]) -> None:
    value["receipt_sha256"] = receipt_sha256(value)


def _load_cli() -> ModuleType:
    path = Path(__file__).parents[1] / "scripts" / "manage_gse315411_bounded_protocol.py"
    spec = importlib.util.spec_from_file_location("manage_gse315411_bounded_protocol", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_custody_receipt_requires_independence_separate_release_and_append_only_logs() -> None:
    valid = _custody_receipt()
    assert validate_custody_receipt(valid)["receipt_sha256"] == valid["receipt_sha256"]

    invalid_values = {
        "custodian_is_independent": False,
        "analysis_account_has_read_access": True,
        "analysis_environment_readable_copies_removed": False,
        "development_payload_separately_releasable": False,
        "locked_payload_separately_releasable": False,
        "access_logging_enabled": False,
        "access_log_append_only": False,
    }
    for field, invalid in invalid_values.items():
        changed = copy.deepcopy(valid)
        changed[field] = invalid
        _refresh_digest(changed)
        with pytest.raises(ValueError, match=field):
            validate_custody_receipt(changed)

    non_boolean = copy.deepcopy(valid)
    non_boolean["custodian_is_independent"] = 1
    _refresh_digest(non_boolean)
    with pytest.raises(ValueError, match="custodian_is_independent"):
        validate_custody_receipt(non_boolean)


def test_custody_receipt_rejects_same_identity_wrong_archive_and_tampering() -> None:
    same_identity = _custody_receipt()
    same_identity["custodian_identity"] = same_identity["analysis_account_identity"]
    _refresh_digest(same_identity)
    with pytest.raises(ValueError, match="must differ"):
        validate_custody_receipt(same_identity)

    wrong_archive = _custody_receipt()
    wrong_archive["cell_stats_sha256"] = "0" * 64
    _refresh_digest(wrong_archive)
    with pytest.raises(ValueError, match="cell_stats_sha256"):
        validate_custody_receipt(wrong_archive)

    tampered = _custody_receipt()
    tampered["analysis_account_identity"] = "changed-after-signing"
    with pytest.raises(ValueError, match="does not bind"):
        validate_custody_receipt(tampered)

    extra = _custody_receipt()
    extra["unbound_claim"] = True
    _refresh_digest(extra)
    with pytest.raises(ValueError, match="extra=.*unbound_claim"):
        validate_custody_receipt(extra)


def test_exposure_map_is_complete_value_free_and_cannot_downgrade_known_exposure() -> None:
    custody = _custody_receipt()
    valid = _exposure_map(custody)
    assert validate_exposure_map(valid, custody)["receipt_sha256"] == valid["receipt_sha256"]

    disclosed = copy.deepcopy(valid)
    disclosed["underlying_molecular_values_disclosed_to_analysis_account"] = True
    _refresh_digest(disclosed)
    with pytest.raises(ValueError, match="must be false"):
        validate_exposure_map(disclosed, custody)

    downgraded = copy.deepcopy(valid)
    rows = downgraded["classifications"]
    assert isinstance(rows, list)
    next(row for row in rows if row["core_id"] == "PDL034D")["exposure_class"] = "none"
    _refresh_digest(downgraded)
    with pytest.raises(ValueError, match="downgrade known exposure for PDL034D"):
        validate_exposure_map(downgraded, custody)

    incomplete = copy.deepcopy(valid)
    incomplete_rows = incomplete["classifications"]
    assert isinstance(incomplete_rows, list)
    incomplete_rows.pop()
    _refresh_digest(incomplete)
    with pytest.raises(ValueError, match="exact 17-core universe"):
        validate_exposure_map(incomplete, custody)

    duplicate = copy.deepcopy(valid)
    duplicate_rows = duplicate["classifications"]
    assert isinstance(duplicate_rows, list)
    duplicate_rows[-1] = copy.deepcopy(duplicate_rows[0])
    _refresh_digest(duplicate)
    with pytest.raises(ValueError, match="duplicate core_id PDL018D"):
        validate_exposure_map(duplicate, custody)


def test_exposure_stratified_split_is_exact_deterministic_and_outcome_blind() -> None:
    custody = _custody_receipt()
    exposure = _exposure_map(custody)
    split = generate_exposure_stratified_split(custody, exposure)

    assert split["exposed_development"] == ["PDL018D", "PDL026A", "PDL034D"]
    assert split["development"] == [
        "PDL018D",
        "PDL026A",
        "PDL034D",
        "PDL095D",
        "PDL072",
        "PDL033T",
        "PDL040A",
        "PDL029A",
        "PDL097",
        "PDL055T",
    ]
    assert split["locked_evaluation"] == [
        "PDL031A",
        "PDL042D",
        "PDL085A",
        "PDL032D",
        "PDL047T",
    ]
    assert split["reserve"] == ["PDL061", "PDL077"]
    assert split["molecular_release_authorized"] is False
    assert split["receipt_sha256"] == receipt_sha256(split)

    reordered = copy.deepcopy(exposure)
    reordered_rows = reordered["classifications"]
    assert isinstance(reordered_rows, list)
    reordered_rows.reverse()
    _refresh_digest(reordered)
    reordered_split = generate_exposure_stratified_split(custody, reordered)
    for field in ("exposed_development", "development", "locked_evaluation", "reserve"):
        assert reordered_split[field] == split[field]


def test_split_fails_closed_when_more_than_ten_cores_are_exposed() -> None:
    custody = _custody_receipt()
    exposure = _exposure_map(custody)
    rows = exposure["classifications"]
    assert isinstance(rows, list)
    for row in rows[:11]:
        row["exposure_class"] = "sample-specific-summary"
    _refresh_digest(exposure)

    with pytest.raises(ValueError, match="no more than 10 exposed cores"):
        generate_exposure_stratified_split(custody, exposure)


def test_loader_rejects_duplicate_json_keys(tmp_path: Path) -> None:
    path = tmp_path / "ambiguous.json"
    path.write_text('{"schema":"first","schema":"second"}', encoding="utf-8")
    with pytest.raises(ValueError, match="duplicate key schema"):
        load_json_receipt(path)


def test_cli_generates_once_and_refuses_to_replace_split_receipt(tmp_path: Path) -> None:
    cli = _load_cli()
    custody = _custody_receipt()
    exposure = _exposure_map(custody)
    custody_path = tmp_path / "custody.json"
    exposure_path = tmp_path / "exposure.json"
    output = tmp_path / "split.json"
    custody_path.write_text(json.dumps(custody), encoding="utf-8")
    exposure_path.write_text(json.dumps(exposure), encoding="utf-8")

    arguments = [
        "generate-split",
        "--custody-receipt",
        str(custody_path),
        "--exposure-map",
        str(exposure_path),
        "--output",
        str(output),
    ]
    assert cli.main(arguments) == 0
    written = json.loads(output.read_text(encoding="utf-8"))
    assert written["locked_evaluation"] == [
        "PDL031A",
        "PDL042D",
        "PDL085A",
        "PDL032D",
        "PDL047T",
    ]
    with pytest.raises(FileExistsError, match="replacement is forbidden"):
        cli.main(arguments)


def test_new_schemas_are_valid_json_and_fail_closed_on_extra_properties() -> None:
    root = Path(__file__).parents[1] / "configs" / "schemas"
    for name in (
        "independent_molecular_custody_receipt.schema.json",
        "molecular_exposure_classification.schema.json",
        "exposure_stratified_split_receipt.schema.json",
    ):
        schema = json.loads((root / name).read_text(encoding="utf-8"))
        assert schema["additionalProperties"] is False


def test_terminal_predecessor_is_immutable_and_successor_stays_non_authorizing() -> None:
    root = Path(__file__).parents[1]
    terminal_path = root / "reports" / "gse315411_prospective_eligibility_receipt.json"
    successor_path = (
        root
        / "manifests"
        / "studies"
        / "gse315411_bounded_same_section_cell_state_v1.draft.json"
    )
    terminal = json.loads(terminal_path.read_text(encoding="utf-8"))
    successor = json.loads(successor_path.read_text(encoding="utf-8"))

    assert terminal["classification"] == "pre_unlock_eligibility_failure"
    assert terminal["decision"] == "fail_closed_before_biological_execution"
    assert terminal["terminal_result"] is True
    assert terminal["prospective_rerun_allowed"] is False
    assert terminal["rejected_split_repair_allowed"] is False
    assert terminal["terminal_interpretation"]["biological_hypothesis_tested"] is False
    assert terminal["terminal_interpretation"]["new_bounded_protocol_authorizes_H_CELL"] is False
    assert "bounded_same_cell_H_CELL_test_possible_after_new_protocol_and_custody" not in terminal[
        "scientific_scope"
    ]

    predecessor = successor["predecessor"]
    assert predecessor["protocol_id"] == "gse315411_nonlinear_morphology_v1"
    assert predecessor["split_repair_or_rerun_allowed"] is False
    assert predecessor["receipt_sha256"] == hashlib.sha256(terminal_path.read_bytes()).hexdigest()
    assert successor["status"] == "terminal_pre_unlock_annotation_qualification_failure"
    assert successor["maximum_conclusion"] == "supports_bounded_same_section_donor_generalization"
    assert set(successor["authorizations"].values()) == {False}
