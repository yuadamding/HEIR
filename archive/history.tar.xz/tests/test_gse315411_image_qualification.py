from __future__ import annotations

import hashlib
import importlib.util
import json
import tarfile
from pathlib import Path
from types import ModuleType

import pytest

from heir.data import gse315411_image_qualification as images
from heir.data.gse315411_bounded_protocol import (
    COHORT,
    CORE_IDS,
    CORE_UNIVERSE_SHA256,
    PROTOCOL_ID,
    receipt_sha256,
)


def _tar(path: Path, members: list[tuple[str, bytes, bytes]]) -> Path:
    """Write (name, content, type) triples to a synthetic gzip tar."""

    with tarfile.open(path, "w:gz") as archive:
        for name, content, member_type in members:
            info = tarfile.TarInfo(name)
            info.type = member_type
            if member_type in {tarfile.SYMTYPE, tarfile.LNKTYPE}:
                info.linkname = "elsewhere"
                info.size = 0
                archive.addfile(info)
            elif member_type == tarfile.DIRTYPE:
                info.size = 0
                archive.addfile(info)
            elif member_type == tarfile.REGTYPE:
                info.size = len(content)
                import io

                archive.addfile(info, io.BytesIO(content))
            else:
                info.size = 0
                archive.addfile(info)
    return path


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _coordinates(path: Path) -> Path:
    lines = ["# synthetic outcome-free test fixture", "Selection,X,Y"]
    points = ((0, 0), (10, 0), (0, 10), (0, 0))
    for core_id in CORE_IDS:
        selection = images.TMA_SELECTION_BY_CORE[core_id]
        lines.extend("%s,%d,%d" % (selection, x, y) for x, y in points)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def _routing(path: Path, *, archive_sha256: str, coordinates_sha256: str) -> Path:
    value = {
        "schema": images.IMAGE_ROUTING_SCHEMA,
        "protocol_id": PROTOCOL_ID,
        "cohort": COHORT,
        "core_universe_sha256": CORE_UNIVERSE_SHA256,
        "archive_sha256": archive_sha256,
        "tma_coordinates_sha256": coordinates_sha256,
        "routes": [
            {
                "core_id": core_id,
                "image_member_path": "slides/TMA6-10.ome.tif",
                "tma_selection_name": images.TMA_SELECTION_BY_CORE[core_id],
            }
            for core_id in CORE_IDS
        ],
    }
    path.write_text(json.dumps(value, indent=2), encoding="utf-8")
    return path


def _safe_archive(path: Path) -> Path:
    return _tar(
        path,
        [
            ("slides/", b"", tarfile.DIRTYPE),
            ("slides/TMA6-10.ome.tif", b"synthetic image bytes", tarfile.REGTYPE),
        ],
    )


def _alignment_archive(
    path: Path,
    *,
    keypoints: bytes = (
        b"fixedX,fixedY,alignmentX,alignmentY\n"
        b"0,0,0,0\n10,0,10,0\n0,10,0,10\n10,10,10,10\n"
    ),
    matrix: bytes = b"1,0,0\n0,1,0\n0,0,1\n",
) -> Path:
    root = "Xen0069259_NB_PDLTMA6-10_v1_alignment_files"
    return _tar(
        path,
        [
            (root + "/", b"", tarfile.DIRTYPE),
            (root + "/keypoints.csv", keypoints, tarfile.REGTYPE),
            (root + "/matrix.csv", matrix, tarfile.REGTYPE),
        ],
    )


def _load_cli() -> ModuleType:
    path = Path(__file__).parents[1] / "scripts" / "manage_gse315411_bounded_protocol.py"
    spec = importlib.util.spec_from_file_location("manage_gse315411_images", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_safe_archive_is_streamed_hashed_and_member_bound(tmp_path: Path) -> None:
    archive = _safe_archive(tmp_path / "safe.tar.gz")
    result = images.inspect_safe_tar_archive(
        archive,
        expected_bytes=archive.stat().st_size,
        supplied_sha256=_sha256(archive),
    )

    assert result["observed_sha256"] == _sha256(archive)
    assert result["file_count"] == 1
    assert result["directory_count"] == 1
    assert result["member_count"] == 2
    assert result["member_manifest_sha256"] == images.canonical_sha256(result["members"])
    regular = next(row for row in result["members"] if row["type"] == "file")
    assert regular["content_sha256"] == hashlib.sha256(b"synthetic image bytes").hexdigest()


@pytest.mark.parametrize(
    ("name", "member_type", "error"),
    [
        ("../escape.tif", tarfile.REGTYPE, "escapes"),
        ("/absolute.tif", tarfile.REGTYPE, "escapes"),
        ("windows\\escape.tif", tarfile.REGTYPE, "unsafe"),
        ("link.tif", tarfile.SYMTYPE, "symbolic link"),
        ("hard.tif", tarfile.LNKTYPE, "hard link"),
        ("pipe.tif", tarfile.FIFOTYPE, "FIFO"),
        ("device.tif", tarfile.CHRTYPE, "device"),
    ],
)
def test_archive_rejects_unsafe_paths_links_and_special_types(
    tmp_path: Path, name: str, member_type: bytes, error: str
) -> None:
    archive = _tar(tmp_path / "unsafe.tar.gz", [(name, b"x", member_type)])
    with pytest.raises(ValueError, match=error):
        images.inspect_safe_tar_archive(
            archive,
            expected_bytes=archive.stat().st_size,
            supplied_sha256=_sha256(archive),
        )


def test_pending_receipt_binds_exact_routes_coordinates_and_all_blockers(tmp_path: Path) -> None:
    archive = _safe_archive(tmp_path / "synthetic-he.tar.gz")
    coordinates = _coordinates(tmp_path / "coordinates.csv")
    routing = _routing(
        tmp_path / "routing.json",
        archive_sha256=_sha256(archive),
        coordinates_sha256=_sha256(coordinates),
    )
    receipt = images._build_pending_image_qualification_receipt(
        archive_path=archive,
        supplied_archive_sha256=_sha256(archive),
        routing_path=routing,
        tma_coordinates_path=coordinates,
        expected_archive_bytes=archive.stat().st_size,
    )

    assert receipt["status"] == "pending_required_evidence"
    assert receipt["phase3_qualified"] is False
    assert receipt["molecular_release_authorized"] is False
    assert receipt["biological_execution_authorized"] is False
    assert receipt["routing"]["exact_17_core_universe_verified"] is True
    assert receipt["routing"]["runtime_filename_inference_used"] is False
    assert [row["core_id"] for row in receipt["routing"]["routes"]] == list(CORE_IDS)
    assert receipt["TMA_coordinates"]["raw_file_sha256"] == _sha256(coordinates)
    assert set(receipt["required_crop_arms"]) == set(images.REQUIRED_CROP_ARMS)
    assert receipt["frozen_crop_arms"] == []
    assert receipt["missing_required_evidence"] == list(images.MISSING_REQUIRED_EVIDENCE)
    assert receipt["V1_alignment_archive"]["status"] == "missing"
    prior_blank = receipt["prior_white_blank_parity_evidence"]
    assert prior_blank["feature_sha256"] == images.PRIOR_WHITE_BLANK_FEATURE_SHA256
    assert prior_blank["qualifies_GSE315411_blank_crop_arm"] is False
    assert receipt["section_context"]["study_H_and_E_serial_TMA_section_count"] == 3
    assert receipt["section_context"]["V1_and_Prime_relationship"] == (
        "sequential_outputs_from_one_tissue_section"
    )
    assert receipt["receipt_sha256"] == receipt_sha256(receipt)


def test_optional_alignment_archive_is_safely_bound_but_transforms_remain_pending(
    tmp_path: Path,
) -> None:
    archive = _safe_archive(tmp_path / "synthetic-he.tar.gz")
    coordinates = _coordinates(tmp_path / "coordinates.csv")
    routing = _routing(
        tmp_path / "routing.json",
        archive_sha256=_sha256(archive),
        coordinates_sha256=_sha256(coordinates),
    )
    alignment = _alignment_archive(tmp_path / images.V1_ALIGNMENT_ARCHIVE_FINAL_NAME)
    receipt = images._build_pending_image_qualification_receipt(
        archive_path=archive,
        supplied_archive_sha256=_sha256(archive),
        routing_path=routing,
        tma_coordinates_path=coordinates,
        expected_archive_bytes=archive.stat().st_size,
        v1_alignment_archive_path=alignment,
        supplied_v1_alignment_sha256=_sha256(alignment),
        expected_v1_alignment_bytes=alignment.stat().st_size,
    )

    assert receipt["V1_alignment_archive"]["status"] == "archive_inventory_verified"
    assert receipt["V1_alignment_archive"]["keypoints"]["correspondence_count"] == 4
    assert receipt["V1_alignment_archive"]["matrix"]["shape"] == [3, 3]
    assert receipt["V1_alignment_archive"]["matrix"]["invertible"] is True
    assert receipt["V1_alignment_archive"]["registration_accuracy_qualified"] is False
    assert "V1_alignment_archive_identity_and_member_inventory" not in receipt[
        "missing_required_evidence"
    ]
    assert "H_and_E_to_Xenium_transforms" in receipt["missing_required_evidence"]
    assert receipt["phase3_qualified"] is False


@pytest.mark.parametrize(
    ("keypoints", "matrix", "message"),
    [
        (
            b"fixedX,fixedY,alignmentX,alignmentY\n0,0,0,0\n1,0,1,0\n0,1,0,1\n",
            b"1,0\n0,1\n",
            "3 by 3",
        ),
        (
            b"fixedX,fixedY,alignmentX,alignmentY\n0,0,0,0\n1,0,1,0\n0,1,0,1\n",
            b"1,0,0\n0,0,0\n0,0,1\n",
            "non-invertible",
        ),
        (
            b"fixedX,fixedY,alignmentX,alignmentY\n0,0,0,0\n1,0,inf,0\n0,1,0,1\n",
            b"1,0,0\n0,1,0\n0,0,1\n",
            "invalid coordinate",
        ),
    ],
)
def test_alignment_semantics_reject_bad_shape_singular_matrix_and_nonfinite_points(
    tmp_path: Path, keypoints: bytes, matrix: bytes, message: str
) -> None:
    archive = _alignment_archive(
        tmp_path / images.V1_ALIGNMENT_ARCHIVE_FINAL_NAME,
        keypoints=keypoints,
        matrix=matrix,
    )
    with pytest.raises(ValueError, match=message):
        images.inspect_v1_alignment_archive(
            archive,
            expected_bytes=archive.stat().st_size,
            supplied_sha256=_sha256(archive),
        )


def test_exact_17_core_routing_rejects_missing_swap_and_unknown_member(tmp_path: Path) -> None:
    archive = _safe_archive(tmp_path / "synthetic-he.tar.gz")
    coordinates = _coordinates(tmp_path / "coordinates.csv")
    routing_path = _routing(
        tmp_path / "routing.json",
        archive_sha256=_sha256(archive),
        coordinates_sha256=_sha256(coordinates),
    )
    base = json.loads(routing_path.read_text(encoding="utf-8"))

    variants = []
    missing = json.loads(json.dumps(base))
    missing["routes"].pop()
    variants.append((missing, "exact 17-core"))
    swapped = json.loads(json.dumps(base))
    swapped["routes"][0]["tma_selection_name"] = swapped["routes"][1]["tma_selection_name"]
    variants.append((swapped, "frozen mapping"))
    unknown = json.loads(json.dumps(base))
    unknown["routes"][0]["image_member_path"] = "slides/not-present.tif"
    variants.append((unknown, "not a regular archive member"))

    for index, (value, message) in enumerate(variants):
        candidate = tmp_path / ("bad-routing-%d.json" % index)
        candidate.write_text(json.dumps(value), encoding="utf-8")
        with pytest.raises(ValueError, match=message):
            images._build_pending_image_qualification_receipt(
                archive_path=archive,
                supplied_archive_sha256=_sha256(archive),
                routing_path=candidate,
                tma_coordinates_path=coordinates,
                expected_archive_bytes=archive.stat().st_size,
            )


def test_partial_or_wrong_hash_archive_never_produces_a_receipt(tmp_path: Path) -> None:
    partial = _safe_archive(tmp_path / (images.ARCHIVE_FINAL_NAME + ".part"))
    coordinates = _coordinates(tmp_path / "coordinates.csv")
    routing = _routing(
        tmp_path / "routing.json",
        archive_sha256=_sha256(partial),
        coordinates_sha256=_sha256(coordinates),
    )
    with pytest.raises(ValueError, match="never .part"):
        images.build_pending_gse315411_image_qualification_receipt(
            archive_path=partial,
            supplied_archive_sha256=_sha256(partial),
            routing_path=routing,
            tma_coordinates_path=coordinates,
        )
    with pytest.raises(ValueError, match="SHA-256 differs"):
        images.inspect_safe_tar_archive(
            partial,
            expected_bytes=partial.stat().st_size,
            supplied_sha256="0" * 64,
        )


def test_cli_writes_pending_receipt_once_with_synthetic_archives(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    archive = _safe_archive(tmp_path / images.ARCHIVE_FINAL_NAME)
    coordinates = _coordinates(tmp_path / images.TMA_COORDINATES_FINAL_NAME)
    routing = _routing(
        tmp_path / "routing.json",
        archive_sha256=_sha256(archive),
        coordinates_sha256=_sha256(coordinates),
    )
    output = tmp_path / "pending.json"
    monkeypatch.setattr(images, "ARCHIVE_EXPECTED_BYTES", archive.stat().st_size)
    synthetic_coordinates = images._load_tma_coordinates(coordinates)
    monkeypatch.setattr(
        images, "TMA_COORDINATES_SHA256", synthetic_coordinates["raw_file_sha256"]
    )
    monkeypatch.setattr(
        images,
        "TMA_COORDINATE_RECORDS_SHA256",
        synthetic_coordinates["coordinate_records_sha256"],
    )
    monkeypatch.setattr(
        images, "TMA_COORDINATE_RECORD_COUNT", synthetic_coordinates["record_count"]
    )
    cli = _load_cli()
    arguments = [
        "qualify-images-pending",
        "--he-archive",
        str(archive),
        "--he-archive-sha256",
        _sha256(archive),
        "--routing",
        str(routing),
        "--tma-coordinates",
        str(coordinates),
        "--output",
        str(output),
    ]
    assert cli.main(arguments) == 0
    assert json.loads(output.read_text(encoding="utf-8"))["phase3_qualified"] is False
    with pytest.raises(FileExistsError, match="replacement is forbidden"):
        cli.main(arguments)


def test_schemas_are_pending_only_and_disallow_extra_top_level_fields() -> None:
    root = Path(__file__).parents[1] / "configs" / "schemas"
    routing = json.loads((root / "gse315411_image_routing.schema.json").read_text())
    receipt = json.loads(
        (root / "gse315411_image_registration_qualification_receipt.schema.json").read_text()
    )

    assert routing["additionalProperties"] is False
    assert receipt["additionalProperties"] is False
    assert receipt["properties"]["status"] == {"const": "pending_required_evidence"}
    assert receipt["properties"]["phase3_qualified"] == {"const": False}
    assert receipt["properties"]["molecular_release_authorized"] == {"const": False}
    assert receipt["properties"]["biological_execution_authorized"] == {"const": False}
