from __future__ import annotations

import json
import tarfile
from io import BytesIO
from pathlib import Path

import numpy as np
import pytest

from heir.annotation import celltypist_inert as inert


def _write_model(tmp_path: Path, panel: tuple[str, ...]) -> tuple[Path, Path]:
    features = list(panel[:379]) + ["MODEL_ONLY"]
    classes = ["A", "B"]
    weights = tmp_path / "weights.npz"
    np.savez_compressed(
        weights,
        coefficient_matrix=np.vstack([np.linspace(-0.2, 0.2, 380), np.linspace(0.3, -0.1, 380)]),
        intercepts=np.asarray([0.1, -0.2]),
        scaler_mean=np.linspace(0.0, 1.0, 380),
        scaler_scale=np.linspace(0.5, 1.5, 380),
        scaler_variance=np.linspace(0.25, 2.25, 380),
    )
    feature_hash = inert.canonical_sha256(features)
    class_hash = inert.canonical_sha256(classes)
    receipt = {
        "schema": "heir.celltypist_inert_export_receipt.v1",
        "source": {"verified_sha256": "a" * 64, "expected_sha256": "a" * 64},
        "weights": {"sha256": inert.sha256_file(weights)},
        "ordered_feature_ids": features,
        "ordered_feature_ids_sha256": feature_hash,
        "ordered_class_ids": classes,
        "ordered_class_ids_sha256": class_hash,
        "normalization": {"with_mean": True, "with_std": True},
        "pickle_required_for_production_inference": False,
    }
    receipt_path = tmp_path / "receipt.json"
    receipt_path.write_text(json.dumps(receipt), encoding="utf-8")
    return weights, receipt_path


def test_inert_prediction_matches_explicit_linear_formula(tmp_path: Path) -> None:
    panel = tuple(f"G{index:03d}" for index in range(480))
    weights, receipt = _write_model(tmp_path, panel)
    model = inert.InertCellTypistModel.load(
        weights, receipt, panel, require_official_human_lung_v2=False
    )
    counts = np.vstack([np.ones(480), np.arange(480) % 11, np.zeros(480)])
    prediction = model.predict_raw_counts(counts)

    library = counts[:2].sum(axis=1, keepdims=True)
    normalized = np.log1p(counts[:2] / library * 10000.0)[:, :379]
    scaled = np.minimum((normalized - model.scaler_mean) / model.scaler_scale, 10.0)
    expected = scaled @ model.coefficient_matrix.T + model.intercepts
    np.testing.assert_allclose(prediction.decision_scores[:2], expected, rtol=0, atol=1e-12)
    assert prediction.predicted_labels[2] == "__ABSTAIN__"
    assert prediction.confidences[2] == 0.0
    assert model.identity()["missing_feature_rule"] == (
        "omit_absent_model_features_without_imputation"
    )


def test_inert_loader_rejects_tampered_weights(tmp_path: Path) -> None:
    panel = tuple(f"G{index:03d}" for index in range(480))
    weights, receipt = _write_model(tmp_path, panel)
    with weights.open("ab") as handle:
        handle.write(b"tamper")
    with pytest.raises(ValueError, match="differs from its export receipt"):
        inert.InertCellTypistModel.load(
            weights, receipt, panel, require_official_human_lung_v2=False
        )


def test_v1_panel_reader_streams_only_frozen_members(tmp_path: Path) -> None:
    archive_path = tmp_path / "probes.tar.gz"
    expected = (50, 380, 50)
    offset = 0
    with tarfile.open(archive_path, "w:gz") as archive:
        for member, count in zip(inert.DEFAULT_V1_PROBE_MEMBERS, expected):
            text = "".join(
                f">G{offset + index:03d} (ENSG{offset + index + 1:011d}) | 1 | 1\nACGT\n"
                for index in range(count)
            ).encode()
            info = tarfile.TarInfo(member)
            info.size = len(text)
            archive.addfile(info, BytesIO(text))
            offset += count
    genes = inert.read_v1_panel_genes(
        archive_path,
        expected_sha256=inert.sha256_file(archive_path),
    )
    assert len(genes) == 480
    assert len(set(genes)) == 480


def test_expected_calibration_error() -> None:
    value = inert.multiclass_expected_calibration_error(
        np.asarray([0.2, 0.4, 0.8, 0.9]),
        np.asarray([0, 1, 1, 1]),
        bin_count=2,
    )
    assert value == pytest.approx(0.175)


def test_inert_prediction_rejects_fractional_raw_counts(tmp_path: Path) -> None:
    panel = tuple(f"G{index:03d}" for index in range(480))
    weights, receipt = _write_model(tmp_path, panel)
    model = inert.InertCellTypistModel.load(
        weights, receipt, panel, require_official_human_lung_v2=False
    )
    counts = np.ones((1, 480), dtype=np.float64)
    counts[0, 0] = 0.5
    with pytest.raises(ValueError, match="integer-valued"):
        model.predict_raw_counts(counts)
