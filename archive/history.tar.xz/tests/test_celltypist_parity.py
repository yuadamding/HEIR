from __future__ import annotations

import numpy as np

from heir.annotation.celltypist_parity import deterministic_synthetic_counts


def test_synthetic_parity_counts_are_deterministic_nonzero_v1_rows() -> None:
    first = deterministic_synthetic_counts()
    second = deterministic_synthetic_counts()
    np.testing.assert_array_equal(first, second)
    assert first.shape == (16, 480)
    assert first.dtype == np.int64
    assert np.all(first >= 0)
    assert np.all(first.sum(axis=1) > 0)
