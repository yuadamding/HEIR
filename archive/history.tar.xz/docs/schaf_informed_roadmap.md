# SCHAF-informed HEIR roadmap

## Current software direction

The user-supplied HEIR software development plan now directs a separate personalized software
path: H&E geometry and cached features plus matched RNA and measured proteins feed a probabilistic
state mapper, then a relative-expression decoder. Spatial RNA supervises and evaluates that same
prediction path; it is absent from ordinary prediction inputs. See
[the current development guide](personalized_development.md) for the implementation and remaining
acceptance criteria.

The roadmap below records the earlier falsification program. Its terminal outcomes, prospective
eligibility restrictions, and study-specific execution gates remain valid for those identities.
Implementing the new prototype is not evidence that any of those gates passed. The historical
deferrals below are not a prohibition on the separately requested software revision.

## Decision principle

The transferable lesson is to qualify a stronger image-to-residual translator before increasing
reference-bank complexity. HEIR retains its donor-safe residual target and falsification controls;
it does not adopt a large end-to-end generator, adversarial alignment, or optimal transport merely
because those components exist in another architecture.

```text
Preserve frozen evidence
        |
        +-- Exposed HEST nonlinear qualification -> procedural failure -> seal version
        |
        +-- New unexposed cohort -> metadata eligibility -> 10-donor development H-MEAS
                                        |
                                        +-- production-equivalent B0 + decision calibration
                                                |
                                                +-- one-shot 5-donor locked evaluation
                                                        |
                                                        +-- if supported: pristine H-CELL
                                                                |
                                                                +-- H-REF v3 -> H-END2END / H-COMP
```

## Track A — estimator qualification on exposed data

1. **V1 retained.** Its missing blank input and unsupported registration subset permanently block
   biological execution.
2. **V2 gates passed.** The receipt-bound blank, Q3 registration estimand, complete runner, CUDA
   smoke, and 2,000-trial calibration were completed before opening the target.
3. **V2 stopped at B0.** The target opened once, but every registered B0 ridge candidate was
   ineligible in the first outer fold. No held-out estimate or refitted null completed.
4. **Procedural result.** D1 and D2 were not evaluable, because zero outer folds completed. The
   pre-outcome calibration tested synthetic held-out predictions but not production B0 selection,
   and the B0 rejection registry was not persisted. Seal v2 and do not tune or rerun on exposed
   HEST. This result does not establish absence of nonlinear signal; any further test needs a new
   protocol and unexposed outcomes.

## Track B — scientific authorization infrastructure

In parallel with exposed estimator work:

1. Obtain immutable, target-independent annotation provenance and row-level validation receipts.
2. Complete development-only H-MEAS and freeze a common reliable measured-gene panel.
3. Replace the computationally infeasible fixed calibration with a preregistered sequential design
   using simultaneous confidence bounds.
4. Register a genuinely pristine, cell-resolved cohort from metadata only before molecular outcomes
   are opened.

Estimator work cannot substitute for any of these prerequisites.

## Track C — references and end-to-end inference

This track remains blocked until a pristine H-CELL protocol passes.

1. Test reference fusion v3 with a single donor/type centroid as the primary bank and centered
   donor residual fusion.
2. Require matched banks to beat image-only, type routing, every wrong donor, and a generic bank
   while preserving variance, coverage, and rare-state performance.
3. Add calibrated H&E-only type routing and fixed-abstention evaluation.
4. Consider conditional mean matching, CORAL, or MMD before any adversarial alignment. Unpaired
   alignment remains H-COMP evidence and cannot establish cell-level instance correctness.

## Stop rules

- Nonlinear image models that do not beat the architecture-matched nonlinear nuisance model do not
  support image-specific information.
- Similar focal and target-removed performance blocks a target-cell interpretation.
- Improvement accompanied by molecular variance collapse blocks reference expansion.
- A retrospective pass allows only prospective protocol design; all biological authorization
  fields remain false.
- A failed predecessor is retained in the evidence bundle and is never relabeled.

## Deferred components

Encoder fine-tuning, RNA foundation-model substitution, reference-expanded genes, optimal
transport, adversarial alignment, graph learning, unknown-state modules, and iterative refinement
remain deferred until their immediate predecessor passes under the registered evidence hierarchy.
