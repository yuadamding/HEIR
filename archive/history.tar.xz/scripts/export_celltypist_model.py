#!/usr/bin/env python3
"""Materialize the pinned Human Lung Atlas CellTypist model as inert files."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from heir.annotation import OFFICIAL_HUMAN_LUNG_ATLAS_V2_SHA256, export_celltypist_pickle


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pickle", type=Path, required=True)
    parser.add_argument("--weights-output", type=Path, required=True)
    parser.add_argument("--receipt-output", type=Path, required=True)
    args = parser.parse_args()
    receipt = export_celltypist_pickle(
        args.pickle,
        OFFICIAL_HUMAN_LUNG_ATLAS_V2_SHA256,
        args.weights_output,
        args.receipt_output,
    )
    print(json.dumps({"schema": receipt["schema"], "receipt": str(args.receipt_output)}))


if __name__ == "__main__":
    main()
