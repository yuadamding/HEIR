#!/usr/bin/env python3
"""Run the isolated official-vs-inert Human Lung Atlas v2 parity gate."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from heir.annotation.celltypist_inert import InertCellTypistModel, read_v1_panel_genes
from heir.annotation.celltypist_parity import run_official_parity


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pickle", type=Path, required=True)
    parser.add_argument("--weights", type=Path, required=True)
    parser.add_argument("--model-receipt", type=Path, required=True)
    parser.add_argument("--probe-archive", type=Path, required=True)
    parser.add_argument("--official-python", type=Path, required=True)
    parser.add_argument("--celltypist-package-root", type=Path, required=True)
    parser.add_argument("--output-receipt", type=Path, required=True)
    args = parser.parse_args()
    panel = read_v1_panel_genes(args.probe_archive)
    model = InertCellTypistModel.load(args.weights, args.model_receipt, panel)
    receipt = run_official_parity(
        model=model,
        source_pickle=args.pickle,
        official_python=args.official_python,
        celltypist_package_root=args.celltypist_package_root,
        output_receipt=args.output_receipt,
    )
    print(json.dumps({"schema": receipt["schema"], "status": receipt["status"]}))


if __name__ == "__main__":
    main()
