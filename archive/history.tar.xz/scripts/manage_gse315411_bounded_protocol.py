#!/usr/bin/env python3
"""Validate custody/exposure receipts or generate the frozen GSE315411 10/5/2 split."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Optional, Sequence

from heir.data.gse315411_bounded_protocol import (
    generate_exposure_stratified_split,
    load_json_receipt,
    validate_custody_receipt,
    validate_exposure_map,
)
from heir.data.gse315411_image_qualification import (
    build_pending_gse315411_image_qualification_receipt,
)
from heir.utils import atomic_json_dump_noreplace, reject_output_input_collisions


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    custody = subparsers.add_parser(
        "validate-custody", description="Validate an independently issued custody receipt."
    )
    custody.add_argument("--receipt", type=Path, required=True)

    exposure = subparsers.add_parser(
        "validate-exposure", description="Validate a custodian-only exposure classification."
    )
    exposure.add_argument("--custody-receipt", type=Path, required=True)
    exposure.add_argument("--exposure-map", type=Path, required=True)

    split = subparsers.add_parser(
        "generate-split", description="Generate the only frozen exposure-stratified 10/5/2 split."
    )
    split.add_argument("--custody-receipt", type=Path, required=True)
    split.add_argument("--exposure-map", type=Path, required=True)
    split.add_argument("--output", type=Path, required=True)

    images = subparsers.add_parser(
        "qualify-images-pending",
        description=(
            "Safely bind the final H&E archive and exact 17-core routing; output remains pending."
        ),
    )
    images.add_argument("--he-archive", type=Path, required=True)
    images.add_argument("--he-archive-sha256", required=True)
    images.add_argument("--routing", type=Path, required=True)
    images.add_argument("--tma-coordinates", type=Path, required=True)
    images.add_argument("--v1-alignment-archive", type=Path)
    images.add_argument("--output", type=Path, required=True)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = _parser().parse_args(argv)
    if args.command == "qualify-images-pending":
        archive = args.he_archive.expanduser().resolve()
        routing = args.routing.expanduser().resolve()
        coordinates = args.tma_coordinates.expanduser().resolve()
        alignment = (
            args.v1_alignment_archive.expanduser().resolve()
            if args.v1_alignment_archive is not None
            else None
        )
        output = args.output.expanduser().resolve()
        inputs = [archive, routing, coordinates]
        if alignment is not None:
            inputs.append(alignment)
        reject_output_input_collisions(
            (output,), tuple(inputs), label="GSE315411 pending image qualification"
        )
        receipt = build_pending_gse315411_image_qualification_receipt(
            archive_path=archive,
            supplied_archive_sha256=args.he_archive_sha256,
            routing_path=routing,
            tma_coordinates_path=coordinates,
            v1_alignment_archive_path=alignment,
        )
        try:
            atomic_json_dump_noreplace(dict(receipt), output)
        except FileExistsError as error:
            raise FileExistsError(
                "image qualification receipt output already exists; replacement is forbidden"
            ) from error
        print(
            json.dumps(
                {
                    "status": receipt["status"],
                    "phase3_qualified": receipt["phase3_qualified"],
                    "molecular_release_authorized": receipt["molecular_release_authorized"],
                    "receipt_sha256": receipt["receipt_sha256"],
                    "missing_required_evidence": receipt["missing_required_evidence"],
                },
                indent=2,
                sort_keys=True,
            )
        )
        return 0

    if args.command == "validate-custody":
        custody = validate_custody_receipt(load_json_receipt(args.receipt))
        print(
            json.dumps(
                {
                    "schema": custody["schema"],
                    "cohort": custody["cohort"],
                    "receipt_sha256": custody["receipt_sha256"],
                    "valid": True,
                },
                indent=2,
                sort_keys=True,
            )
        )
        return 0

    custody_path = args.custody_receipt.expanduser().resolve()
    exposure_path = args.exposure_map.expanduser().resolve()
    custody = validate_custody_receipt(load_json_receipt(custody_path))
    exposure = validate_exposure_map(load_json_receipt(exposure_path), custody)
    if args.command == "validate-exposure":
        print(
            json.dumps(
                {
                    "schema": exposure["schema"],
                    "cohort": exposure["cohort"],
                    "receipt_sha256": exposure["receipt_sha256"],
                    "valid": True,
                },
                indent=2,
                sort_keys=True,
            )
        )
        return 0

    output = args.output.expanduser().resolve()
    reject_output_input_collisions(
        (output,), (custody_path, exposure_path), label="GSE315411 split generation"
    )
    split = generate_exposure_stratified_split(custody, exposure)
    try:
        atomic_json_dump_noreplace(dict(split), output)
    except FileExistsError as error:
        raise FileExistsError(
            "split receipt output already exists; replacement is forbidden"
        ) from error
    print(
        json.dumps(
            {
                "development": split["development"],
                "locked_evaluation": split["locked_evaluation"],
                "reserve": split["reserve"],
                "receipt_sha256": split["receipt_sha256"],
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
