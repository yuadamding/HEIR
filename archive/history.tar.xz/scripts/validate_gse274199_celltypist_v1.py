#!/usr/bin/env python3
"""Run donor-aware V1-only CellTypist validation on public GSE274199 counts."""

from __future__ import annotations

import argparse
import csv
import gzip
import io
import json
import os
import tempfile
from pathlib import Path
from typing import Mapping, Sequence

import h5py
import numpy as np

from heir.annotation.celltypist_export import _publish_noreplace
from heir.annotation.celltypist_inert import (
    InertCellTypistModel,
    canonical_sha256,
    read_v1_panel_genes,
    sha256_file,
)
from heir.annotation.external_validation import summarize_predictions, support_by_class_and_donor

SCHEMA = "heir.gse274199_celltypist_v1_external_validation.v1"
EXPECTED_H5AD_BYTES = 1_180_621_333
EXPECTED_H5AD_SHA256 = "0648ce0268807301b5fe1b92955ed8e9d29c5f67812c6ed9ec3ed7da79e79b4c"
H5AD_URL = "https://datasets.cellxgene.cziscience.com/af6e81be-e65c-4821-987e-e0eb6c8acd59.h5ad"
COLLECTION_URL = (
    "https://cellxgene.cziscience.com/collections/e276e3e2-197a-4524-abd1-a753a48dc33a"
)
GEO_URL = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE274199"
ARTICLE_URL = "https://doi.org/10.1016/j.healun.2026.02.1666"
CODE_URL = "https://github.com/hayes-potter-lab/fibro-changes-acr"
PORTAL_LICENSE_EVIDENCE_URL = (
    "https://cellxgene.cziscience.com/docs/032__Contribute%20and%20Publish%20Data"
)
VALIDATION_COLUMNS = (
    "validation_split",
    "validation_donor_id",
    "cell_id",
    "author_cell_type",
    "cell_ontology_term_id",
    "true_model_class",
    "predicted_model_class",
    "confidence",
    "abstained",
    "raw_sigmoid_probabilities_json",
)


def _decoded(values: np.ndarray) -> np.ndarray:
    return np.asarray([
        value.decode() if isinstance(value, (bytes, np.bytes_)) else str(value)
        for value in values
    ])


def _read_h5_vector(value: h5py.Dataset | h5py.Group) -> np.ndarray:
    if isinstance(value, h5py.Group):
        categories = _decoded(value["categories"][()])
        codes = np.asarray(value["codes"][()], dtype=np.int64)
        if np.any((codes < 0) | (codes >= len(categories))):
            raise ValueError("H5AD categorical vector contains an invalid code")
        return categories[codes]
    return _decoded(value[()])


def _json_object(path: Path, label: str) -> Mapping[str, object]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if type(value) is not dict:
        raise ValueError(f"{label} must be a plain JSON object")
    return value


def _atomic_json_noreplace(path: Path, payload: Mapping[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        _publish_noreplace(Path(temporary), path)
        Path(temporary).unlink()
    except BaseException:
        Path(temporary).unlink(missing_ok=True)
        raise


def _atomic_text_noreplace(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        _publish_noreplace(Path(temporary), path)
        Path(temporary).unlink()
    except BaseException:
        Path(temporary).unlink(missing_ok=True)
        raise


def _write_validation_rows(path: Path, rows: Sequence[tuple[str, ...]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    os.close(descriptor)
    try:
        with Path(temporary).open("wb") as raw:
            with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
                with io.TextIOWrapper(compressed, encoding="utf-8", newline="") as text:
                    writer = csv.writer(text, delimiter="\t", lineterminator="\n")
                    writer.writerow(VALIDATION_COLUMNS)
                    writer.writerows(rows)
            raw.flush()
            os.fsync(raw.fileno())
        _publish_noreplace(Path(temporary), path)
        Path(temporary).unlink()
    except BaseException:
        Path(temporary).unlink(missing_ok=True)
        raise


def _panel_count_rows(
    matrix: h5py.Group,
    start: int,
    stop: int,
    column_to_panel: np.ndarray,
) -> np.ndarray:
    pointers = np.asarray(matrix["indptr"][start : stop + 1], dtype=np.int64)
    if len(pointers) != stop - start + 1 or np.any(np.diff(pointers) < 0):
        raise ValueError("raw CSR row pointers are malformed")
    first, last = int(pointers[0]), int(pointers[-1])
    indices = np.asarray(matrix["indices"][first:last], dtype=np.int64)
    data = np.asarray(matrix["data"][first:last])
    if indices.shape != data.shape or np.any((indices < 0) | (indices >= len(column_to_panel))):
        raise ValueError("raw CSR indices/data are malformed")
    row_indices = np.repeat(np.arange(stop - start, dtype=np.int64), np.diff(pointers))
    panel_indices = column_to_panel[indices]
    selected = panel_indices >= 0
    dense = np.zeros((stop - start, 480), dtype=np.float64)
    np.add.at(dense, (row_indices[selected], panel_indices[selected]), data[selected])
    return dense


def _classes_with_support(
    model_classes: Sequence[str],
    support: Mapping[str, Mapping[str, int]],
    *,
    minimum_cells: int,
    minimum_donors: int,
) -> tuple[str, ...]:
    return tuple(
        class_id
        for class_id in model_classes
        if class_id in support
        and sum(count >= minimum_cells for count in support[class_id].values()) >= minimum_donors
    )


def _per_donor_metrics(
    *,
    donor_values: np.ndarray,
    truth: np.ndarray,
    predicted: np.ndarray,
    confidence: np.ndarray,
    abstained: np.ndarray,
    class_ids: Sequence[str],
    donor_ids: Sequence[str],
    support: Mapping[str, Mapping[str, int]],
    minimum_cells: int,
    calibration_bins: int,
) -> Mapping[str, object]:
    result: dict[str, object] = {}
    for donor in donor_ids:
        donor_classes = tuple(
            class_id for class_id in class_ids if support[class_id].get(donor, 0) >= minimum_cells
        )
        selected = (donor_values == donor) & np.isin(truth, donor_classes)
        if not donor_classes or not selected.any():
            result[donor] = {"status": "insufficient_supported_types", "class_ids": []}
            continue
        result[donor] = {
            "status": "reported",
            "class_ids": list(donor_classes),
            **summarize_predictions(
                truth[selected],
                predicted[selected],
                confidence[selected],
                abstained[selected],
                donor_classes,
                calibration_bins=calibration_bins,
            ),
        }
    return result


def _format_metric(value: object) -> str:
    return "NA" if value is None else f"{float(value):.4f}"


def _report(receipt: Mapping[str, object], receipt_sha256: str) -> str:
    decision = receipt["decision"]
    primary = receipt["primary_validation"]
    thresholds = receipt["quality_thresholds"]
    lines = [
        "# GSE274199 V1-only annotation validation",
        "",
        f"Receipt SHA-256: `{receipt_sha256}`",
        "",
        "## Outcome",
        "",
        f"**{decision['status'].upper()} — {decision['reason']}**",
        "",
        (
            f"The pediatric primary set contained {primary['cells']} mapped candidate cells from "
            f"{len(primary['donor_ids'])} independent donors. The frozen external-validation "
            f"ontology contained {len(primary['candidate_model_classes'])} support-eligible model "
            f"classes; {len(decision['passing_model_classes_before_global_gate'])} passed their "
            "per-type discrimination/support checks."
        ),
        "",
        "## Frozen global metrics",
        "",
        "| Metric | Observed | Required |",
        "|---|---:|---:|",
        (
            "| Fine-type macro F1 | "
            f"{_format_metric(primary.get('fine_type_macro_f1'))} | "
            f"≥ {thresholds['minimum_fine_type_macro_f1']:.2f} |"
        ),
        (
            "| Multiclass ECE | "
            f"{_format_metric(primary.get('calibration_error'))} | "
            f"≤ {thresholds['maximum_multiclass_expected_calibration_error']:.2f} |"
        ),
        (
            "| Minimum class sensitivity | "
            f"{_format_metric(primary.get('minimum_major_class_sensitivity'))} | "
            f"≥ {thresholds['minimum_major_class_sensitivity']:.2f} |"
        ),
        (
            "| Prediction coverage | "
            f"{_format_metric(primary.get('prediction_coverage'))} | "
            f"≥ {thresholds['minimum_prediction_coverage']:.2f} |"
        ),
        "",
        "These metrics use the official CellTypist one-vs-rest sigmoid confidence; its 61-value "
        "vector is not a probability simplex. ECE therefore tests the confidence actually used by "
        "CellTypist rather than silently applying softmax or renormalization.",
        "",
        "## Per-class results",
        "",
        "| Model class | Cells | Donors ≥20 | F1 | Sensitivity | Qualified before global gate |",
        "|---|---:|---:|---:|---:|---|",
    ]
    support = primary["support_by_model_class_and_donor"]
    passing = set(decision["passing_model_classes_before_global_gate"])
    per_class = primary.get("per_class", {})
    for class_id in primary["candidate_model_classes"]:
        metrics = per_class[class_id]
        donor_count = sum(int(value) >= 20 for value in support[class_id].values())
        lines.append(
            f"| {class_id} | {metrics['true_cells']} | {donor_count} | "
            f"{metrics['f1']:.4f} | {metrics['sensitivity']:.4f} | "
            f"{'yes' if class_id in passing else 'no'} |"
        )
    lines.extend(
        [
            "",
            "## Per-donor results",
            "",
            "| Donor | Cells | Supported classes | Macro F1 | ECE | Min sensitivity | Coverage |",
            "|---|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for donor, metrics in primary["per_donor_metrics"].items():
        if metrics["status"] != "reported":
            lines.append(f"| {donor} | 0 | 0 | NA | NA | NA | NA |")
        else:
            lines.append(
                f"| {donor} | {metrics['cells']} | {len(metrics['class_ids'])} | "
                f"{metrics['fine_type_macro_f1']:.4f} | {metrics['calibration_error']:.4f} | "
                f"{metrics['minimum_major_class_sensitivity']:.4f} | "
                f"{metrics['prediction_coverage']:.4f} |"
            )
    lines.extend(
        [
            "",
            "## Scientific scope and provenance",
            "",
            "- Cohort/individual independence is accepted with a deidentification caveat: the "
            "Cincinnati allograft cohort is institutionally, temporally, and author-disjoint from "
            "Vanderbilt GSE315411, but public aliases cannot cryptographically prove identity "
            "non-overlap.",
            "- No direct CellTypist/HLCA labeling circularity was found. The article and released "
            "code do not cite or invoke CellTypist, Sikkema HLCA, Azimuth, or label transfer.",
            "- Upstream author-label construction code is absent. The author labels plus curated "
            "Cell Ontology terms are defensible, but their construction is not fully reproducible.",
            "- The article is CC BY 4.0; the analysis-code repository is MIT. CELLxGENE's "
            "contribution documentation says publicly released portal data are accessed under "
            "CC BY 4.0. These are recorded as separate evidence rather than treating the article "
            "license as the GEO dataset license.",
            "- GSE274199 is a transplant/rejection cohort. It is a stringent external validation, "
            "not a healthy-infant domain match.",
            "",
            "## Input and safety identity",
            "",
            f"- H5AD SHA-256: `{receipt['source_dataset']['h5ad_sha256']}`",
            f"- Inert weights SHA-256: `{receipt['model']['weights_sha256']}`",
            f"- Final parity receipt SHA-256: `{receipt['parity']['receipt_sha256']}`",
            f"- V1 panel: {receipt['feature_audit']['v1_panel_gene_count']} genes; "
            f"model-supported: {receipt['feature_audit']['supported_model_feature_count']} genes.",
            "- Normalization: library-size 10,000 over all 480 V1 genes, log1p, then select the "
            "379 supported features in model order; absent model features are not imputed.",
            "- Production scoring used inert numeric NPZ only. No GSE315411 expression or "
            "molecular outcome file was opened.",
            "",
        ]
    )
    return "\n".join(lines)


def run(args: argparse.Namespace) -> Mapping[str, object]:
    h5ad = args.h5ad.expanduser().resolve()
    mapping_path = args.mapping.expanduser().resolve()
    parity_path = args.parity_receipt.expanduser().resolve()
    if h5ad.stat().st_size != EXPECTED_H5AD_BYTES or sha256_file(h5ad) != EXPECTED_H5AD_SHA256:
        raise ValueError("GSE274199 H5AD differs from the pinned public asset")
    mapping = _json_object(mapping_path, "ontology mapping")
    parity = _json_object(parity_path, "parity receipt")
    if parity.get("status") != "pass" or parity.get("production_pickle_loaded") is not False:
        raise ValueError("final official-vs-inert parity receipt did not pass")
    panel = read_v1_panel_genes(args.probe_archive)
    model = InertCellTypistModel.load(args.weights, args.model_receipt, panel)
    model_class_set = set(model.classes)
    author_mapping = mapping.get("author_label_mapping")
    if type(author_mapping) is not dict:
        raise ValueError("ontology mapping lacks author labels")
    thresholds = mapping["quality_thresholds"]
    support_rule = mapping["support_rule"]
    primary_donors = tuple(str(value) for value in mapping["primary_validation_donor_ids"])
    sensitivity_donors = tuple(str(value) for value in mapping["age_shift_sensitivity_donor_ids"])
    minimum_cells = int(support_rule["minimum_cells_per_primary_donor"])
    minimum_donors = int(support_rule["minimum_primary_donors"])
    confidence_threshold = float(thresholds["confidence_threshold"])
    calibration_bins = int(thresholds["calibration_bins"])

    with h5py.File(h5ad, "r") as file:
        shape = tuple(int(value) for value in file["raw/X"].attrs["shape"])
        if shape != (56_676, 27_320) or file["raw/X"].attrs["encoding-type"] != "csr_matrix":
            raise ValueError("GSE274199 raw-count matrix identity changed")
        genes = _read_h5_vector(file["raw/var/gene_symbols"])
        if len(genes) != shape[1] or len(set(genes.tolist())) != shape[1]:
            raise ValueError("GSE274199 raw gene symbols are not unique")
        gene_index = {gene: index for index, gene in enumerate(genes)}
        missing_panel = [gene for gene in panel if gene not in gene_index]
        missing_supported = [gene for gene in model.supported_features if gene not in gene_index]
        if missing_panel or missing_supported:
            raise ValueError("GSE274199 does not contain the complete V1/model feature scope")
        column_to_panel = np.full(shape[1], -1, dtype=np.int32)
        for panel_index, gene in enumerate(panel):
            column_to_panel[gene_index[gene]] = panel_index

        donor = _read_h5_vector(file["obs/donor_id"])
        stage = _read_h5_vector(file["obs/development_stage"])
        author = _read_h5_vector(file["obs/author_cell_type"])
        ontology = _read_h5_vector(file["obs/cell_type_ontology_term_id"])
        cell_id = _read_h5_vector(file["obs/_index"])
        if any(len(value) != shape[0] for value in (donor, stage, author, ontology, cell_id)):
            raise ValueError("GSE274199 observation metadata is misaligned")
        if len(set(cell_id.tolist())) != shape[0]:
            raise ValueError("GSE274199 cell IDs are not unique")
        observed_authors = set(author.tolist())
        if observed_authors != set(author_mapping):
            raise ValueError("frozen author-label mapping does not cover the exact H5AD ontology")
        expected_donors = set(primary_donors) | set(sensitivity_donors)
        if set(donor.tolist()) != expected_donors or set(primary_donors) & set(sensitivity_donors):
            raise ValueError("GSE274199 donor scope differs from the frozen age split")

        true_model = np.full(shape[0], "", dtype=object)
        for raw_label, record in author_mapping.items():
            if type(record) is not dict:
                raise ValueError("author-label mapping record is malformed")
            selected = author == raw_label
            expected_term = str(record["cell_ontology_term_id"])
            if set(ontology[selected].tolist()) != {expected_term}:
                raise ValueError("CELLxGENE ontology term differs from the frozen crosswalk")
            target = record["model_class"]
            if target is not None:
                if str(target) not in model_class_set:
                    raise ValueError("ontology crosswalk names an absent model class")
                true_model[selected] = str(target)

        mapped = true_model != ""
        primary_scope = np.isin(donor, primary_donors) & mapped
        mapped_class_set = set(true_model)
        mapped_classes = tuple(
            class_id for class_id in model.classes if class_id in mapped_class_set
        )
        initial_support = support_by_class_and_donor(
            true_model[primary_scope],
            donor[primary_scope],
            mapped_classes,
            primary_donors,
        )
        candidate_classes = _classes_with_support(
            model.classes,
            initial_support,
            minimum_cells=minimum_cells,
            minimum_donors=minimum_donors,
        )
        if len(candidate_classes) < 2:
            raise ValueError("fewer than two ontology classes meet the frozen support rule")
        evaluation_mask = mapped & np.isin(true_model, candidate_classes)
        evaluation_indices = np.flatnonzero(evaluation_mask)
        evaluation_position = np.full(shape[0], -1, dtype=np.int64)
        evaluation_position[evaluation_indices] = np.arange(len(evaluation_indices))
        predicted = np.full(len(evaluation_indices), None, dtype=object)
        confidence = np.zeros(len(evaluation_indices), dtype=np.float64)
        probabilities = np.zeros((len(evaluation_indices), len(model.classes)), dtype=np.float64)
        valid_library = np.zeros(len(evaluation_indices), dtype=np.bool_)
        matrix = file["raw/X"]
        for start in range(0, shape[0], args.batch_size):
            stop = min(start + args.batch_size, shape[0])
            local_global = np.arange(start, stop)
            local_selected = evaluation_mask[start:stop]
            if not local_selected.any():
                continue
            counts = _panel_count_rows(matrix, start, stop, column_to_panel)
            batch_prediction = model.predict_raw_counts(counts)
            target_positions = evaluation_position[local_global[local_selected]]
            predicted[target_positions] = batch_prediction.predicted_labels[local_selected]
            confidence[target_positions] = batch_prediction.confidences[local_selected]
            probabilities[target_positions] = batch_prediction.raw_sigmoid_probabilities[
                local_selected
            ]
            valid_library[target_positions] = batch_prediction.valid_library_mask[local_selected]

    if not valid_library.all() or any(value is None for value in predicted):
        raise ValueError("external validation contains a zero V1 library or missing prediction")
    eval_donor = donor[evaluation_indices]
    eval_truth = np.asarray(true_model[evaluation_indices], dtype="U")
    eval_author = author[evaluation_indices]
    eval_ontology = ontology[evaluation_indices]
    eval_cell_id = cell_id[evaluation_indices]
    eval_predicted = np.asarray(predicted, dtype="U")
    eval_abstained = confidence < confidence_threshold
    primary_selected = np.isin(eval_donor, primary_donors)
    sensitivity_selected = np.isin(eval_donor, sensitivity_donors)

    primary_support = support_by_class_and_donor(
        eval_truth[primary_selected],
        eval_donor[primary_selected],
        candidate_classes,
        primary_donors,
    )
    primary_metrics = summarize_predictions(
        eval_truth[primary_selected],
        eval_predicted[primary_selected],
        confidence[primary_selected],
        eval_abstained[primary_selected],
        candidate_classes,
        calibration_bins=calibration_bins,
    )
    primary_per_donor = _per_donor_metrics(
        donor_values=eval_donor[primary_selected],
        truth=eval_truth[primary_selected],
        predicted=eval_predicted[primary_selected],
        confidence=confidence[primary_selected],
        abstained=eval_abstained[primary_selected],
        class_ids=candidate_classes,
        donor_ids=primary_donors,
        support=primary_support,
        minimum_cells=minimum_cells,
        calibration_bins=calibration_bins,
    )

    type_decisions: dict[str, object] = {}
    passing_types = []
    for class_id in candidate_classes:
        class_metrics = primary_metrics["per_class"][class_id]
        supported_donors = tuple(
            donor_id
            for donor_id in primary_donors
            if primary_support[class_id][donor_id] >= minimum_cells
        )
        donor_sensitivities = {
            donor_id: primary_per_donor[donor_id]["per_class"][class_id]["sensitivity"]
            for donor_id in supported_donors
        }
        reasons = []
        if class_metrics["f1"] < float(thresholds["minimum_fine_type_macro_f1"]):
            reasons.append("class_f1_below_0.70")
        if class_metrics["sensitivity"] < float(thresholds["minimum_major_class_sensitivity"]):
            reasons.append("class_sensitivity_below_0.50")
        if any(
            value < float(thresholds["minimum_major_class_sensitivity"])
            for value in donor_sensitivities.values()
        ):
            reasons.append("supported_donor_sensitivity_below_0.50")
        passed = not reasons
        if passed:
            passing_types.append(class_id)
        type_decisions[class_id] = {
            "status": "pass" if passed else "fail",
            "reasons": reasons,
            "supported_primary_donor_ids": list(supported_donors),
            "sensitivity_by_supported_primary_donor": donor_sensitivities,
        }

    passing_types = tuple(passing_types)
    qualified_mask = primary_selected & np.isin(eval_truth, passing_types)
    qualified_metrics = None
    if len(passing_types) >= 2 and qualified_mask.any():
        qualified_metrics = summarize_predictions(
            eval_truth[qualified_mask],
            eval_predicted[qualified_mask],
            confidence[qualified_mask],
            eval_abstained[qualified_mask],
            passing_types,
            calibration_bins=calibration_bins,
        )
    global_reasons = []
    if qualified_metrics is None:
        global_reasons.append("fewer_than_two_discrimination_qualified_types")
    else:
        if qualified_metrics["fine_type_macro_f1"] < float(
            thresholds["minimum_fine_type_macro_f1"]
        ):
            global_reasons.append("fine_type_macro_f1_below_0.70")
        if qualified_metrics["calibration_error"] > float(
            thresholds["maximum_multiclass_expected_calibration_error"]
        ):
            global_reasons.append("calibration_error_above_0.10")
        if qualified_metrics["minimum_major_class_sensitivity"] < float(
            thresholds["minimum_major_class_sensitivity"]
        ):
            global_reasons.append("minimum_major_class_sensitivity_below_0.50")
        if qualified_metrics["prediction_coverage"] < float(
            thresholds["minimum_prediction_coverage"]
        ):
            global_reasons.append("prediction_coverage_below_0.80")
    passed = not global_reasons

    sensitivity_metrics: Mapping[str, object] | None = None
    sensitivity_classes = tuple(
        class_id
        for class_id in candidate_classes
        if np.any(sensitivity_selected & (eval_truth == class_id))
    )
    if sensitivity_classes:
        adult_rows = sensitivity_selected & np.isin(eval_truth, sensitivity_classes)
        sensitivity_metrics = summarize_predictions(
            eval_truth[adult_rows],
            eval_predicted[adult_rows],
            confidence[adult_rows],
            eval_abstained[adult_rows],
            sensitivity_classes,
            calibration_bins=calibration_bins,
        )

    row_values = []
    class_probabilities = [
        json.dumps(row.tolist(), separators=(",", ":"), allow_nan=False) for row in probabilities
    ]
    for index in range(len(evaluation_indices)):
        split = "pediatric_primary" if primary_selected[index] else "adult_age_shift_sensitivity"
        row_values.append(
            (
                split,
                str(eval_donor[index]),
                str(eval_cell_id[index]),
                str(eval_author[index]),
                str(eval_ontology[index]),
                str(eval_truth[index]),
                str(eval_predicted[index]),
                repr(float(confidence[index])),
                "true" if eval_abstained[index] else "false",
                class_probabilities[index],
            )
        )
    row_values.sort(key=lambda row: (0 if row[0] == "pediatric_primary" else 1, row[1], row[2]))
    _write_validation_rows(args.output_rows, row_values)

    stage_by_donor = {
        donor_id: sorted(set(stage[donor == donor_id].tolist())) for donor_id in expected_donors
    }
    unsupported_counts = {
        label: int((author == label).sum())
        for label, record in author_mapping.items()
        if record["model_class"] is None
    }
    primary_block = {
        **primary_metrics,
        "donor_ids": list(primary_donors),
        "cells": int(primary_selected.sum()),
        "candidate_model_classes": list(candidate_classes),
        "support_by_model_class_and_donor": primary_support,
        "per_donor_metrics": primary_per_donor,
    }
    receipt = {
        "schema": SCHEMA,
        "decision": {
            "status": "pass" if passed else "fail",
            "reason": (
                "external_v1_only_annotation_gate_passed"
                if passed
                else "external_v1_only_annotation_gate_failed_closed"
            ),
            "global_failure_reasons": global_reasons,
            "passing_model_classes_before_global_gate": list(passing_types),
            "qualified_model_classes_for_gse315411": list(passing_types) if passed else [],
            "authorizes_gse315411_annotation": passed,
        },
        "source_dataset": {
            "accession": "GSE274199",
            "h5ad_path": str(h5ad),
            "h5ad_url": H5AD_URL,
            "h5ad_bytes": EXPECTED_H5AD_BYTES,
            "h5ad_sha256": EXPECTED_H5AD_SHA256,
            "cells": 56_676,
            "raw_count_shape": [56_676, 27_320],
            "collection_url": COLLECTION_URL,
            "geo_url": GEO_URL,
            "article_url": ARTICLE_URL,
            "code_url": CODE_URL,
            "donor_ids": sorted(expected_donors),
            "development_stage_by_donor": stage_by_donor,
            "primary_pediatric_cells_all_labels": int(np.isin(donor, primary_donors).sum()),
            "license_evidence": {
                "article": "CC_BY_4.0",
                "analysis_code_repository": "MIT",
                "cellxgene_public_data_terms": "CC_BY_4.0_per_portal_contribution_documentation",
                "cellxgene_public_data_terms_url": PORTAL_LICENSE_EVIDENCE_URL,
                "geo_dataset_license": "not_separately_asserted",
            },
        },
        "independence_and_label_provenance": mapping["independence_assessment"],
        "mapping": {
            "path": str(mapping_path),
            "sha256": sha256_file(mapping_path),
            "schema": mapping["schema"],
            "frozen_before_expression_scoring": mapping["frozen_before_expression_scoring"],
            "policy": mapping["mapping_policy"],
            "author_label_mapping": author_mapping,
            "unsupported_author_label_cell_counts": unsupported_counts,
        },
        "feature_audit": {
            "v1_panel_gene_count": len(panel),
            "v1_panel_genes_present": len(panel),
            "supported_model_feature_count": len(model.supported_features),
            "supported_model_features_present": len(model.supported_features),
            "missing_v1_panel_genes": missing_panel,
            "missing_supported_model_features": missing_supported,
            "h5ad_feature_field": "raw.var.gene_symbols",
            "ordered_v1_panel_genes_sha256": canonical_sha256(list(panel)),
            "ordered_supported_model_features_sha256": canonical_sha256(
                list(model.supported_features)
            ),
        },
        "model": dict(model.identity()),
        "parity": {
            "receipt_path": str(parity_path),
            "receipt_sha256": sha256_file(parity_path),
            "schema": parity["schema"],
            "status": parity["status"],
            "comparison": parity["comparison"],
        },
        "quality_thresholds": thresholds,
        "support_rule": support_rule,
        "primary_validation": primary_block,
        "type_qualification": type_decisions,
        "qualified_type_global_metrics": qualified_metrics,
        "adult_age_shift_sensitivity": {
            "donor_ids": list(sensitivity_donors),
            "candidate_model_classes_observed": list(sensitivity_classes),
            "metrics": sensitivity_metrics,
            "decision_role": "prespecified_sensitivity_not_a_substitute_for_primary_donors",
        },
        "row_level_evidence": {
            "path": str(args.output_rows.resolve()),
            "sha256": sha256_file(args.output_rows),
            "rows": len(row_values),
            "columns": list(VALIDATION_COLUMNS),
            "row_order": "validation_split_then_donor_then_cell_id",
            "probability_vector_order": list(model.classes),
            "probability_semantics": "official_independent_one_vs_rest_sigmoid_not_simplex",
        },
        "execution": {
            "production_pickle_loaded": False,
            "gse315411_molecular_data_loaded": False,
            "batch_size": args.batch_size,
            "worker_processes": 1,
            "visible_cpu_affinity": sorted(os.sched_getaffinity(0)),
            "gpu_used": False,
            "implementation_sha256": {
                "runner": sha256_file(Path(__file__).resolve()),
                "inert_scorer": sha256_file(
                    Path(__file__).resolve().parents[1]
                    / "src/heir/annotation/celltypist_inert.py"
                ),
                "metrics": sha256_file(
                    Path(__file__).resolve().parents[1]
                    / "src/heir/annotation/external_validation.py"
                ),
            },
        },
    }
    _atomic_json_noreplace(args.output_receipt, receipt)
    receipt_sha = sha256_file(args.output_receipt)
    _atomic_text_noreplace(args.output_report, _report(receipt, receipt_sha))
    return receipt


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--h5ad", type=Path, required=True)
    parser.add_argument("--weights", type=Path, required=True)
    parser.add_argument("--model-receipt", type=Path, required=True)
    parser.add_argument("--probe-archive", type=Path, required=True)
    parser.add_argument("--parity-receipt", type=Path, required=True)
    parser.add_argument("--mapping", type=Path, required=True)
    parser.add_argument("--output-rows", type=Path, required=True)
    parser.add_argument("--output-receipt", type=Path, required=True)
    parser.add_argument("--output-report", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=512)
    args = parser.parse_args()
    if args.batch_size < 1 or args.batch_size > 4096:
        parser.error("--batch-size must be between 1 and 4096")
    receipt = run(args)
    print(json.dumps({"schema": receipt["schema"], "decision": receipt["decision"]}))


if __name__ == "__main__":
    main()
