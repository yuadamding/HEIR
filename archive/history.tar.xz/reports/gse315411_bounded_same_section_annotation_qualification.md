# GSE315411 bounded same-section qualification

## Terminal result

`gse315411_bounded_same_section_cell_state_v1` stopped at its frozen Phase-4 annotation gate:

```text
terminal_pre_unlock_annotation_qualification_failure
fail_closed_before_biological_execution
```

No GSE315411 expression matrix, transcript table, per-cell molecular target, development Prime
payload, or locked Prime payload was opened. H-MEAS, B0, D1, D2, and biological model fitting were
not run. The nonlinear H&E-to-state hypothesis therefore remains **untested**, not biologically
unsupported.

## What was tested

The public GSE274199 human-lung single-cell cohort provided an external, donor-aware annotation
qualification set. The primary evaluation used 24,844 mapped cells from six pediatric donors; two
adult donors were retained as a prespecified age-shift sensitivity analysis. The input simulation
used raw counts for all 480 GSE315411 V1 genes, library-size normalization to 10,000, `log1p`, and
the 379 V1 genes supported by the frozen CellTypist Human Lung Atlas v2 model.

The executable pickle was not used for production scoring. It was converted in a no-network sandbox
to numeric-only NPZ weights. On 16 deterministic parity rows, the inert scorer agreed with official
CellTypist on 16/16 labels; maximum decision-score error was `1.0563e-6` and maximum sigmoid error
was `6.2915e-8`.

## Frozen gate results

Nineteen fine types met the prespecified support rule of at least 20 cells in at least three primary
donors. AT2, B cells, and CD8 T cells passed the per-type F1, sensitivity, and supported-donor
sensitivity checks. The frozen global gate was then recomputed on this surviving subset:

| Endpoint | All 19 candidates | Three-type subset | Required | Subset result |
|---|---:|---:|---:|---|
| Fine-type macro F1 | 0.392366 | 0.853995 | >= 0.70 | pass |
| Multiclass ECE | 0.359301 | 0.214970 | <= 0.10 | **fail** |
| Minimum class sensitivity | 0.000000 | 0.637805 | >= 0.50 | pass |
| Prediction coverage at confidence 0.50 | 0.414627 | 0.794065 | >= 0.80 | **fail** |

Because the conjunction failed, the qualified-type set is empty and the annotation stream is not
authorized for GSE315411. The 32,320-row evidence file was independently re-read after execution;
ontology mapping, class order, sigmoid argmax, confidence, abstention, donor support, all reported
metrics, and the failure decision were recomputed exactly.

An independent adversarial audit found three additional conservative facts. CellTypist's 61
one-vs-rest sigmoid values are not a probability simplex, so they do not satisfy HEIR's stricter
calibrated-probability-vector contract. If coverage counts only high-confidence predictions inside
the eligible ontology, it falls further to 0.40444 for the primary set and 0.77725 for the
three-type subset. Finally, every primary donor independently fails macro F1, ECE, minimum
sensitivity, and coverage. The runner also evaluates only 24,844 of 45,446 pediatric cells because
20,602 ambiguous, unsupported, or low-support truth cells are outside the candidate ontology; it
therefore cannot establish safe abstention or false-positive control for out-of-ontology lung cells.
None of these observations can reverse the terminal failure.

## Scientific decision

- This protocol identity is terminal and cannot repair, recalibrate, or rerun the annotation stream.
- A calibrated fine-type annotator or broad-lineage fallback requires a new protocol identity and
  new unexposed validation evidence.
- Completing the outcome-free H&E archive cannot revive this identity or authorize molecular access.
- The result does not authorize H-CELL, H-INTRINSIC, H-REF, H-EXT, or full HEIR.

## Bound artifacts

| Artifact | SHA-256 |
|---|---|
| GSE274199 H5AD | `0648ce0268807301b5fe1b92955ed8e9d29c5f67812c6ed9ec3ed7da79e79b4c` |
| CellTypist source pickle | `6b0730537f4fee9f9a6195891a72635d1a3b9e21cade7a7481b2b14808070fdd` |
| Inert NPZ weights | `547cd698a176f3b0cc64acd431628c503742fe62e4b1466a3d3c49cc807fef8b` |
| Final official/inert parity receipt | `7b37cccd44252cb663380acb41a9181dc8da58ef9d523ae21725ce06ac6b4913` |
| External validation receipt | `756e6cbf98e948bac3ab7d835d9e1d7a6d4098a3f8873688578d19fcd01b8d09` |
| Row-level validation evidence | `1bc06dff69fa60d6a88eae5729545b17bd39ffc76936f5955f2842ad1f6d2935` |
| HEIR terminal receipt content | `92703a5a4b7e510f930b1095c37089452ee2a4cda834bc08c8ed72622e03a080` |

The external cohort has defensible but not fully reproducible author-label provenance: released
materials do not show CellTypist/HLCA/Azimuth label transfer, but the upstream author-label
construction script is absent. This limitation cannot reverse the observed failure and is retained
in the machine-readable receipt.
