# GSE315411 prospective biological-test eligibility

**Terminal decision for `gse315411_nonlinear_morphology_v1`: fail closed before biological
execution.** GSE315411 is the first downloaded cohort
that meets the required count of independent biological individuals, and its dual Xenium assay can
support a clean V1-label/Prime-only-target design. It cannot be run under the current strict
prospective protocol because no independent molecular lock or target-independent annotation receipt
exists, and published per-sample molecular QC contaminated the first outcome-independent locked
split.

No expression matrix, transcript table, processed expression object, or per-cell molecular row was
opened. No biological model was fitted and no HEIR biological score was computed.

This protocol identity is consumed. Its rejected split must not be repaired, substituted, or rerun.
The result is an eligibility failure, not biological non-support, and it does not make GSE315411
permanently unusable under a genuinely new protocol.

## What passed

- The primary paper states that each slide contained samples from 17 individuals. The 17 TMA cores
  are therefore admissible biological units for a nominal 10-development/5-evaluation/2-reserve
  design.
- The single tissue section assayed sequentially with two chemistries provides two separable
  same-cell streams: V1 (`GSM9427183`) for annotation and Prime with V1 segmentation
  (`GSM9427185`) for molecular targets.
- The deposited probe definitions contain 480 unique V1 genes and 5,001 unique Prime genes, with
  239 overlapping genes. Excluding every V1 gene leaves 4,762 nominal Prime-only target genes.
- Outcome-free TMA coordinates, H&E, registration material, and H-optimus-1 features may be prepared
  before molecular unlock.
- The frozen primary encoder is H-optimus-1 revision
  `3592cb220dec7a150c5d7813fb56e68bd57473b9`; UNI2-h remains prohibited.

## Why the first prospective split was rejected

The initial assignment used only core IDs and the protocol identity:

```text
SHA256("gse315411_nonlinear_morphology_v1" || NUL || uppercase(core_id))
```

Ascending ranks 1-10 were development, 11-15 were locked evaluation, and 16-17 were reserve. This
placed `PDL034D` in the locked five. The paper explicitly reports a per-sample filtering-count
exception for `PDL034D`, so the split violates the frozen rule that locked molecular QC must not be
exposed. Supplemental-QC inspection also exposed the first rows for `PDL018D` and `PDL026A`.

The split is rejected rather than repaired after exposure. No replacement roles are frozen under
this protocol.

The only permissible successor considered here is
`gse315411_bounded_same_section_cell_state_v1`. It is a separate, non-authorizing Stage-A protocol;
it cannot inherit or revise the rejected split.

## Remaining hard blockers

1. GEO stores all 17 cores together in slide-wide molecular files. The current analysis account and
   exFAT data mount cannot enforce the required five-individual lock. An independent custodian must
   download, partition, hash, and retain the locked payload.
2. The authors' clusters are expression-derived and are not independent cell-type truth. A candidate
   CellTypist Human Lung Atlas v2 model has been downloaded and hashed. Static, non-executing pickle
   inspection found 379 of the 480 V1 gene symbols (79.0%) in the model, but its ontology, executable
   V1-only behavior, abstention rule, and locked categorical outputs have not been frozen.
3. Published per-sample QC invalidates the first split under the current identity. A new protocol may
   proceed only if an independent custodian classifies every core's public exposure and an
   exposure-stratified rule places every sample-specific-summary exposure in development while
   retaining five unexposed locked individuals and two unexposed reserves.
4. H-MEAS, the production-equivalent B0 scenario matrix, complete synthetic decision calibration,
   and the one-time runner cannot execute until the preceding custody and annotation gates pass.

## Acquisition now running

The outcome-free H&E archive is downloading to
`/mnt/seagate/HnE/GSE315411/images/GSE315411_HE_images.tar.gz.part`. The expected byte count is
35,204,235,163. Transfer is limited to 4 MiB/s, one process, one CPU, idle-priority I/O, and the file
will not be promoted until its tar structure and local SHA-256 are verified.

The two outcome-bearing audit files were moved to
`/mnt/seagate/HnE/GSE315411/outcome_quarantine/`. This is an audit quarantine, not independent
custody, and neither file is authorized as prospective input.

## Scientific boundary

With a newly frozen exposure-stratified protocol and genuine custody, this cohort could test a
  bounded Stage-A question: whether H-optimus-1 H&E features predict Prime-only within-type molecular
state when type labels use only V1 genes and an external lung ontology. It cannot test matched
single-nucleus reference value, H-REF, H-END2END, external-center generalization, or H&E-only
  deployment. One TMA and one assayed tissue section per individual also make donor/type and
donor/section/type endpoints effectively identical.

The machine-readable receipt is
`reports/gse315411_prospective_eligibility_receipt.json`.
